package stepDefs;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ApprovalPT;
import pages.HomePage;

public class UtilitiesstepDef extends TestBase{
	HomePage homepage;
	ApprovalPT approvalpt;
	
	@Given("Launches application")
	public void launch_act_application() {
			
		try {
			initialize();
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Then("Home page gets dispalyed")
	public void user_is_on_home_page() {
	 try {
		    	homepage = new HomePage();
		    	homepage.userOnHomePageValidation();
		    	
		    	
	    }
		    
		    catch(Exception e)
		{
				e.printStackTrace();
			}
	}
	
	@When("User selects ExpandApprovals, Utilities and Team name change")
	public void user_selects_expand_approvals_utilities_and_team_name_change() {
		try {
			approvalpt = new ApprovalPT();
			approvalpt.clickOnApprovalButton();
			approvalpt.click_on_utility();
			
		}
		  catch(Exception e)
				{
						e.printStackTrace();
					}
	}
	
	@Then("Team name should be open")
	public void team_name_should_be_open() {
		try {
		approvalpt = new ApprovalPT();
		approvalpt.click_on_TeamNameChange();
		approvalpt.validate_TeamChangepage();
		}
		  catch(Exception e)
		{
				e.printStackTrace();
			}
	}
	
	@Then("Client NameFSG OfficeFSG Team fields should be displayed")
	public void client_name_fsg_office_fsg_team_fields_should_be_displayed() {
		try {
			approvalpt = new ApprovalPT();
			approvalpt.validate_teampage_details();
		}
		catch(Exception e)
		{
				e.printStackTrace();
			}
	}
	
	@When("User selects ExpandApprovals, Utilities and Transfer program")
	public void user_selects_expand_approvals_utilities_and_transfer_program() {
		try {
			approvalpt = new ApprovalPT();
			approvalpt.clickOnApprovalButton();
			approvalpt.click_on_utility();
			
		}
		  catch(Exception e)
				{
						e.printStackTrace();
					}
	}
	@Then("Transfer program should be open")
	public void transfer_program_should_be_open() {
		
		try {
			approvalpt = new ApprovalPT();
			//approvalpt.clickOnApprovalButton();
			//approvalpt.click_on_utility();
			approvalpt.click_on_transferprogram();
			
		}
		  catch(Exception e)
				{
						e.printStackTrace();
					}
	}
	    
	
	@Then("Transfer ProgramTransfer To fields should be displayed")
	public void transfer_program_transfer_to_fields_should_be_displayed() {
		try {
			approvalpt = new ApprovalPT();
			//approvalpt.clickOnApprovalButton();
			//approvalpt.click_on_utility();
			approvalpt.verifytransferprogramfields();
			
		}
		  catch(Exception e)
				{
						e.printStackTrace();
					}
	   
	}
	@When("User clicks on Cancel button with Transfer program")
	public void user_clicks_on_cancel_button_with_Transferprogram() {
		
		try {
			approvalpt = new ApprovalPT();
			//approvalpt.clickOnApprovalButton();
			//approvalpt.click_on_utility();
			approvalpt.clickOncancelbutton();
			
			
		}
		  catch(Exception e)
				{
						e.printStackTrace();
				}
	   
	   
	}
	@Then("Another pop up should open with {string}")
	public void another_pop_up_should_open_with(String string) {
		
		try {
			approvalpt = new ApprovalPT();
			//approvalpt.clickOnApprovalButton();
			//approvalpt.click_on_utility();
			
			approvalpt.clickOncancelpopup();
			
		}
		  catch(Exception e)
				{
						e.printStackTrace();
					}
	   
	}
	@When("User clicks Yes on pop up")
	public void user_clicks_yes_on_pop_up() {
	   
	}
	@Then("Pop up should close")
	public void pop_up_should_close() {
	   
	}
	

@When("User selects ExpandApprovals, Utilities and Transfer policy")
public void user_selects_expand_approvals_utilities_and_transfer_policy() {
	
	try {
		approvalpt = new ApprovalPT();
		approvalpt.clickOnApprovalButton();
		approvalpt.click_on_utility();
		
	}
	  catch(Exception e)
			{
					e.printStackTrace();
				}
}
    

@Then("Transfer policy should be open")
public void transfer_policy_should_be_open() {
	
	try {
		approvalpt = new ApprovalPT();
		//approvalpt.clickOnApprovalButton();
		//approvalpt.click_on_utility();
		approvalpt.click_on_transferpolicy();
		
	}
	  catch(Exception e)
			{
					e.printStackTrace();
				}
    
    
}
@Then("Client NameTransfer FromTransfer To fields should be displayed")
public void client_name_transfer_from_transfer_to_fields_should_be_displayed() {
	
	try {
		approvalpt = new ApprovalPT();
		//approvalpt.clickOnApprovalButton();
		//approvalpt.click_on_utility();
		approvalpt.verify_Transferpolicyfields();
		
	}
	  catch(Exception e)
			{
					e.printStackTrace();
				}
    
	
}

@When("User clicks on Cancel button with Transfer policy")
public void user_clicks_on_cancel_button_with_transfer_policy() {
 
	try {
		approvalpt = new ApprovalPT();
		//approvalpt.clickOnApprovalButton();
		//approvalpt.click_on_utility();
		approvalpt.clickOnCancelTransferpolicy();
		
	}
	  catch(Exception e)
			{
					e.printStackTrace();
				}
}


@Then("User clicks Yes on pop up and Pop up should close")
public void user_clicks_yes_on_pop_up_and_pop_up_should_close() {
	
	try {
		approvalpt = new ApprovalPT();
		//approvalpt.clickOnApprovalButton();
		//approvalpt.click_on_utility();
		
		approvalpt.clickOncancelpopup();
		
	}
	  catch(Exception e)
			{
					e.printStackTrace();
				}
   
    
}



	
	@After
	public void takescreenshot(Scenario scenario)
	{
		try
		{Utility.generateScreenshot(scenario);
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
