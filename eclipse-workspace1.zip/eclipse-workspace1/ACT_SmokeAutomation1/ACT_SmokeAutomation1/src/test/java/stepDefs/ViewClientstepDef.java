package stepDefs;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AllClientsPage;
import pages.Dashboard;


//formatting
public class ViewClientstepDef extends TestBase {
	
	Dashboard dashboard;
	
	AllClientsPage allclients;
	
@Given("Launch application")
public void launch_application() {
	
	try {
	initialize();
	Map<String, String> values = xmlfileReader();
	
	System.out.println("Root element name is: " + values);
	
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	
	
}
@Then("View Client details is displayed")
public void view_client_details_is_displayed() {
	
	try
	{
	
	dashboard =new Dashboard();
	
	dashboard.navigateToAllClients();
	Assert.assertTrue(dashboard.veifyAllClients());
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

@When("Client name is searched with expected Client Name {string}")
public void client_name_is_searched_with_expected_client_name(String clientname) {
    // Write code here that turns the phrase above into concrete actions
	
	try {
		allclients = new AllClientsPage();
	
	allclients.allClientsvalidation();
	
	allclients.applyClientNameFilter(clientname);
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
    
}
@Then("Client results should get displayed with client name {string}")
public void client_results_should_get_displayed_with_client_name(String clientname) {
    // Write code here that turns the phrase above into concrete actions
    
	try {
	allclients = new AllClientsPage();
	
	Assert.assertTrue(allclients.verifyClientFilterresults(clientname));
	
	//prop.setProperty("clientname", "Test123");
	
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
}

@After(order=1)
public void takescreenshot(Scenario scenario)
{
	try
	{Utility.generateScreenshot(scenario);
	
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
}

@After(order=2)
public void tearDownClass() {
    
}



}
