package stepDefs;


import java.util.List;
import java.util.Map;

import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AllClientsPage;
import pages.CreateProgramPage;
import pages.Dashboard;
import pages.HomePage;
import pages.ViewClient;

public class CreateProgramstepDef extends TestBase {
	
    HomePage homePage ;
    Dashboard dashboard;
	AllClientsPage allclients;
	Map<String, String> values = xmlfileReader();
	ViewClient client;
	CreateProgramPage createProgramPage;
	Utility utility;
	
	@Given("Launch the application")
	public void Launch_the_application() {
		
		try {
		initialize();
		//Map<String, String> values = xmlfileReader();
		
		//System.out.println("Root element name is: " + values);
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	@When("User is on home page")
	public void User_is_on_Home_page()
	{
	  try
	  {
		homePage = new HomePage();
	  	homePage.userOnHomePageValidation();
	  	
	  }
	  
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}  
	
	@When("User clicks On the All Clients")
	public void User_clicks_on_the_All_Clients()
	{
	  try
	  {
		  
	    dashboard = new Dashboard();
		dashboard.navigateToAllClients();
	  }
	  
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	  
	}

	@When("User search for The expected client name")
	public void User_search_for_the_expected_client_name()  
	{
		
		try 
		{
			allclients = new AllClientsPage();
			
			allclients.allClientsvalidation();
			
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			allclients.applyClientNameFilter(SPClientName);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	  
	
	}
	
	@Then("Expected client Name should display")
	public void Expected_client_name_should_display()
	{
		
		try {
			allclients = new AllClientsPage();
			
			//Assert.assertTrue(allclients.verifyClientFilterresults(clientname));
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			Assert.assertTrue(allclients.verifyClientFilterresults(SPClientName));
			
			//prop.setProperty("clientname", "Test123");
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Then("User clicks on the View client icon")
	public void User_clicks_on_the_View_client_icon()
	{
	   try
	   {
		   
		allclients= new AllClientsPage();
	    allclients.clickOnViewClient();
	   
	   }
	   
	   catch(Exception e)
	   {
			e.printStackTrace();
	   }
	   
	}
	
	@Given("User is on View client page")
	public void User_is_on_View_client_page() 
	{
	   try
	   {
		   
	    client = new ViewClient();
		client.viewClientValidation();
		Thread.sleep(3000);
	   }
	   
	   catch(Exception e)
	   {
			e.printStackTrace();
	   }
	}
	
	@When("User selects Add Program button")
	public void User_selects_Add_Program_button()
	{
	   try
	   {
		   
	    client = new ViewClient();
		client.clickOnAddProgramButton();
		
	   }
	   
	   catch(Exception e)
	   {
			e.printStackTrace();
	   }
	   
	}
	
	@Then("User is on Create Program page")
	public void User_is_on_Create_Program_page()
	{
	  try
	  {
		  
	    createProgramPage = new CreateProgramPage();
		createProgramPage.createProgramValidation();
		
	  }
		
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}
	
	
	@When("User fills the Program effective date")
	public void User_fills_the_Program_effective_date()
	{
	  try
	  {
		  
	    createProgramPage = new CreateProgramPage();
		createProgramPage.getTodayDate();
		createProgramPage.fillTodayDate();
	  }
	  
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	  
	}
	
	@When("User selects the Coverage group	EPL")
	public void User_selects_the_Coverage_group_EPL()
	{
	   try
	   {
		   
	    createProgramPage = new CreateProgramPage();
		createProgramPage.selectCoverage();
		
	   }
	   
	   catch(Exception e)
	   {
			e.printStackTrace();
	   }
	}
	
	@Then("User validates the Program name")	
	public void User_validates_the_Program_name()
	{
	  try
	  {
		createProgramPage = new CreateProgramPage();
		createProgramPage.validateProgramName();
		
	  }
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}

	@When("User fill all the details of EPL specific section")
	public void User_fill_all_the_details_of_EPL_specific_section(DataTable data)
	{
	  try
	  {
		  
	    List<List<String>> d = data.asLists();
		String A = d.get(0).get(0);
		String B = d.get(0).get(1);
		String C = d.get(0).get(2);
		String D = d.get(0).get(3);
		String E = d.get(0).get(4);
		String F = d.get(0).get(5);
		String G = d.get(0).get(6);
		String H = d.get(0).get(7);
	
		createProgramPage = new CreateProgramPage();
		createProgramPage.fillHeadCountAndUSValues(A,B);
		createProgramPage.fillFullTimeValues(C);
		createProgramPage.fillStateValues(D,E,F,G,H);
		
	  }
	  
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	  
		
	}
	@Then("User verify the sum of total state head count")
	public void User_verify_the_sum_of_total_state_head_count()
	{
	  try
	  {
		  
	    createProgramPage = new CreateProgramPage();
		createProgramPage.VerifyHeadCountAndUSNonUSValues();
		createProgramPage.verifyHeadCountAndFullPartTimeValues();
		createProgramPage.verifyUSAndStateValues();
		
	  }
	  
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	  
	}
	
	
	@Given("User validates the ARS and FSG office details")
	public void User_validates_the_ARS_and_FSG_office_details() 
	{
	   try
	   {
		   
	    createProgramPage = new CreateProgramPage();
		createProgramPage.verifyOfficeFields();
		
	   }
	   
	   catch(Exception e)
	   {
			e.printStackTrace();
	   }
	}
	
	@When("User select the Role and Employee name")
	public void User_select_the_Role_and_Employee_name()
	{
	  try
	  {
		  
	    createProgramPage = new CreateProgramPage();
		createProgramPage.selectRoleFields();
		createProgramPage.selectEmployeeFields();
		
	  }
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}
	
	@Then("User validates the sum of Productionpercentage")
	public void User_validates_the_sum_of_Productionpercentage(DataTable data)
	{
	  try
	  {
		  
	    List<List<String>> d = data.asLists();
		String A = d.get(0).get(0);
		String B = d.get(0).get(1);
		createProgramPage = new CreateProgramPage();
		createProgramPage.fillProductionPercentage(A,B);
		createProgramPage.verifyProductionPercentage();
		
	  }
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}
	
	@When("User click the Save button")
	public void User_click_the_Save_button()
	{
	  try
	  {
		createProgramPage = new CreateProgramPage();
		createProgramPage.clickOnSave();
	  }
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}
	
	@Then("User should validate pop up")
	public void user_should_validate_pop_up()
	{
	  try
	  {
		createProgramPage = new CreateProgramPage();
		createProgramPage.verifyPopup();
	  }
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}
	


	@After
	public void takescreenshot(Scenario scenario)
	{
		try
		{ 
			Utility.generateScreenshot(scenario);
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}  






