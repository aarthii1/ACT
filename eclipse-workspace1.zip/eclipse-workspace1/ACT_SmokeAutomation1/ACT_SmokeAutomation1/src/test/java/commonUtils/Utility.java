package commonUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import base.TestBase;
import io.cucumber.java.Scenario;


//adding timestamp with scenario
public class Utility extends TestBase {
	
	public static void generateScreenshot(Scenario scenario)
	{
		
		// Create object of SimpleDateFormat class and decide the format
		 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		 
		 //get current date time with Date()
		 Date date = new Date();
		 
		 // Now format the date
		 String date1= dateFormat.format(date);
		if(scenario.isFailed() || !(scenario.isFailed()))
		{
			TakesScreenshot screen = (TakesScreenshot) driver;
			File file =screen.getScreenshotAs(OutputType.FILE);
			byte[] imgByte;
			try {
				imgByte = FileUtils.readFileToByteArray(file);
				scenario.attach(imgByte, "image/png",scenario.getName()+date1 );
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	//This function return todaysDate in the format M/dd/YYYY Ex: 6/13/2022
	public String todaysDate() {
		
		Date thisDate = new Date();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("M/dd/YYYY");
		
		String datestamp = dateFormat.format(thisDate);
		
		return datestamp;
		
		
	}
	//This function updates the properties file with new value
	public void updateConfig(String key, String value, String updatePath) {
		prop =new Properties();
		String path = System.getProperty("user.dir")
				 + updatePath;
		FileOutputStream ops;
		
		try {
			
			
			 ops = new FileOutputStream(path);
			 
			 prop.setProperty(key, value);
			 
			 prop.store(ops, null);
			 
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//This function returns the client name which has been created by the create client feature.
	public String getClientName() {
		prop= new Properties();
		String path = System.getProperty("user.dir")
				 + "//src//test//resources//configFiles//clientname.properties";
		FileInputStream ips;
		try {
			ips = new FileInputStream(path);
			prop.load(ips);
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return prop.getProperty("clientname");
	}
	
	
}
