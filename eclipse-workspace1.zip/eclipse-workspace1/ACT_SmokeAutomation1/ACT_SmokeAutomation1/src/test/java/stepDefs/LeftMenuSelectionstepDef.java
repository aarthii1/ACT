package stepDefs;

import java.util.Map;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.LeftMenuSelection;

public class LeftMenuSelectionstepDef extends TestBase {
	
	LeftMenuSelection leftmenu;
	HomePage homepage;

	@Given("Launches ACT application")
	public void login_to_application() {
		try { 
			initialize();
			Map<String, String> values = xmlfileReader();
			
			System.out.println("Root element name is: " + values);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}		
	}
	
	@Then("Homepage displayed")
	public void home_page_is_displayed() {
		try
		{
			homepage = new HomePage();
			
			homepage.userOnHomePageValidation();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User clicks on the Views option")
	public void user_clicks_on_the_views_option() {
		try {
			leftmenu = new LeftMenuSelection();
			leftmenu.click_on_Views();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Then("User validates the pages under it")
	public void user_validates_the_pages_under_it() {
		try {
		leftmenu = new LeftMenuSelection();
		leftmenu.validate_pages_on_views();
		Thread.sleep(3000);
		 
		 closeAllBrowsers();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
	
	 @After
		public void takescreenshot(Scenario scenario)
		{
			try
			{Utility.generateScreenshot(scenario);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
}

