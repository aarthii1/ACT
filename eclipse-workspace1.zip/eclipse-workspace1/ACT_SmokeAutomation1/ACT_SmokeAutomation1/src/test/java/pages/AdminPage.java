package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class AdminPage extends TestBase{
	
WebElementActions webelementactions;

@FindBy(xpath="//span[text()='Admin Setups']")
WebElement Admin;

@FindBy(xpath="//a[text()='Aggregate Limit Types']")
WebElement Agg;

@FindBy(xpath="//h2[contains(text(),'Aggregate Limit Types')]")
WebElement Aggp;

@FindBy(xpath="//a[text()='Audit History']")
WebElement Audit;

@FindBy(xpath="//h2[contains(text(),'Audit History')]")
WebElement Auditp;

@FindBy(xpath="//a[text()='Cancellation Reasons']")
WebElement Cancellation;

@FindBy(xpath="//h2[contains(text(),'Cancellation Reasons')]")
WebElement Cancellationp;

@FindBy(xpath="//a[text()='Carrier Codes']")
WebElement Carrier;

@FindBy(xpath="//h2[contains(text(),'Carrier Codes')]")
WebElement Carrierp;

@FindBy(xpath="//a[text()='Carrier Groups']")
WebElement Carrierg;

@FindBy(xpath="//h2[contains(text(),'Carrier Groups')]")
WebElement Carriergp;

@FindBy(xpath="//a[text()='Competitor Brokers']")
WebElement Competitor;

@FindBy(xpath="//h2[contains(text(),'Competitor Brokers')]")
WebElement Competitionp;

@FindBy(xpath="//a[text()='Coverage Codes']")
WebElement Coverage;

@FindBy(xpath="//h2[contains(text(),'Coverage Codes')]")
WebElement Coveragep;

@FindBy(xpath="//a[text()='Coverage Groups']")
WebElement Coverageg;

@FindBy(xpath="//h2[contains(text(),'Coverage Group')]")
WebElement Coveragegp;

@FindBy(xpath="//a[text()='Coverage Specific Limits']")
WebElement Specificlim;

@FindBy(xpath="//h2[contains(text(),'Coverage Specific Limits')]")
WebElement Specificp;

@FindBy(xpath="//a[text()='Deductible Types']")
WebElement Deductible;

@FindBy(xpath="//h2[contains(text(),'Deductible Types')]")
WebElement Deductiblep;

@FindBy(xpath="//a[text()='Fee Types']")
WebElement Fee;

@FindBy(xpath="//h2[contains(text(),'Fee Types')]")
WebElement Feep;

@FindBy(xpath="//a[text()='FOS Countries']")
WebElement FOS;

@FindBy(xpath="//h2[contains(text(),'FoS Country')]")
WebElement FOSp;

@FindBy(xpath="//a[text()='FSG Offices']")
WebElement FSGo;

@FindBy(xpath="//h2[contains(text(),'FSG Offices')]")
WebElement FSGop;

@FindBy(xpath="//a[text()='FSG Teams']")
WebElement FSGT;

@FindBy(xpath="//h2[contains(text(),'FSG Teams')]")
WebElement FSGTp;

@FindBy(xpath="//a[text()='FSG Team Members']")
WebElement Teammember;

@FindBy(xpath="//h2[contains(text(),'FSG Team Members')]")
WebElement Teammemberp;

@FindBy(xpath="//a[text()='Intermediary Codes']")
WebElement Inter;

@FindBy(xpath="//h2[contains(text(),'Intermediary Codes')]")
WebElement Interp;

@FindBy(xpath="//a[text()='Parent Companies']")
WebElement Parent;

@FindBy(xpath="//h2[contains(text(),'Parent Company')]")
WebElement Parentp;

@FindBy(xpath="//a[text()='Regions']")
WebElement Region;

@FindBy(xpath="//h2[contains(text(),'Regions')]")
WebElement Regionp;

@FindBy(xpath="//a[@title='Benchmarking Request Log']")
WebElement Benchmarking;

@FindBy(xpath="//td[contains(text(),'BENCHMARKING REQUEST LOG')]")
WebElement Benchmarkingp;

@FindBy(id="ctl00_PlaceHolderMain_btnBack_input")
WebElement Back;

@FindBy(xpath="//a[text()='ARS Offices']")
WebElement ARS;
//
@FindBy(xpath="//h2[contains(text(),'ARS Offices')]")
WebElement ARSp;

@FindBy(xpath="//a[text()='FSG ACT']")
WebElement Home;

  public AdminPage() {
	try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
  
  public void click_on_Adminsetups() {
	  try {
		  webelementactions = new WebElementActions();
			webelementactions.doubleclick(Admin);
	  }
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Aggregate() {
	 try {
		// Agg.click();
		 webelementactions = new WebElementActions();
		 webelementactions.doubleclick(Agg); 
		 webelementactions.Explicitwait(Aggp);
	 }
	 catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Audit() {
	  try {
//		 Audit.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Audit); 
			 webelementactions.Explicitwait(Auditp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Cancellation() {
	  try {
	//	  Cancellation.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Cancellation); 
			 webelementactions.Explicitwait(Cancellationp);
	  }
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Carriercode() {
	  try {
	//	  Carrier.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Carrier); 
			 webelementactions.Explicitwait(Carrierp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Carriergp() {
	  try {
	//	  Carrierg.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Carrierg); 
			 webelementactions.Explicitwait(Carriergp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Carrierg() {
	  try {
		//  Agg.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Audit); 
			 webelementactions.Explicitwait(Auditp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Competitor() {
	  try {
//		  Competitor.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Competitor); 
			 webelementactions.Explicitwait(Competitionp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Coverage() {
	  try {
		//  Coverage.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Coverage); 
			 webelementactions.Explicitwait(Coveragep);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_ARS() {
	  try {
		//  Coverage.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(ARS); 
			 webelementactions.Explicitwait(ARSp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Coveragegroup() {
	  try {
	//	  Coverageg.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Coverageg); 
			 webelementactions.Explicitwait(Coveragegp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Specificlimit() {
	  try {
	//	 Specificlim.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Specificlim); 
			 webelementactions.Explicitwait(Specificp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Deductible() {
	  try {
	//	  Deductible.click();
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Deductible); 
			 webelementactions.Explicitwait(Deductiblep);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Fee() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Fee); 
			 webelementactions.Explicitwait(Feep);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_FOS() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(FOS); 
			 webelementactions.Explicitwait(FOSp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_FSG() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(FSGo); 
			 webelementactions.Explicitwait(FSGop);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_FSGTeams() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(FSGT); 
			 webelementactions.Explicitwait(FSGTp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Teammember() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Teammember); 
			 webelementactions.Explicitwait(Teammemberp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
 
  public void click_on_Interdatory() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Inter); 
			 webelementactions.Explicitwait(Interp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Parent() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Parent); 
			 webelementactions.Explicitwait(Parentp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Region() {
	  try {
		  
			 webelementactions = new WebElementActions();
			 webelementactions.doubleclick(Region); 
			 webelementactions.Explicitwait(Regionp);
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
  }
  
  public void click_on_Benchmarking() {
	  try {
		   Benchmarking.click();
		   webelementactions = new WebElementActions();
			 webelementactions.Explicitwait(Benchmarkingp);
			 Thread.sleep(1000);
			 Back.click();
			 Assert.assertTrue(Home.isDisplayed());
	  }
	  
	  catch(Exception e)
		{
			e.printStackTrace();
		}
	  }
  
}
