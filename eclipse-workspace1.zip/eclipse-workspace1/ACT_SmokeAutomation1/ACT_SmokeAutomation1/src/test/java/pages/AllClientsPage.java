package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class AllClientsPage extends TestBase {
	
	@FindBy(xpath="//input[contains(@name,\"FilterTextBox_ClientName\")]")
	WebElement ClientNametextbox;
	
	@FindBy(xpath="//input[contains(@name,\"FilterTextBox_CompanyStatus\")]")
	WebElement CompanyStatusfilter;
	
	@FindBy(xpath="//input[contains(@name,\"Filter_ClientName\")]")
	WebElement ClientNamefilter;
	
	@FindBy(xpath="//*[@id=\"ctl00_PlaceHolderMain_radGridClientList_ctl00__0\"]/td[2]")
	WebElement Clientnameresults;	

	@FindBy(xpath = "//img[contains(@id ,'ctl00_ctl04_imgClient')]")
	WebElement ViewClient;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_DBA')]")
	WebElement DBATextBox;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_FKA')]")
	WebElement FKATextBox;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_FSGOfficeName')]")
	WebElement FSGOfficeNameTextBox;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_FSGTeamName')]")
	WebElement FSGTeamNameTextBox;
	
	@FindBy(xpath="//tr[contains(@id,'radGridClientList_ctl00__0')]")
	WebElement ClientNameResult;
	
	@FindBy(xpath="//input[contains(@id,'ctl00_ctl04_GECBtnExpandColumn')]")
	WebElement ExpandClientNameResult;
	
	@FindBy(xpath="//tr[contains(@id,'ctl00_ctl06_radGridProgramList_ctl00__1')]")
	WebElement ProgramNameResult;
	
	@FindBy(xpath="//input[contains(@id,'ctl00_ctl06_radGridProgramList_ctl00_ctl07_GECBtnExpandColumn')]")
	WebElement ExpandProgramNameResult;
	
	@FindBy(xpath="//tr[contains(@id,'ctl00_ctl06_radGridProgramList_ctl00_ctl09_radGridPolicyList_ctl00__0')]")
	WebElement PolicyResult;
	
	@FindBy(xpath="//input[contains(@id,'ctl00_ctl06_radGridProgramList_ctl00_ctl09_radGridPolicyList_ctl00_ctl04_GECBtnExpandColumn')]")
	WebElement ExpandPolicyResult;
	
	@FindBy(xpath="//tr[contains(@id,'ctl00_ctl06_radGridProgramList_ctl00_ctl09_radGridPolicyList_ctl00_ctl06_radGridPremiumTransactionList_ctl00__0')]")
	WebElement TransactionResult;
	
	@FindBy(xpath="//img[@id='ctl00_onetidHeadbnnr2']")
	WebElement AonLogo;
	
	WebElementActions webeleactions;
	
public AllClientsPage() {
		try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}


public void allClientsvalidation()
{
	try {
		Assert.assertTrue(ClientNametextbox.isDisplayed());
	
	Assert.assertTrue(ClientNametextbox.isDisplayed());
	}
	
	catch(Exception e) {
		
		e.printStackTrace();
	}
}



public void applyClientNameFilter(String clientname)

{
	ClientNametextbox.sendKeys(clientname);
	ClientNamefilter.click();
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public boolean verifyClientFilterresults(String clientname)
{
	boolean flag= false;
	
	try
	{
	
	if ((Clientnameresults.getText()).contains(clientname))
		
		{System.out.println(Clientnameresults.getText());
	
		flag =true;
		}
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	return flag;
	
}


public void  clickOnViewClient()
{
	
	ViewClient.click();
	
}


public void allClientsFieldsvalidation()
{
	try {
		
	
	Assert.assertTrue(ClientNametextbox.isDisplayed());
	Assert.assertTrue(CompanyStatusfilter.isDisplayed());
	Assert.assertTrue(DBATextBox.isDisplayed());
	Assert.assertTrue(FKATextBox.isDisplayed());
	Assert.assertTrue(FSGOfficeNameTextBox.isDisplayed());
	Assert.assertTrue(FSGTeamNameTextBox.isDisplayed());
	}
	
	catch(Exception e) {
		
		e.printStackTrace();
	}
}

public void expandClientName() {
	try {
		Assert.assertTrue(ClientNameResult.isDisplayed());
		
		ExpandClientNameResult.click();
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

public void validationOfClientExpansion() {
	try {
		webeleactions = new WebElementActions();
		
		webeleactions.Explicitwait(ProgramNameResult);
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

public void expandProgramName() {
	try {
		Assert.assertTrue(ProgramNameResult.isDisplayed());
		
		ExpandProgramNameResult.click();
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

public void validationOfProgramNameExpansion() {
	try {
		webeleactions = new WebElementActions();
		
		webeleactions.Explicitwait(PolicyResult);
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

public void expandPolicy() {
	try {
		Assert.assertTrue(PolicyResult.isDisplayed());
		
		ExpandPolicyResult.click();
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

public void validationOfPolicyExpansion() {
	try {
		webeleactions = new WebElementActions();
		
		webeleactions.Explicitwait(TransactionResult);
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

public void click_on_aon_logo() {
	try {
		
		AonLogo.click();
		
		Thread.sleep(5000);
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}



}
