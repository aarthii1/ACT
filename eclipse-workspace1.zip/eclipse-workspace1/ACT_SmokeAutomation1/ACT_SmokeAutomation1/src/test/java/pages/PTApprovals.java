package pages;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class PTApprovals extends TestBase {
	
	WebElementActions webelementactions;
	AllClientsPage allClientsPage;
	Dashboard dashboard;
	@FindBy(xpath = "//span[text() = 'Approvals']")
	WebElement approvalButton;
	
	@FindBy(xpath = "//span[text() = 'Pending Approvals']")
	WebElement pendingApprovalButton;
	
	@FindBy(xpath = "//a[text() = 'PT Approvals']")
	WebElement PTApprovalButton;
	
	@FindBy(xpath = "//h2")
	WebElement Header;
	
	@FindBy(xpath = "//div[contains(@id , 'PendingForApprovalHeader_GridData')]/table/tbody/tr/td[3]")
	List<WebElement> programNames;
	
	@FindBy(xpath = "//input[contains(@id , '_ctl00_ctl04_GECBtnExpandColumn')]")
	WebElement expandButton;
	
	@FindBy(xpath = "//a[@title ='View Transaction']")
    WebElement viewTransaction;
	
	@FindBy(xpath = "//h2")
	WebElement headerPendingApproval;
	
	@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr[1]")
	WebElement clientProgramPolicyRow;
	
	@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr/td[1]")
	WebElement clientName;
	
	@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr/td[3]")
	WebElement programName;
	
	@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr/td[5]")
	WebElement policyNo;
	
	@FindBy(xpath = "//span[text()='Policy Details']")
	WebElement policyDetail;
	
	@FindBy(xpath = "//span[text()='Policy Information']")
	WebElement policyInformation;
	
	@FindBy(xpath = "//span[contains(@id , '_i0_lblClientName')]")
	WebElement policyInformationclientName;
	
	@FindBy(xpath ="//table[contains(@id , 'pbPolicy_i0_tblPolicy')]/tbody/tr[2]/td[2]/span")
	WebElement policyInformatioProgramName;
	
	@FindBy(xpath = "//table[contains(@id , 'pbPolicy_i0_tblPolicy')]/tbody/tr[2]/td[5]/div/span")
	WebElement policyInformatioPolicyNo;
	
	@FindBy(xpath = "//span[text()='Premium Transaction Details']")
	WebElement premiumTransactionDetails;
	
	@FindBy(xpath = "//span[text()='Premium Transaction']")
	WebElement premiumTransaction;
	
	@FindBy(xpath = "//span[contains(@id , 'i0_lblTransactionTypeValue')]")
	WebElement transactionType;
	
	@FindBy(xpath = "//input[contains(@id , 'radbtnApproveTop_input')]")
	WebElement approveButton;
	
	@FindBy(xpath = "//input[contains(@id , 'radbtnEditTop_input')]")
	WebElement editButton;
	
	@FindBy(xpath = "//input[contains(@id , 'radbtnCancelTop_input')]")
	WebElement cancelButton;
	
	@FindBy(xpath = "//input[contains(@id , 'radbtnDisApproveTop_input')]")
	WebElement disApproveButton;
	
	@FindBy(xpath = "//span[text() = 'View/Search']")
	WebElement viewSearchButton;
	
	@FindBy(xpath = "//span[text() = 'Premium Transactions View']")
	WebElement premiumTransactionViewButton;
	
	@FindBy(xpath = "//a[text() = 'Approved']")
	WebElement approvedButton;
	
	@FindBy(xpath = "//h2")
	WebElement approvedPage;
	
	@FindBy(xpath = "//input[contains(@id , 'ctl00_ctl06_radGridPTViewPolicyHeader_ctl00_ctl04_GECBtnExpandColumn')]")
	WebElement expandApprovedTransactionClient;
	
	@FindBy(xpath = "//h2")
	WebElement headerViewTransactionPage;
	
	@FindBy(xpath = "//span[contains(@id , 'RadPanelBar1_i0_lblPolicyNumberValue')]")
	WebElement policyNoViewTransactionPage;
	
	@FindBy(xpath = "//span[text() = 'Approval Details']")
	WebElement approvalDetails;
	
	@FindBy(xpath = "//span[contains(@id , 'RadPanelBar1_i3_lblApprivalStatusValue')]")
	WebElement approvedStatus;
	
	
	@FindBy(xpath = "//span[contains(@id , 'RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl04_lblCoverageID')]")
	WebElement CCRCoverage;
	
	@FindBy(xpath = "//tr[contains(@id , 'ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00__0')]/td[2]")
	WebElement clientPendingApprovals;
	
	@FindBy(xpath = "//th[text() = 'Attachments']")
	WebElement attachment;
	
	@FindBy(xpath = "//span[text() = 'Contact and Account Service Team']")
	WebElement contactAndAccountService;
	
    @FindBy(xpath = "//input[contains(@id , 'FilterTextBox_TeamName')]")
	 WebElement teamNameFilterBox;
	 
	 @FindBy(xpath = "//input[contains(@id , 'ctl00_ctl02_ctl02_RDIFPolicyExpiryDate_text')]")
	 WebElement expDateFilterBox;
	
	 @FindBy(xpath = "//input[contains(@name,'Filter_TeamName')]")
     WebElement filterTeamName;
	 
	 @FindBy(xpath = "//input[contains(@name,'Filter_PolicyExpiryDate')]")
     WebElement filterExpDate;
	 
	//WebElement for Expand All
		
	//input#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl02_ctl00_radbtnExpandAll_input
		
		@FindBy(css="input#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl02_ctl00_radbtnExpandAll_input")
		WebElement ExpandAll;
		
		@FindBy(xpath="//h2[contains(text(),'Approvals')]")
		WebElement Approvalsheader;
		
		//WebElement ClientnameFilterBox
		@FindBy(css="input#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl02_ctl03_FilterTextBox_ClientName")
		WebElement ClientNameFilterbox;
		
		//WebElement ClientnameFilter contains
		@FindBy(css="input#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl02_ctl03_Filter_ClientName")
		WebElement ClientNameFilter;

		//WebElement viewTransaction
		@FindBy(css="a#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl06_radGrdDetails_ctl00_ctl05_lnkPremiumTransaction")
		WebElement ViewTransaction;
		
		//WebElement CLientName FirstRow
		@FindBy(css="span#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl04_lblClientName")
		WebElement clientFirstRow;
		
		//WebElement for Pending 
		@FindBy(xpath="//h2[contains(text(),'Pending Approval')]")
		WebElement Pendingheader;
		
		//Disapprove button
	    @FindBy(css="input#ctl00_PlaceHolderMain_radbtnDisApproveTop_input")
	    WebElement disapprovebutton;
	    
	    //Disapprove out of order
	    @FindBy(css="a#ctl00_PlaceHolderMain_ucMsgBoxPTConfirmation_rwMessageBox_C_butOk")
	    WebElement disapproveOkpopup;
	          
	    //Cancel button
	    @FindBy(css="input#ctl00_PlaceHolderMain_radbtnCancelTop_input")
	    WebElement cancelbutton;
	    
	    //Contacts Team section
	    @FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_rpbPTDetails_i0_rpbApproval']//span[contains(text(),'Account Service Team')]")
	    WebElement ContactsTeam;
	    
	    //FSG Team Name
	    @FindBy(css="span#ctl00_PlaceHolderMain_rpbPTDetails_i0_rpbApproval_i2_lblFSGProgramTeamNameValue")
	    WebElement FSGTeamname;
	    
	    //Policy Label value
	    @FindBy(css="span#ctl00_PlaceHolderMain_rpbucViewPolicy_i0_ucViewPolicyControl_rpbPolicy_i0_lblPolicyNumber")
	    WebElement Policyvalue;
	    
	    //Expiration date label value
	    @FindBy(css="span#ctl00_PlaceHolderMain_rpbucViewPolicy_i0_ucViewPolicyControl_rpbPolicy_i0_lblPolicyExpirationDate")
	    WebElement expdatevalue;
	    
	    //Program name label value
	    @FindBy(css="span#ctl00_PlaceHolderMain_rpbucViewPolicy_i0_ucViewPolicyControl_rpbPolicy_i0_lblProgramName")
	    WebElement progname;
	   
	    @FindBy(xpath="//span[text() = 'EqualTo']")
	    WebElement equaltofilter;
	    
	 
	 public PTApprovals ()
		{
			try
			{
			PageFactory.initElements(driver, this);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		 }
	
	
       
	 public void clickOnApprovalButton()
		{
			try
			{
				webelementactions = new WebElementActions();
				webelementactions.doubleclick(approvalButton);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		 }
	
	 public void clickOnPendingApprovalButton()
		{
			try
			{
				webelementactions = new WebElementActions();
				webelementactions.doubleclick(pendingApprovalButton);
			    PTApprovalButton.click();
			}
			
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		 }
	 
	
	 
	 public void verifyApprovalPage()
		{
			try
			{
				
					
				    Assert.assertTrue(Header.isDisplayed());
				    
				
					
					
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	
	 
	 
	 public void clickExpand()
		{
			try
			{ 
				
				
				expandButton.click();
				//expandButton.click();
				//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
				//wait.until(ExpectedConditions.elementToBeClickable(viewTransaction));
				
				
                //JavascriptExecutor jse = (JavascriptExecutor) driver;
				
				//jse.executeScript("arguments[0].click()",viewTransaction);
				//viewTransaction.click();
					
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	 public void verifyClientDetailsPage()
		{
			try
			{
				
					
				   // Assert.assertTrue(headerPendingApproval.isDisplayed());
				    
				    Assert.assertTrue(clientProgramPolicyRow.isDisplayed());
				    Assert.assertTrue(policyInformation.isDisplayed());
				    Assert.assertTrue(policyDetail.isDisplayed());
                    Thread.sleep(5000);
				 
			    
				
					
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	 public void verifyClientDetails()
		{
			try
			{
				
				//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
				//wait.until(ExpectedConditions.visibilityOf(policyInformatioProgramName));
				
				Assert.assertEquals(clientName.getText(),policyInformationclientName.getText());
				Assert.assertEquals(programName.getText(),policyInformatioProgramName.getText());
				Assert.assertEquals(policyNo.getText(),policyInformatioPolicyNo.getText());
				
				
				
					
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	 public void verifyTransactionDetails()
		{
			try
			{
				
				
				
				 premiumTransactionDetails.isDisplayed();
				 premiumTransaction.isDisplayed();
				 
				 Assert.assertTrue(transactionType.getText().equalsIgnoreCase("New Business") || transactionType.getText().equalsIgnoreCase("Endorsement") || transactionType.getText().equalsIgnoreCase("Extension"));
				 
				 Assert.assertTrue(approveButton.isDisplayed());
				 Assert.assertTrue(editButton.isDisplayed());
				 Assert.assertTrue(cancelButton.isDisplayed());
				 Assert.assertTrue(disApproveButton.isDisplayed());
				
				 
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}


	 public void clickApproveButton()
		{
			try
			{
				Thread.sleep(3000);
				approveButton.click();
				Thread.sleep(3000);
				
				
		    }	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
 
	 public void approvedTransactionPage()
	{
			try
			{
				
				webelementactions = new WebElementActions();
				webelementactions.doubleclick(viewSearchButton);
				webelementactions.doubleclick(premiumTransactionViewButton);
				webelementactions.doubleclick(approvedButton);
				Assert.assertTrue(approvedPage.isDisplayed());
				Thread.sleep(4000);
				
				
		    }	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	 public void expandCompanyOnApprovedTransactionPage()
	 {
			try
			{
				expandButton.click();
				
				Thread.sleep(4000);				
		    }	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
      }        

	 public void expandClientOnApprovedTransactionPage()
	 {
			try
			{
				
				expandApprovedTransactionClient.click();
				Thread.sleep(4000);
				
               //JavascriptExecutor jse = (JavascriptExecutor) driver;
				
				//jse.executeScript("arguments[0].click()",viewTransaction);
				
				
				//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
			//	wait.until(ExpectedConditions.elementToBeClickable(viewTransaction));
				//viewTransaction.click();
				
				// JavascriptExecutor jse = (JavascriptExecutor) driver;
					
				//	jse.executeScript("arguments[0].click()",viewTransaction);
					
		    }	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
      }        

	 public void viewTransactionAfterClientExpand()
	 {
			try
			{
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
				wait.until(ExpectedConditions.elementToBeClickable(viewTransaction));
				
				viewTransaction.click();
		    }	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
      }   
	 
	 
	 public void verifyViewTransactionPage()
	 {
			try
			{
				
				
				Assert.assertTrue(headerViewTransactionPage.isDisplayed());
				Assert.assertTrue(clientProgramPolicyRow.isDisplayed());
				Assert.assertTrue(clientName.isDisplayed());
				Assert.assertTrue(programName.isDisplayed());
				Assert.assertTrue(premiumTransaction.isDisplayed());
				Assert.assertTrue(transactionType.getText().equalsIgnoreCase("New Business") || transactionType.getText().equalsIgnoreCase("Endorsement") || transactionType.getText().equalsIgnoreCase("Extension"));
				Assert.assertTrue(policyNoViewTransactionPage.isDisplayed());
				
				JavascriptExecutor jse = (JavascriptExecutor) driver;

				 jse.executeScript("arguments[0].scrollIntoView()",approvedStatus);
				
				Assert.assertTrue(approvedStatus.isDisplayed()); 
				Assert.assertTrue(approvedStatus.getText().equalsIgnoreCase("Approved"));
			    
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
      }        

  /*	 public boolean verifyClientFilterresultsPendingApproval(String clientname)
	 {
	 	boolean Flag = false;
	 	
	 	
	 	try
	 	{
	 		Thread.sleep(3000);
	 	    String text = clientPendingApprovals.getText();
	 		System.out.println(text);
	 	if ((clientPendingApprovals.getText()).contains(clientname))
	 		
	 		{System.out.println(clientPendingApprovals.getText());
	 	
	 		Flag = true;
	 		}
	 	
	 	}
	 	
	 	catch(Exception e)
	 	{
	 		e.printStackTrace();
	 	}
	 	return Flag;
	 	
	 	
	 	
	 }

	*/

	
	    public void fillCompanyAndFilter(String team)
	    {
			
	    	    	
	    	try
	    	{
	    	     
	    	    teamNameFilterBox.sendKeys(team);
	    	    filterTeamName.click();
	    	    Thread.sleep(7000);
	    	    
	    		
	    		
	    	}
	    	
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    		
	    	}
	    	
	    }	
	    	 public void fillexpdateAndFilter(String expDate)
	 	    {
	 			
	 	    	    	
	 	    	try
	 	    	{
	 	    	       
	 	    		expDateFilterBox.sendKeys(expDate);
	 	    		
	 	    		Thread.sleep(5000);
	 	    		filterExpDate.click();
	 	    		Thread.sleep(5000);
	 	    		filterExpDate.click();
	 	    		Thread.sleep(5000);
	 	    		equaltofilter.click();
	 	    		Thread.sleep(5000);
	 	    	}
	 	    	
	 	    	catch(Exception e)
	 	    	{
	 	    		e.printStackTrace();
	 	    		
	 	    	}
	 	    	
	    		
	    	
	    }
		/*
		  public void applyFilterPTapprovals(String clientname)
		    {
		    	
		    	webelementactions =new WebElementActions();
		    	try
		    	{
		    		
		    		
		    		System.out.println("PT approvals");
//		    		
		         Thread.sleep(2000);
//		    		
		//
//		    		ClientNameFilterbox.sendKeys("dishatest");
//		    		
//		    		ClientNameFilter.click();
//		    	
		    	
		    	webelementactions.applyFilter(ClientNameFilterbox, ClientNameFilter,clientname);
		    	Thread.sleep(1000);
		    	ExpandAll.click();
		    	}
		    	
		    	catch(Exception e)
		    	{
		    		e.printStackTrace();
		    	}
		    	
		    }
		    
		 */
		    public boolean clientresultsValidation(String Clientname)
		    {    
		    	
		    	return(clientFirstRow.getText().contains(Clientname));
		    }
		    
		    public void clickonViewTransaction()
		    {
		        try
		        {
		        	
		        	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
					wait.until(ExpectedConditions.elementToBeClickable(ViewTransaction));	
		    	ViewTransaction.click();
		    	
		    	Pendingheader.isDisplayed();
		    	
		    	
		        }
		        
		        catch(Exception e)
		        {
		        	e.printStackTrace();
		        }
		    	
		    	
		    }
		    
		    
		   // public HashMap<String, String> retrieveTransactiondetails()
		    public void retrieveTransactiondetails()
		    {
				//HashMap<String, String> trans= new HashMap<String, String>(); 
		    	    	
		     try{
		    	
		    	 
				// disapprovebutton.isDisplayed();
		    	    	
				// cancelbutton.isDisplayed();
		    	
		    	 transdetails.put("Expiration date",expdatevalue.getText().trim());
		    	
		    	 transdetails.put("Program name",progname.getText().trim());
		    	
		    	 transdetails.put("Policy number",Policyvalue.getText().trim());
		    	
		    	 JavascriptExecutor jse = (JavascriptExecutor) driver;
				  
				 jse.executeScript("arguments[0].scrollIntoView()", ContactsTeam);
				
				 transdetails.put("Team name",FSGTeamname.getText().trim());
		    	
		    	}
		    	
		    	catch(Exception e)
		    	{e.printStackTrace();
		    		
		    	}
		    	
		    	
		    		
		    	
		    }
			
			
			public void clickonDisapprovebutton()
			{
				try
				{
				disapprovebutton.click();
				
				if (disapproveOkpopup.isDisplayed())
				
				disapproveOkpopup.click();
				
				Approvalsheader.isDisplayed();
				}
				
				catch(Exception e)
		    	{e.printStackTrace();
		    		
		    	}
		    	
		    	
			}
			
			
			


		
}







