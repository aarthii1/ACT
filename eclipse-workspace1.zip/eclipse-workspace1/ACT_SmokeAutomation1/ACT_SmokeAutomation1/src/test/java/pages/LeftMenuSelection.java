package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class LeftMenuSelection extends TestBase {
	
WebElementActions webelementactions;
	
@FindBy(xpath="//span[text()='Views']")
WebElement Views;

@FindBy(xpath="//a[text()='Premiums by Revenue']")
WebElement Premium1;

@FindBy(xpath="//a[text()='Premiums by Team']")
WebElement Premium2;

@FindBy(xpath="//a[text()='Premiums by Team/Client']")
WebElement Premium3;

@FindBy(xpath="//a[text()='Pending PT by Revenue']")
WebElement Premium4;

@FindBy(xpath="//a[text()='Pending PT by Revenue']")
WebElement Premium5;

@FindBy(xpath="//a[text()='Pending PT by Team/Client']")
WebElement Premium6;

@FindBy(xpath="//a[text()='Approved PT by Date']")
WebElement Premium7;

@FindBy(xpath="//h2[contains(text(),'Commissions by Revenue Year/Month and Revenue')]")
WebElement Premiumpage1;

@FindBy(xpath="//h2[contains(text(),'Commissions by Team, Revenue Year/Month and Revenue Type')]")
WebElement Premiumpage2;

@FindBy(xpath="//h2[contains(text(),'Total Premiums and Commissions by Team/Client')]")
WebElement Premiumpage3;

@FindBy(xpath="//h2[contains(text(),'Revenue Type for pending Premium Transactions')]")
WebElement Premiumpage4;

@FindBy(xpath="//h2[contains(text(),'Revenue Year/Month and Revenue Type for pending Premium Transactions')]")
WebElement Premiumpage5;

@FindBy(xpath="//h2[contains(text(),'Total Premiums and Commissions by Team/Client, Revenue Year/Month')]")
WebElement Premiumpage6;

@FindBy(xpath="//h2[contains(text(),'Approved Premium Transaction by Date')]")
WebElement Premiumpage7;

public LeftMenuSelection() {
	try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
}

public void click_on_Views() {
	try {
		webelementactions = new WebElementActions();
		webelementactions.doubleclick(Views);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

public void validate_pages_on_views() {
	try {
		webelementactions = new WebElementActions();
		Premium1.click();
		webelementactions.Explicitwait(Premiumpage1);
		Premium2.click();
		webelementactions.Explicitwait(Premiumpage2);
		Premium3.click();
		webelementactions.Explicitwait(Premiumpage3);
		Premium4.click();
		webelementactions.Explicitwait(Premiumpage4);
		Premium5.click();
		webelementactions.Explicitwait(Premiumpage5);
		Premium6.click();
		webelementactions.Explicitwait(Premiumpage6);
		Premium7.click();
		webelementactions.Explicitwait(Premiumpage7);
	
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}


}
