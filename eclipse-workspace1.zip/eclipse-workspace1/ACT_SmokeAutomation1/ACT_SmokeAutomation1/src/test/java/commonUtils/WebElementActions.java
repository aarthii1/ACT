package commonUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import base.TestBase;


//try and catch with parameter
public class WebElementActions extends  TestBase {
	
	/***********************************************/	
	/*ModuleName: void doubleclick
	Parameters: Element
	Description: This function has no return value
	/*************************************************/ 
	
	public void doubleclick(WebElement element)
	{
       try 
       {Actions action = new Actions(driver);
		
		action.doubleClick(element).perform();
		
		element.click();
	   }
       
       catch(Exception e)
       {
    	   e.printStackTrace();
       }
	}
	
	
	/***********************************************/	
	/*ModuleName: void Implicit wait
	Parameters: Time
	Description: This function has no return value
	/*************************************************/ 
	// catch --thread.sleep
	public void implicitwait (int time)
	{
		try
		{
			driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
		}
		
		catch(Exception e)
	       {
	    	   e.printStackTrace();
	       }
	}
	// catch --thread.sleep
		
	/***********************************************/	
	/*ModuleName: void Explicit swait
	Parameters: Element
	Description: This function has no return value
	/*************************************************/ 
	
	public boolean Explicitwait(WebElement element) {
		
			WebElement element1 = null;
	  try 
	  {
		
		WebDriverWait wait = new WebDriverWait(driver, 20);
		
		element1=wait.until(ExpectedConditions.visibilityOf(element));
		
		//return(element1.isDisplayed());
		
	  }
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		
		
	  return(element1.isDisplayed());
		
	}
	
/***********************************************/	
/*ModuleName: void selectDropdown
Parameters: WebElement element,String propertyval,String value
Description: This function has no return value
/*************************************************/ 
	public void selectDropdown(WebElement element,String propertyval,String value)
	{
		
		try
		{
			int val , temp=0;
		
		Select sel =new Select(element);
		   
		
		String propertyval1 =propertyval.toUpperCase();
//		
//		System.out.println(element.getText());
//		
//		System.out.println(propertyval);
//		
//		System.out.println(value);
		
		
		if (propertyval1.equals("VISIBLETEXT"))
				temp =1;
		else
			if (propertyval1.equals("VALUE"))
				
				temp =2;
		else
			if (propertyval1.equals("INDEX"))
				
				temp =3;		
			
		
	 
		 switch(temp)
		{
			case 1 :
				sel.selectByVisibleText(value);
				break;
				
			case 2:
				sel.selectByValue(value);
				break;
				
			case 3:
				val = Integer.parseInt(value);
				sel.selectByIndex(val);
				break;
		}
		 
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
/***********************************************/	
/*ModuleName: void selectCombobox
Parameters: WebElement dropdown, List <WebElement> dropdownvalues, String value
Description: This function has no return value
/*************************************************/ 
	
	public void selectCombobox(WebElement dropdown, List <WebElement> dropdownvalues, String value)
	{
		try{
			
			
			dropdown.click();
			
			Thread.sleep(3000);
		
			
		  //List<WebElement> allOptions = dropdownvalues; 
	        //System.out.println(allOptions.size());
	         
	             // send keys and  webelement click     
	                 
	        for(int i = 0; i<=dropdownvalues.size()-1; i++) {
	             
	             //System.out.println(dropdownvalues.get(i).getText());
	             
	            if(dropdownvalues.get(i).getText().contains(value)) {
	                 
	            	dropdownvalues.get(i).click();
	                break;
	                 
	            }
	        }
		}
	        
	        catch(Exception e)
	  	  {
	  		  e.printStackTrace();
	  	  }
	        
	}
		
/***********************************************/	
/*ModuleName: void applyFilter
Parameters: WebElement filterbox,WebElement filter,String filtervalue
Description: This function has no return value
/*************************************************/ 
		
	public void  applyFilter(WebElement filterbox,WebElement filter,String filtervalue)
	{  try
	  {
		filterbox.sendKeys(filtervalue);
		
		filter.click();
	  }
	
	  catch(Exception e)
	{
		  e.printStackTrace();
	}
	}
	
/***********************************************/	
/*ModuleName: void applyFilterResults
Parameters: WebElement Results,String filtervalue
Description: This function has boolean return value
/*************************************************/  
	public boolean applyFilterResults(WebElement Results,String filtervalue)
	{
		
		//String value;	
		
		//shld handle null pointer or empty
		
	    boolean flag = false;
		try {
		String value=Results.getText();
		
		if (value.contains(filtervalue))
		
			flag= true;
		
		else
			
			flag= false;
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
	}
	
	
/***********************************************/	
/*ModuleName: int columnnoRetrival
Parameters: Column Headers,Column Name
Description: This function returns column number*/
/*************************************************/	
		
	public int columnnoRetrival(List<WebElement>colHeader,String colName)
	{
		
		int colno =0 ;
		
		try
		{
		
		for (int i=1;i<colHeader.size();i++)
		  {
			  if (colHeader.get(i).getText().contains(colName))  
			  
			  {
                  colno =i;
                  
                  break;

			  }
			  
		  }
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		return colno;
		
	}
	
/**************************************************************************************/	
/*ModuleName: void  clickOnTableWebelement
Parameters: int Filtervalue,String xpathtoClick,String tablexpath,String expectedfiltervalue
Description: This function clicks the WebElement on the specific row where filter value matches 
/**************************************************************************************/	
		

		
		public void clickOnTableWebelement(int colnumfiltervalue,String xpathtoClick,String tablexpath,String expectedfiltervalue)
		{
			String temp=tablexpath;
			
			//List<WebElement> eleRows =  driver.findElements(By.xpath(temp));
			
			//int Rowcount= eleRows.size();
			
			try
			{
			
			int Rowcount = driver.findElements(By.xpath(temp)).size();
			
				for(int i=1;i<Rowcount;i++)
			  {
				 
				 WebElement ele1=driver.findElement(By.xpath(temp+"["+ (i) +"]/td["+colnumfiltervalue+"]"));
				 
				 	
				 if ((ele1.getText()).contains(expectedfiltervalue))
				 {
					 
					 driver.findElement(By.xpath("("+temp+")"+"["+ (i) +"]"+xpathtoClick)).click();
					 
					 break;
					 
				 }
				 
			  }
			}
				
			catch(Exception e) {
				e.printStackTrace();
			}	  
				  
			  }
			
/*
 * ModuleName:void isValuePresentinTxtBx
 * Parameters:WebElement element
 * Description: This function checks the text box and returns True if it is not empty.
 */
		public void isValuePresentinTxtBx(WebElement element)
		{
	       try 
	       {
	    	   
	    	   
	    	   String value = element.getAttribute("value");
	    	   
	    	  // System.out.println(value);
	    	   
	    	   Assert.assertFalse(value.isEmpty());
	    	   
		   }
	       
	       catch(Exception e)
	       {
	    	   e.printStackTrace();
	       }
		
		}
		
				
		
/*DatePicker function
 * This function will select the first date which is available in the calendar
 * WebElement calBtn - We need to provide the element of the calendar icon
 * List <WebElement> calDates - We need to provide the list of dates available.
 * */
		
		public void datePickerSelection(WebElement calBtn, List<WebElement> calDates) {
			try {
				calBtn.click();
				
				
				for(WebElement date: calDates) {
						
						date.click();
						Thread.sleep(5000);
						return;
					}
				
				
				}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
/*
 * This function returns true if the element is present in the web page and returns false if not present
 * We need to pass the xpath of the element to the function  
 */
	public boolean isElementPresent(String xpath) {
		try {
			driver.findElement(By.xpath(xpath));
		}
		catch(NoSuchElementException e) {
			return false;
		}
		return true;

					}

	}


		

	

