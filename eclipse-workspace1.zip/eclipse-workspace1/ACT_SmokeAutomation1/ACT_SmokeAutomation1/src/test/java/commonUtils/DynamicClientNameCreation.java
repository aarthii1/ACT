package commonUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.openqa.selenium.support.PageFactory;

import base.TestBase;


public class DynamicClientNameCreation extends TestBase{
	
	 Map<String,String> values = xmlfileReader();
	 String initialClientName = values.get("name");
	 
	
	public String clientname() {
	
		
		Date thisDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMddYYhhmmss");
        
        String datetimestamp = dateFormat.format(thisDate);
        
        String finClientName = initialClientName + datetimestamp;
       
        
        return finClientName;
        }
	
			
}
