package stepDefs;

import java.util.List;

import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;
import pages.AllClientsPage;
import pages.CreateProgramPage;
import pages.Dashboard;
import pages.HomePage;
import pages.SignOut;
import pages.ViewClient;
import io.cucumber.java.*;
import io.cucumber.java.en.*;
import io.cucumber.datatable.DataTable;

public class AllClientsstepDef extends TestBase{
	HomePage homepage;
	Dashboard dashboard;
	AllClientsPage allclients;
	WebElementActions webeleactions;
	ViewClient client;
	CreateProgramPage createprogrampage;
	SignOut signout;
	
	@Given("User Launch the ACT application")
	public void user_launch_the_act_application() {
		try {
			initialize();
			
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}

	}
	@Then("User validates the Home page")
	public void user_validates_the_home_page() {
		  try {
		    	homepage = new HomePage();
		    	homepage.userOnHomePageValidation();
		    }
		    
		    catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Given("User chooses the All Clients option")
	public void user_chooses_the_all_clients_option() {
		try {
			dashboard = new Dashboard();
			dashboard.navigateToAllClients();
			dashboard.veifyAllClients();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Then("User verify all the fields in All Clients")
	public void user_verify_all_the_fields_in_all_clients() {
		try {
			allclients = new AllClientsPage();
			
			allclients.allClientsFieldsvalidation();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks plus button to expand a client")
	public void user_clicks_plus_button_to_expand_a_client() {
		try {
			allclients = new AllClientsPage();
			allclients.expandClientName();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Client gets expanded")
	public void client_gets_expanded() {
		try {
			allclients = new AllClientsPage();
			allclients.validationOfClientExpansion();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks plus button to expand a program")
	public void user_clicks_plus_button_to_expand_a_program() {
		try {
			allclients = new AllClientsPage();
			allclients.expandProgramName();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Program gets expanded")
	public void program_gets_expanded() {
		try {
			allclients = new AllClientsPage();
			allclients.validationOfProgramNameExpansion();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks plus button to expand a policy")
	public void user_clicks_plus_button_to_expand_a_policy() {
		try {
			allclients = new AllClientsPage();
			allclients.expandPolicy();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Policy should get expanded with Premium Transactions")
	public void policy_should_get_expanded_with_premium_transactions() {
		try {
			allclients = new AllClientsPage();
			allclients.validationOfPolicyExpansion();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User navigates to the Home page")
	public void user_navigates_to_the_home_page() {
		try {
			allclients = new AllClientsPage();
			
			allclients.click_on_aon_logo();
			
			Thread.sleep(4000);
			
			homepage = new HomePage();
	    	homepage.userOnHomePageValidation();
			
	    	dashboard = new Dashboard();
	    	dashboard.navigateBackToClientView();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	@Then("User selects client name {string} and click View Client")
	public void user_selects_client_name_and_click_view_client(String clientname) {
		try {
			allclients = new AllClientsPage();
		    allclients.applyClientNameFilter(clientname);
		   
		    Thread.sleep(4000);
		    
		    Assert.assertTrue(allclients.verifyClientFilterresults(clientname));
		    
		    allclients.clickOnViewClient();
		    
		    Thread.sleep(5000);
		    
		    client = new ViewClient();
		    client.viewClientValidation();
		    
		   
		    
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks on Add program")
	public void user_clicks_on_add_program() {
		try {
			client = new ViewClient();
			client.clickOnAddProgramButton();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Create Program should open")
	public void create_program_should_open() {
		try {
			  createprogrampage = new CreateProgramPage();
			  createprogrampage.createProgramValidation();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User fills all the mandatory fields of program details")
	public void user_fills_all_the_mandatory_fields_of_program_details(DataTable data) {
		try {
			
			List<List<String>> d = data.asLists();
			String A = d.get(0).get(0);
			String B = d.get(0).get(1);
			String C = d.get(0).get(2);
			String D = d.get(0).get(3);
			String E = d.get(0).get(4);
			String F = d.get(0).get(5);
			String G = d.get(0).get(6);
			String H = d.get(0).get(7);
			
			
			createprogrampage = new CreateProgramPage();
			createprogrampage.getTodayDate();
			createprogrampage.fillTodayDate();
			createprogrampage.selectCoverage();
			createprogrampage.validateProgramName();
			createprogrampage.fillHeadCountAndUSValues(A,B);
			createprogrampage.fillFullTimeValues(C);
			createprogrampage.fillStateValues(D,E,F,G,H);
			
			createprogrampage.VerifyHeadCountAndUSNonUSValues();
			createprogrampage.verifyHeadCountAndFullPartTimeValues();
			createprogrampage.verifyUSAndStateValues();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User fills the Contact team details")
	public void user_fills_the_contact_team_details(DataTable data) {
		try {
			createprogrampage = new CreateProgramPage();
			createprogrampage.verifyOfficeFields();
			createprogrampage.selectRoleFields();
			createprogrampage.selectEmployeeFields();
			
			List<List<String>> d = data.asLists();
			String A = d.get(0).get(0);
			String B = d.get(0).get(1);
				
			createprogrampage.fillProductionPercentage(A,B);
			createprogrampage.verifyProductionPercentage();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	@Given("User logs out of the application")
	public void user_logs_out_of_the_application() {
		try {
			signout = new SignOut();
			signout.clickOnMenu();
			signout.clickOnSignOut();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
