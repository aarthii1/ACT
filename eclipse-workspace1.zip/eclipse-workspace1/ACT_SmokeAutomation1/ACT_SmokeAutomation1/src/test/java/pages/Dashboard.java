package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.TestBase;

public class Dashboard extends TestBase {
	
	@FindBy(xpath ="//span[contains(text(),'Clients')]")
	WebElement Clients;

	
	//Create Client Option xpath
	@FindBy(xpath ="//a[contains(text(),'Create Client')]")
	WebElement CreateClient;
	
	@FindBy(xpath ="//a[contains(text(),'All Clients')]")
	WebElement AllClients;
	
	@FindBy(xpath="//h2[contains(text(),\"Client List\")]")
	WebElement Clientheader;

	//Create policy page header
	@FindBy(xpath="//h2[contains(text(),\"Create Policy\")]")
	WebElement Createpolicy;
	
	//View program page header
	@FindBy(xpath="//h2[contains(text(),'View Program')]")
    WebElement ViewProgram;
	
	//Contact and Account Service Team Section header
	@FindBy(xpath="//span[contains(text(),'Account Service Team')]")
	WebElement ContactAccountSection;

	//Create Client Header Xpath
	@FindBy(xpath="//h2[contains(text(),\"Create Client\")]")
	WebElement CreateClientHeader;
	
	//View Client Header Xpath
	@FindBy(xpath="//h2[contains(text(),\"View Client\")]")
	WebElement ViewClient;
	
	@FindBy(xpath="//h2[contains(text(),'Premium Transaction')]")
	WebElement PremiumTransaction;
	
	@FindBy(xpath="//h2[contains(text(),'Search Policy')]")
	WebElement Searchpolicy;

	@FindBy(xpath="//h2[contains(text(),'Endorsement Policy')]")
	WebElement Endorsementpage;

	//Approvals
	@FindBy(xpath="//span[text()='Approvals']")
	WebElement Approvals;
		
	//Pending Approvals
	@FindBy(xpath="//span[contains(text(),'Pending Approvals')]")
     WebElement PendingApprovals;
	
	//PTapprovals pending approvals
	@FindBy(xpath="//a[@title='Premium Transactions Pending for Approvals']")
	WebElement PendingPTapprovals;
	
	//PT approvals Header
	@FindBy(xpath="//h2[contains(text(),'Approvals')]")
    WebElement PTApproval;		

	//View Search
	@FindBy(xpath="//span[contains(text(),'View/Search')]")
	WebElement ViewSearch;
	
	//Policy List/Search
	@FindBy(xpath="//a[contains(text(),'Policy List/Search')]")
	WebElement PolicyListSearch;
	
	//Premium Transaction View
	@FindBy(xpath="//span[contains(text(),'Premium Transactions View')]")
	WebElement PremiumTransactionsView;

	//Premium Transactions View - Pending
	@FindBy(xpath="//a[@title='View Pending Premium transactions']")
	WebElement PremiumPending;
	
	//Premium Transactions View - Approved
	@FindBy(xpath="//a[@title='View All Premium Transactions by Team and Expiration Date']")
	WebElement PremiumApproved;
	
	//Premium Transactions View - Disapproved
	@FindBy(xpath="//a[@title='View Disapproved Premium Transactions']")
	WebElement PremiumDisapproved;
	
	//Premium Transactions View - Pending Installments
	@FindBy(xpath="//a[@title='View Installments Due by Month']")
	WebElement PremiumPendingInstallments;
	
	public Dashboard() {
	
	PageFactory.initElements(driver, this);
	
}

	//double click ,dropdown predefine function
	public void navigateToAllClients()
	{
		
		
		Actions action = new Actions(driver);
		
		action.doubleClick(Clients).perform();
		
		AllClients.click();
		
	}
	
	public void navigateToCreateClient()
	{
		
		
		Actions action = new Actions(driver);
		
		action.doubleClick(Clients).perform();
		
		CreateClient.click();
		
	}
	
	public void navigateToPolicyListSearch()
	{
		
		
		Actions action = new Actions(driver);
		
		action.doubleClick(ViewSearch).perform();
		
		PolicyListSearch.click();
		
	}
	
	public boolean veifyAllClients()
	{
		return(Clientheader.isDisplayed());
		
	}
	

	public boolean verifyCreatePolicy() {
		return(Createpolicy.isDisplayed());
	}
	

	public boolean verifyCreateClient()
	{
		return(CreateClientHeader.isDisplayed());
		
	}
	
	public boolean verifyViewClient() {
		return(ViewClient.isDisplayed());
	}


	
	public void navigateToPTapproval()
	{

		Actions action = new Actions(driver);
		
		action.doubleClick(Approvals).perform();
		
		action.doubleClick(PendingApprovals).perform();

		PendingPTapprovals.click();	
			
	}
	
	public boolean verifyPTApproval() {
		return(PTApproval.isDisplayed());
	}
	
	

  public boolean verifyViewProgramPage() {
		
		return(ViewProgram.isDisplayed());
	}
		
 
  public boolean VerifyContactAccountscreen() {
	
	return(ContactAccountSection.isDisplayed());
}
  
  public boolean verifyPremiumTransactionPage() {
	  
	  return(PremiumTransaction.isDisplayed());
  }
  
  public boolean verifySearchPolicy() {
	  
	  return(Searchpolicy.isDisplayed());
  }
  
public boolean verifyEndorsementpolicypage() {
	  
	  return(Endorsementpage.isDisplayed());
  }

public void navigateToPremiumTransactionsView()
{
	try {
	
	Actions action = new Actions(driver);
	
	action.doubleClick(ViewSearch).perform();
	
	Thread.sleep(4000);
	
	action.doubleClick(PremiumTransactionsView).perform();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
}

public void navigateBackToViewSearch()
{
	try {
	
	Actions action = new Actions(driver);
	
	action.doubleClick(PremiumTransactionsView).perform();
	
	Thread.sleep(4000);
	
	action.doubleClick(ViewSearch).perform();
	
	
	
	
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
}

public boolean verifyPremiumPendingOption() {
	  
	  return(PremiumPending.isDisplayed());
}

public void navigateToPremiumPremiumPendingPage()
{
	
	PremiumPending.click();
	
}

public boolean verifyPremiumApprovedOption() {
	  
	  return(PremiumApproved.isDisplayed());
}

public void navigateToPremiumApprovedPage()
{
	
	PremiumApproved.click();
	
}

public boolean verifyPremiumPendingInstallmentsOption() {
	  
	  return(PremiumPendingInstallments.isDisplayed());
}

public void navigateToPremiumPendingInstallmentsPage()
{
	
	PremiumPendingInstallments.click();
	
}

public boolean verifyPremiumDisapprovedOption() {
	  
	  return(PremiumDisapproved.isDisplayed());
}

public void navigateToPremiumDisApprovedPage()
{
	
	PremiumDisapproved.click();
	
}

public void navigateBackToClientView() {
	try {

		Actions action = new Actions(driver);
		
		action.doubleClick(Clients).perform();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

}
