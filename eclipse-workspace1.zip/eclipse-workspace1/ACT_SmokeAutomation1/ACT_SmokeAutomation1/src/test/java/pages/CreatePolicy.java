package pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.collections.Lists;

import base.TestBase;
import commonUtils.WebElementActions;
import io.cucumber.datatable.DataTable;

public class CreatePolicy extends TestBase{
	
	WebElementActions webelementactions;
	
	Dashboard dashboard;
	
	//Expand client button xpath
	@FindBy(xpath="//tr[contains(@id,'ClientList_ctl00__0')]//td[1]")
	WebElement ExpandClient;
	
	//View Program Icon
	@FindBy(xpath="//img[contains(@id,'ctl04_imgProgram')]")
	WebElement ViewProgIcon;
	
	@FindBy(xpath="//h2[contains(text(),'View Program')]")
	WebElement ViewProg;
	
	//For click the Addpolicy button
	@FindBy(xpath="//input[contains(@id,'AddPolicyT_input')]")
	WebElement Addpol;

	//for verifying the client name at create policy page
	@FindBy(xpath="//span[contains(@id,'ClientName')]")
	WebElement Clientname;
	
	//for verifying the Program name at create policy page
	@FindBy(xpath="//span[contains(@id,'ProgramName')]")
	WebElement ProgramName;
	
	//Layer text box
	@FindBy(xpath="//input[contains(@id,'rntxtLayerNumber_text')]")
	WebElement Layer;
	
	//Policy number text box
	@FindBy(xpath= "//input[contains(@id,'PolicyNumber_text')]")
	WebElement PolicyNo;
	
	//Inception date field
	@FindBy(xpath="//input[contains(@id,'PolicyEffectiveDate_dateInput_text')]")
	WebElement Inception;
	
	//expiration date field
	@FindBy(xpath="//input[contains(@id,'PolicyExpirationDate_dateInput_text')]")
	WebElement Expiration;
	
	//Foreign policy field
	@FindBy(xpath="//input[contains(@id,'ForeignPlacement_Input')]")
	WebElement ForeignPol;
	
	//Quota share field
	@FindBy(xpath="//input[contains(@id,'QuotaShareLayer_Input')]")
	WebElement QuotaShare;
	
	@FindBy(xpath="//input[contains(@id,'PunitiveWrap_Input')]")
	WebElement Punitive;
	
	@FindBy(xpath="//input[contains(@id,'RunOffPolicy_Input')]")
	WebElement RunOff;
	
	@FindBy(xpath="//input[contains(@id,'rcbSPS_Input')]")
	WebElement SPS;
	
	@FindBy(xpath="//input[contains(@id,'MidTermBOR_Input')]")
	WebElement BOR;
	
	@FindBy(xpath="//input[contains(@id,'BrokerPlacement_Input')]")
	WebElement Benchmarking;
	
	//for Carrier group text box
	@FindBy(xpath="//input[contains(@id,'rcbCarrierGroup_Input')]")
	WebElement CarrierGp;
	
	//for Carrier text box
	@FindBy(xpath="//input[contains(@id,'rcbCarrier_Input')]")
	WebElement Carrier;
	
	//for Attachmentpoint text box
	@FindBy(xpath="//input[contains(@id,'AttachmentPoint_text')]")
	WebElement Attachmentpoint;
	
	//for Add Coverage button
	@FindBy(xpath="//a[contains(@id,'radbtnAddCoverage')]")
	WebElement AddCov;
	
	//for Coverage box
	@FindBy(xpath="//a[contains(@id,'rcbCoverage_Arrow')]")
	WebElement Coverage;
    
	//for Contact & Account Service team
	@FindBy(xpath="//span[contains(text(),'Account Service Team')]")
	WebElement Contact;
	
	//for limit text box
	@FindBy(xpath="//input[contains(@id,'rntxtLimit_text')]")
	WebElement limit;
	
	//for Aggregate limit text box
	@FindBy(xpath="//input[contains(@id,'AggregateLimit_text')]")
	WebElement Agglimit;
	
	//for Primary Deductible text box
	@FindBy(xpath="//input[contains(@id,'PrimaryDeductible_text')]")
	WebElement PrimaryDec;
	
	//for Secondary Deductible text box
	@FindBy(xpath = "//input[contains(@id,'SecondaryDeductible_text')]")
	WebElement SecondaryDec;
	
	//for Primary Aggregate type text box
	@FindBy(xpath="//input[@value='Annual Aggregate']")
	WebElement AggType;

	//for Deductible type text box
	@FindBy(xpath="//input[@value='Single Plaintiff']")
	WebElement DeductibleType;

	//for secondary deductible type text box
	@FindBy(xpath="//input[contains(@id,'SecondaryDeductibleType_Input')]")
	WebElement Deductible2Type;
	
	//for Insert button
	@FindBy(xpath="//input[@title='Insert']")
	WebElement insert;

	//for bottom control buttons
	@FindBy(xpath="//table[contains(@id,'tblBottomControls')]")
	WebElement button;
	
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl04_EditButton")
	WebElement Editbtn;
	
	//for Save button
	@FindBy(xpath="//table[contains(@id,'tblBottomControls')]//td[1]")
	WebElement save;
	
	//for Attachment confirmation window
	@FindBy(xpath="(//td[@class='rwWindowContent']//div)[2]")
	WebElement Attachmentconfirmfation;
	
	//for Policy creation confirmation box
	@FindBy(id="ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C")
	WebElement Confirmationbox;

	//for Yes
	@FindBy(id="ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_butOk_input")
	WebElement Confirmationstatus;
	
	@FindBy(xpath="//h2[contains(text(),'Create Premium Transaction')]")
	WebElement CreatePreTran;
	
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rdpPolicyExpirationDate_dateInput_text")
	WebElement effectiveexpirationdate;
	
	@FindBy(xpath="//div[@id='confirm1659685753363_content']")
	WebElement Exppopup;
	
	@FindBy(xpath="//span[text()='Yes']")
	WebElement expOkbtn;
	
	@FindBy(xpath="//input[contains(@id,'rcbPaymentType_Input')]")
	WebElement paymentType;
	
	//Disapprove button
    @FindBy(css="input#ctl00_PlaceHolderMain_radbtnDisApproveTop_input")
    WebElement disapprovebutton;
    
    //Disapprove out of order
    @FindBy(css="a#ctl00_PlaceHolderMain_ucMsgBoxPTConfirmation_rwMessageBox_C_butOk")
    WebElement disapproveOkpopup;
    
    @FindBy(xpath="//h2[contains(text(),'Approvals')]")
	WebElement Approvalsheader;
	
	public CreatePolicy() {
		
		try {
			
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	//To Open the View Program Page
	
	public void selectClient() {
		
		try 
		    {
			
			ExpandClient.click();
			
			webelementactions = new WebElementActions();
			
			webelementactions.Explicitwait(ViewProgIcon);
			
			ViewProgIcon.click();
			
			webelementactions.Explicitwait(ViewProg);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	//To validate the popup after clicking the add policy button
	
	public void addPolicy() {
		
		try {

			Addpol.click();
			
            webelementactions = new WebElementActions();
			
			webelementactions.implicitwait(2000);
			
			WebElement PopUp = driver.findElement(By.xpath("//em[contains(text(),'Account Service Team')]"));
			
			if(PopUp .getText().equalsIgnoreCase("Update 'Account Service Team' Details")) {
				
			WebElement ASTdetails = driver.findElement(By.name("rwValidateASTDetails"));
				
			driver.switchTo().frame(ASTdetails);
				
			WebElement Continue = driver.findElement(By.id("ctl00_PlaceHolderMain_btnContinueWithoutUpdate_input"));
				
			Continue.click();
			
			webelementactions.implicitwait(4000);
				
				}
				
				else {
					
					WebElement page = driver.findElement(By.xpath("//h2[contains(text(),'Create Policy')]"));
					
					Assert.assertTrue(page.isDisplayed());
				}
	       }
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
	}
	
	public void layerValidation(String layer, String policy){
		
		try 
		{
			
			Layer.sendKeys(layer);
			
			Thread.sleep(4000);
			
			PolicyNo.sendKeys(policy);
			
			Thread.sleep(9000);
			
			String attach = Attachmentpoint.getAttribute("value");
				
		    Assert.assertEquals(attach, "$0");

		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	//For verifying all the fields present at the policy page
	public void allfieldsValidation() {
		
		try
		    {
			
			webelementactions = new WebElementActions();
			
			Assert.assertTrue(Clientname.isDisplayed());
			
			Assert.assertTrue(ProgramName.isDisplayed());
			
			webelementactions.isValuePresentinTxtBx(QuotaShare);
			
			webelementactions.isValuePresentinTxtBx(ForeignPol);
			
			webelementactions.isValuePresentinTxtBx(Inception);
			
			webelementactions.isValuePresentinTxtBx(Expiration);
			
			webelementactions.isValuePresentinTxtBx(Punitive);
			
			webelementactions.isValuePresentinTxtBx(RunOff);
			
			webelementactions.isValuePresentinTxtBx(SPS);
			
			webelementactions.isValuePresentinTxtBx(BOR);
			
			webelementactions.isValuePresentinTxtBx(Benchmarking);
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
			
		}

	//for selecting the value to Carrier Group and Carrier field
	public void carrierGpfieldValidation() {
		
		try {
			
			webelementactions = new WebElementActions();
			
			CarrierGp.click();
			
			Thread.sleep(3000);
		 
			List<WebElement> CarriergpOptions = driver.findElements(By.xpath("//div[contains(@id,'rcbCarrierGroup_DropDown')]//li"));
			
			webelementactions.selectCombobox(CarrierGp, CarriergpOptions, "AIG");
			
			Thread.sleep(9000);
		}
		
       catch(Exception e) {
			
			e.printStackTrace();
		}
			
    }
		    
	public void carrierfieldValidation() {
		
	      try
	        
	      {

		    Carrier.click();
		    
		    Thread.sleep(3000);

		  List<WebElement> CarrierOptions = driver.findElements(By.xpath("//div[contains(@id,'rcbCarrier_DropDown')]//li"));

		   webelementactions = new WebElementActions();
		  
		   webelementactions.selectCombobox(Carrier, CarrierOptions, "AIG Europe Limited");
			
		  Thread.sleep(8000);
			
		}
          catch(Exception e) {
			
			   e.printStackTrace();
		}
			}
	
	//For adding coverage to transaction
	public void addCoverage() {
		
		try 
		    {
		
		     AddCov.click();
		    
		    webelementactions = new WebElementActions();
				
			webelementactions.Explicitwait(Coverage);

		    JavascriptExecutor jse = (JavascriptExecutor) driver;
		  
			jse.executeScript("arguments[0].scrollIntoView()", Contact);
			
			Coverage.click();
			
			List<WebElement> alloptions = driver.findElements(By.xpath("//div[contains(@id,'rcbCoverage_DropDown')]//li"));
		  
		    Thread.sleep(5000);
		     
			for(int i=0; i<=alloptions.size()-1; i++) {
			  
		  	if(alloptions.get(i).getText().equalsIgnoreCase("Employment Practices Liability (EPL)")) {
		  		
		 	alloptions.get(i).click();
		  		
		 	 break;
		  	 }
		}
			
			Thread.sleep(9000);

		}
		
		 catch(Exception e) {
				
			   e.printStackTrace();
		}
	}
	
	public void coverageDetails(String limit1, String Agglimit1, String PrimaryDec1, String Secondarydec1) {
		
		try 
		   {
			
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", Contact);
			
		    //To fill the coverage details under add coverage section
			  
			 limit.sendKeys(limit1);
			  
			 Thread.sleep(2000);

			 Agglimit.sendKeys(Agglimit1);

			 PrimaryDec.sendKeys(PrimaryDec1);

			 SecondaryDec.sendKeys(Secondarydec1);

			 String Type = AggType.getAttribute("value");
				
			 Assert.assertEquals(Type,"Annual Aggregate");
	
			 String Type1 = DeductibleType.getAttribute("value");
					
			 Assert.assertEquals(Type1,"Single Plaintiff");
					
			 Thread.sleep(4000);
			
			 Deductible2Type.click();
			  
			 List<WebElement> alloptions2 = driver.findElements(By.xpath("//div[contains(@id,'SecondaryDeductibleType_DropDown')]//li"));

			Thread.sleep(4000);
			
			 for(int i=0; i<=alloptions2.size()-1; i++) {
				  
			  	if(alloptions2.get(i).getText().equalsIgnoreCase("Mass class")) 
			  	{
			  	   alloptions2.get(i).click();
		
			  		break;
			  	}
			  
			  }
				 Thread.sleep(4000);
		}
		
		 catch(Exception e) {
				
			   e.printStackTrace();
		}
	}
	
	public void insertCoverage() {
		
		try
		{
			insert.click();
			
			webelementactions = new WebElementActions();
			
			webelementactions.Explicitwait(Editbtn);
		}
		
		 catch(Exception e) {
				
			   e.printStackTrace();
		}

	}
	
	//To verify the Contact and Service team section present on the screen
	
	public void contactAccountTeamValidation() {
		
		try {
			
            JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", Contact);
			
			dashboard =new Dashboard();
			
			Assert.assertTrue(dashboard.VerifyContactAccountscreen());
		 
		}

		 catch(Exception e) {
				
			   e.printStackTrace();
		}
	}
	
//To click on the Save button	
	
	public void savePolicy() {
		
		try
		   {
			
			 if(button.isDisplayed()) {
			
			 save.click();
				 
			 Thread.sleep(4000);
				
			 //for attachments
			 
			 WebElement confirmstataus = Attachmentconfirmfation.findElement(By.xpath("//span[text()='No']"));
			 
			 confirmstataus.click();
			 
			 webelementactions = new WebElementActions();
				
			webelementactions.Explicitwait(Confirmationbox); 

			  }
		   }
		
		 catch(Exception e) {
			   e.printStackTrace();
		}
	}

   public void validatePopUp() {

		try 
		   {
	   // For selecting the transaction

			WebElement Confirmationstatus = Confirmationbox.findElement(By.id("ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_butOk_input"));
			
			Confirmationstatus.click();
			
            webelementactions = new WebElementActions();
			
			webelementactions.Explicitwait(CreatePreTran);
			
		   }
		
		 catch(Exception e) {
			   e.printStackTrace();
		}
	
	}
   
		   
		   public void policy_effective_date() {
			   try {
				   
				   String postdate = effectiveexpirationdate.getAttribute("value");
				   Thread.sleep(4000);
				   String expdate = postdate;
				   
				   String splitter[]= expdate.split("/");
			        String day = splitter[1];
			        String month = splitter[0];
			        String year = splitter[2];
			        
			        int one = Integer.parseInt(year);
			        int two = one +2;
//			        System.out.println(two);
			        String three =String.valueOf(two);
//			        System.out.println(three);
			        
			        String newExpDate = month+"/"+day+"/"+three;
//			        System.out.println(newExpDate);
			        
			        effectiveexpirationdate.clear();
			        
			        Thread.sleep(1000);
			        
			        effectiveexpirationdate.sendKeys(newExpDate);
			        
			        Thread.sleep(1000);
			        
			        Attachmentpoint.click();
			        
			   }
			   catch(Exception e) {
				   e.printStackTrace();
			}
		   }
		   
		  
   
   public void prepaid_amount() {
	   try {
		   
	//	   Assert.assertTrue(Exppopup.isDisplayed()); 
	//	   expOkbtn.click();
		   
		   String Type = paymentType.getAttribute("value");
			
		    Assert.assertEquals(Type, "Prepaid");
	   }
	   catch(Exception e) {
		   e.printStackTrace();
	}
   }
   
   public void coverage_Detail_multiyear(String limit1, String Agglimit1) {
		
		try 
		   {
			
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", Contact);
			
		    //To fill the coverage details under add coverage section
			  
			 limit.sendKeys(limit1);
			  
			 Thread.sleep(2000);

			 Agglimit.sendKeys(Agglimit1);
			 
			 List<WebElement> AggLimitTypeValues1 = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbAggLimitType_DropDown']/div/ul/li"));
			webelementactions.selectCombobox(Agglimit, AggLimitTypeValues1, "Annual Aggregate");
		   }
		
		catch(Exception e) {
			   e.printStackTrace();
		}
   }
   
   public void click_on_add_policy() {
	   try {
		   
		   Addpol.click();
		   Thread.sleep(2000);
	   }
	   catch(Exception e) {
		   e.printStackTrace();
	   }
   }
   
   public void layer_Validation_multiyear(String layer, String policy){
		
		try 
		{
			
			Layer.sendKeys(layer);
			
			Thread.sleep(4000);
			
			PolicyNo.sendKeys(policy);
			
			Thread.sleep(9000);
			
			Attachmentpoint.sendKeys("12");
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

