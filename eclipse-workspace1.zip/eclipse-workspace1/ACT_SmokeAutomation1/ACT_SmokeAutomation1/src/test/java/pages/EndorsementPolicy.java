package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class EndorsementPolicy extends TestBase {

 WebElementActions webelementactions;
 
 Dashboard dashboard;
	  
//To Click endoserment button	
@FindBy(xpath="//input[contains(@id,'btnEndorsement_input')]")
WebElement Endorsement;

@FindBy(xpath="//h2[contains(text(),'Endorsement Policy')]")
WebElement Endorsementpage;

@FindBy(xpath="//h2[contains(text(),\"View Client\")]")
WebElement ViewClient;

@FindBy(xpath="//iframe[@name='rwValidateASTDetails']")
WebElement UpdateDetScreen;

@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_lblProgramName")
WebElement progname;

@FindBy(xpath="//h2[contains(text(),'Endorsement Policy')]")
WebElement ViewEndorsement;

@FindBy(xpath="//em[contains(text(),'Account Service Team')]")
WebElement PopUp;

@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_lblClientName")
WebElement Clientname;

@FindBy(xpath="//input[contains(@id,'PolicyNumber_text')]")
WebElement Policyno;

@FindBy(xpath="(//input[contains(@id,'dateInput_text')])[1]")
WebElement Effectivedate;

@FindBy(xpath="(//input[contains(@id,'dateInput_text')])[2]")
WebElement Expirationdate;

@FindBy(xpath="//input[contains(@id,'rbtnSave_input')]")
WebElement Save;

@FindBy(xpath="(//td[@class='rwWindowContent']//div)[2]")
WebElement Attachmentconfirmation;

@FindBy(xpath="//em[contains(text(),'Policy Endorsement')]")
WebElement Policyendorsed;

@FindBy(xpath="//input[@name='ctl00$PlaceHolderMain$ucMsgBox$rwMessageBox$C$butOk']")
WebElement Endorsementconfirmation;

@FindBy(xpath="//h2[contains(text(),'Create Premium Transaction')]")
WebElement CreatePreTran;

@FindBy(xpath="//a[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_dtInceptionDate_popupButton']")
WebElement EndoEffectivedate;

@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_lblTransactionTypeValue")
WebElement Transtype;

@FindBy(xpath="//input[contains(@name,'radcmbRecurringRevenue')]")
WebElement Recurringrev;

@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_radcmbCappedCommission_Input")
WebElement Capcommission;

@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_radtxtComments_contentIframe")
WebElement Comment;

@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_dtExpiryDate_dateInput_text")
WebElement EndoExpdate; 

//Select Coverage Option
@FindBy(xpath="//input[@value='Select Coverage']")
WebElement SelectCoverage;
	
//Coverage Text Box
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbCoverage_Input']")
WebElement CoverageTxtBox;
	
//Premium Text Box
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtPremium_text']")
WebElement PremiumTxtBox;
	
	//Commission Percent
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtCommissionPct_text']")
WebElement CommissionPercent;
	
//Commission $
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtCommission_text']")
WebElement CommissionDol;
	
//Fee
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtFee_text']")
WebElement Fee;
	
//Fee Type
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbFeeType_Input']")
WebElement FeeType;
	
//Revenue Type
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbRevenueType_Input']")
WebElement RevType;
	
//Insert Button
@FindBy(xpath="//input[@title='Insert']")
WebElement InsertBtn;

//Grid Data After Insert
@FindBy(xpath="//tr[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00__0']")
WebElement GridData;
	
//Submit for approval Button
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_radbtnSave_input']")
WebElement SubmitApprBtn;

//Extension sent for approval pop-up
@FindBy(xpath="//span[@id='ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_lblMessage']")
WebElement EndAppPopup;
	
//Pop-up ok button
@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_butOk_input']")
WebElement EndAppOkBtn;

@FindBy(xpath = "//span[text() = 'Approvals']")
WebElement approvalButton;

@FindBy(xpath = "//span[text() = 'Pending Approvals']")
WebElement pendingApprovalButton;

@FindBy(xpath = "//a[text() = 'PT Approvals']")
WebElement PTApprovalButton;

@FindBy(xpath = "//h2")
WebElement Header;

@FindBy(xpath = "//div[contains(@id , 'PendingForApprovalHeader_GridData')]/table/tbody/tr/td[3]")
List<WebElement> programNames;

@FindBy(xpath = "//input[contains(@id , '_ctl00_ctl04_GECBtnExpandColumn')]")
WebElement expandButton;

@FindBy(xpath = "//a[@title ='View Transaction']")
WebElement viewTransaction;

//@FindBy(xpath = "//h2")
//WebElement headerPendingApproval;

@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr[1]")
WebElement clientProgramPolicyRow;

@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr/td[1]")
WebElement clientName;

@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr/td[3]")
WebElement programName;

@FindBy(xpath = "//table[@id ='tblbreadcrum']/tbody/tr/td[5]")
WebElement policyNo;

@FindBy(xpath = "//span[text()='Policy Details']")
WebElement policyDetail;

@FindBy(xpath = "//span[text()='Policy Information']")
WebElement policyInformation;

@FindBy(xpath = "//span[contains(@id , '_i0_lblClientName')]")
WebElement policyInformationclientName;

@FindBy(xpath ="//table[contains(@id , 'pbPolicy_i0_tblPolicy')]/tbody/tr[2]/td[2]/span")
WebElement policyInformatioProgramName;

@FindBy(xpath = "//table[contains(@id , 'pbPolicy_i0_tblPolicy')]/tbody/tr[2]/td[5]/div/span")
WebElement policyInformatioPolicyNo;

@FindBy(xpath = "//span[text()='Premium Transaction Details']")
WebElement premiumTransactionDetails;

@FindBy(xpath = "//span[text()='Premium Transaction']")
WebElement premiumTransaction;

@FindBy(xpath = "//span[contains(@id , 'i0_lblTransactionTypeValue')]")
WebElement transactionType;

@FindBy(xpath = "//input[contains(@id , 'radbtnApproveTop_input')]")
WebElement approveButton;

@FindBy(xpath = "//input[contains(@id , 'radbtnEditTop_input')]")
WebElement editButton;

@FindBy(xpath = "//input[contains(@id , 'radbtnCancelTop_input')]")
WebElement cancelButton;

@FindBy(xpath = "//input[contains(@id , 'radbtnDisApproveTop_input')]")
WebElement disApproveButton;

@FindBy(xpath = "//span[text() = 'View/Search']")
WebElement viewSearchButton;

@FindBy(xpath = "//span[text() = 'Premium Transactions View']")
WebElement premiumTransactionViewButton;

@FindBy(xpath = "//a[text() = 'Approved']")
WebElement approvedButton;

@FindBy(xpath = "//h2")
WebElement approvedPage;

@FindBy(xpath="//h2[contains(text(),'Approval')]")
WebElement Approvalpage;
public EndorsementPolicy() {
	
	try {
		
	PageFactory.initElements(driver, this);
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
}

public void click_on_Endorsement() {
	try {
		
		Endorsement.click();

		Thread.sleep(4000);
		
		webelementactions = new WebElementActions();
		
		Boolean isPresent = webelementactions.isElementPresent("//h2[contains(text(),'Endorsement Policy')]");
		
		if(isPresent==true) {
			
		Assert.assertTrue(Endorsementpage.isDisplayed());
			
//		WebElement PopUp = driver.findElement(By.xpath("//em[contains(text(),'Account Service Team')]"));
		
//		if(PopUp.getText().equalsIgnoreCase("Update 'Account Service Team' Details")) {
//			
//		WebElement ASTdetails = driver.findElement(By.name("rwValidateASTDetails"));
//			
//		driver.switchTo().frame(ASTdetails);
//			
//		WebElement Continue = driver.findElement(By.id("ctl00_PlaceHolderMain_btnContinueWithoutUpdate_input"));
//			
//		Continue.click();
//		
//		Thread.sleep(4000);
		
			}
			
		else if(isPresent==false){
			
			UpdateDetScreen.isDisplayed();
			
			driver.switchTo().frame(UpdateDetScreen);			
			
			WebElement Continue = driver.findElement(By.id("ctl00_PlaceHolderMain_btnContinueWithoutUpdate_input"));
			
			Continue.click();
			
			driver.switchTo().defaultContent();
				
//		WebElement page = driver.findElement(By.xpath("//h2[contains(text(),'Endorsement Policy')]"));
//				
//		Assert.assertTrue(page.isDisplayed());
				
//				webelementactions = new WebElementActions();
//				 
//				webelementactions.Explicitwait(Endorsementpage);
       }
	}
	
	catch(Exception e)
	
	{
		e.printStackTrace();
	}

}

public void wait_until_endorsement_page_load() {
	try {
		
		webelementactions = new WebElementActions();
		webelementactions.Explicitwait(Endorsementpage);
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

  public void verifydetails() {
	
	 try 
	  {
		Assert.assertTrue(Clientname.isDisplayed());
		Assert.assertTrue(progname.isDisplayed());
		Assert.assertFalse(Policyno.isEnabled());
		Assert.assertFalse(Effectivedate.isEnabled());
		Assert.assertFalse(Expirationdate.isEnabled());
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

   public void saveEndorsementPolicy() {
	
     try
        {
    	 webelementactions = new WebElementActions();
    	 
    	 Save.click();

         Thread.sleep(4000);
    	 
    	 WebElement confirmstataus = Attachmentconfirmation.findElement(By.xpath("//span[text()='No']"));
		 
		 confirmstataus.click();
		  
		 webelementactions.Explicitwait(Policyendorsed);
		 
		 Endorsementconfirmation.click();
		 
		 webelementactions.Explicitwait(CreatePreTran);
		 
    }
     catch(Exception e)
 	{
 		e.printStackTrace();
 	}

}
   
   public void wait_until_premium_page_load() {
		try {
			
			webelementactions = new WebElementActions();
			webelementactions.Explicitwait(CreatePreTran);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void user_on_premium_page_validation() {
		try {
			
			Assert.assertTrue(dashboard.verifyPremiumTransactionPage());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
   
	  public void transaction_type_validation() {
			try {
				Assert.assertEquals(Transtype.getText(), "Endorsement");
			}
			catch(Exception e) 
			{
				e.printStackTrace();
			}
		}
	  
	  public void verify_revenue_details() {
			
			try
			   {
				
				String attach = Capcommission.getAttribute("value");
				
			    Assert.assertEquals(attach, "No");
			    
			    String attach1 = Recurringrev.getAttribute("value");
				
			    Assert.assertEquals(attach1, "No");
				
				Comment.sendKeys("testing");
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	  
	  public void fill_inception_dates() {
		  
		  try
		      {
			  
			  webelementactions = new WebElementActions();
				
				//DateValues
			   List<WebElement> ExtEffDateValues = driver.findElements(By.xpath("//table[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_dtInceptionDate_calendar_Top']/tbody/tr/td/a"));
			 	
			  webelementactions.datePickerSelection(EndoEffectivedate, ExtEffDateValues);
			  
		  }
		  catch(Exception e)
			{
				e.printStackTrace();
			}
	  }
	  
	  public void fill_coverage_details(String Premium, String Commission, String Fee1) {
			try {
				
				webelementactions = new WebElementActions();
				
				SelectCoverage.click();
				
				webelementactions.Explicitwait(CoverageTxtBox);

				webelementactions.isValuePresentinTxtBx(CoverageTxtBox);
				
				PremiumTxtBox.sendKeys(Premium);
				
				CommissionPercent.sendKeys(Commission);
				
				CommissionDol.click();
				
				webelementactions.isValuePresentinTxtBx(CommissionDol);
				
				Fee.sendKeys(Fee1);
				
				//Fee Type Values
				List<WebElement> FeeTypeValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbFeeType_DropDown']/div/ul/li"));
				
				
				webelementactions.selectCombobox(FeeType, FeeTypeValues, "Aon Bermuda Limited Fee(ABL )");
				

				//Revenue Type Values
				List<WebElement> RevTypeValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbRevenueType_DropDown']/div/ul/li"));
				
				webelementactions.selectCombobox(RevType, RevTypeValues, "New Existing (NE)");
				
				InsertBtn.click();
				
				webelementactions.Explicitwait(GridData);
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		public void user_clicks_on_submit_approval() {
			
			try {
				
				webelementactions = new WebElementActions();
				
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				
				jse.executeScript("arguments[0].scrollIntoView()", SubmitApprBtn);
				
				SubmitApprBtn.click();
				
				webelementactions.Explicitwait(EndAppPopup);
			}
			
			catch(Exception e) {
				
				e.printStackTrace();
		  }
		 }
		
		public void user_validates_submission() {
			try {
				webelementactions = new WebElementActions();
				
				Assert.assertEquals("Endorsement Premium Transaction has been successfully created and sent for approval.", EndAppPopup.getText());
				
				EndAppOkBtn.click();
				
				webelementactions.Explicitwait(ViewClient);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		public void clickOnApprovalButton()
		{
			try
			{
				webelementactions = new WebElementActions();
				webelementactions.doubleclick(approvalButton);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		 }
	
	 public void clickOnPendingApprovalButton()
		{
			try
			{
				webelementactions = new WebElementActions();
				webelementactions.doubleclick(pendingApprovalButton);
			    PTApprovalButton.click();
			}
			
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		 }
	 
	
	 
	 public void verifyApprovalPage()
		{
			try
			{
				Assert.assertTrue(Header.isDisplayed());

			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	
	 
	 public void clickExpand()
		{
			try
			{ 
				expandButton.click();
				//expandButton.click();
				//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
				//wait.until(ExpectedConditions.elementToBeClickable(viewTransaction));
				
				
                //JavascriptExecutor jse = (JavascriptExecutor) driver;
				
				//jse.executeScript("arguments[0].click()",viewTransaction);
				//viewTransaction.click();
					
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	 public void verifyClientDetailsPage()
		{
			try
			{		
				   // Assert.assertTrue(headerPendingApproval.isDisplayed());
				    Assert.assertTrue(clientProgramPolicyRow.isDisplayed());
				    Assert.assertTrue(policyInformation.isDisplayed());
				    Assert.assertTrue(policyDetail.isDisplayed());
                    Thread.sleep(5000);
					
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	 public void verifyClientDetails()
		{
			try
			{
				
				//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
				//wait.until(ExpectedConditions.visibilityOf(policyInformatioProgramName));
				
				Assert.assertEquals(clientName.getText(),policyInformationclientName.getText());
				Assert.assertEquals(programName.getText(),policyInformatioProgramName.getText());
				Assert.assertEquals(policyNo.getText(),policyInformatioPolicyNo.getText());
		
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}
	 
	 public void verifyTransactionDetails()
		{
			try
			{

				 premiumTransactionDetails.isDisplayed();
				 premiumTransaction.isDisplayed();
				 
				 Assert.assertTrue(transactionType.getText().equalsIgnoreCase("New Business") || transactionType.getText().equalsIgnoreCase("Endorsement") || transactionType.getText().equalsIgnoreCase("Extension"));
				 
				 Assert.assertTrue(approveButton.isDisplayed());
				 Assert.assertTrue(editButton.isDisplayed());
				 Assert.assertTrue(cancelButton.isDisplayed());
				 Assert.assertTrue(disApproveButton.isDisplayed());
				
				 
			}	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}


	 public void clickApproveButton()
		{
			try
			{
				Thread.sleep(3000);
				approveButton.click();
				Thread.sleep(3000);
				Assert.assertTrue(Approvalpage.isDisplayed());
				
		    }	
			catch(Exception e)
		    {
			   e.printStackTrace();
		    }
					
		}

	}
