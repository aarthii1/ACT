package pages;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.TestBase;
import commonUtils.WebElementActions;

public class PTDisApprovals extends TestBase {

    WebElementActions webelementactions;
	
	Dashboard dashboard;
	
	//WebElement for Expand All
	
	
	@FindBy(css="input#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl02_ctl00_radbtnExpandAll_input")
	WebElement ExpandAll;
	
	@FindBy(xpath="//h2[contains(text(),'Approvals')]")
	WebElement Approvalsheader;
	
	//WebElement ClientnameFilterBox
	@FindBy(css="input#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl02_ctl03_FilterTextBox_ClientName")
	WebElement ClientNameFilterbox;
	
	//WebElement ClientnameFilter contains
	@FindBy(css="input#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl02_ctl03_Filter_ClientName")
	WebElement ClientNameFilter;

	//WebElement viewTransaction
	@FindBy(css="a#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl06_radGrdDetails_ctl00_ctl05_lnkPremiumTransaction")
	WebElement ViewTransaction;
	
	//WebElement CLientName FirstRow
	@FindBy(css="span#ctl00_PlaceHolderMain_radGrdPendingForApprovalHeader_ctl00_ctl04_lblClientName")
	WebElement clientFirstRow;
	
	//WebElement for Pending 
	@FindBy(xpath="//h2[contains(text(),'Pending Approval')]")
	WebElement Pendingheader;
	
	//Disapprove button
    @FindBy(css="input#ctl00_PlaceHolderMain_radbtnDisApproveTop_input")
    WebElement disapprovebutton;
    
    //Disapprove out of order
    @FindBy(css="a#ctl00_PlaceHolderMain_ucMsgBoxPTConfirmation_rwMessageBox_C_butOk")
    WebElement disapproveOkpopup;
          
    //Cancel button
    @FindBy(css="input#ctl00_PlaceHolderMain_radbtnCancelTop_input")
    WebElement cancelbutton;
    
    //Contacts Team section
    @FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_rpbPTDetails_i0_rpbApproval']//span[contains(text(),'Account Service Team')]")
    WebElement ContactsTeam;
    
    //FSG Team Name
    @FindBy(css="span#ctl00_PlaceHolderMain_rpbPTDetails_i0_rpbApproval_i2_lblFSGProgramTeamNameValue")
    WebElement FSGTeamname;
    
    //Policy Label value
    @FindBy(css="span#ctl00_PlaceHolderMain_rpbucViewPolicy_i0_ucViewPolicyControl_rpbPolicy_i0_lblPolicyNumber")
    WebElement Policyvalue;
    
    //Expiration date label value
    @FindBy(css="span#ctl00_PlaceHolderMain_rpbucViewPolicy_i0_ucViewPolicyControl_rpbPolicy_i0_lblPolicyExpirationDate")
    WebElement expdatevalue;
    
    //Program name label value
    @FindBy(css="span#ctl00_PlaceHolderMain_rpbucViewPolicy_i0_ucViewPolicyControl_rpbPolicy_i0_lblProgramName")
    WebElement progname;
    
    public PTDisApprovals() {
		try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
    
    public void applyFilterPTapprovals(String clientname)
    {
    	
    	webelementactions =new WebElementActions();
    	try
    	{
    		

    		System.out.println("PT approvals");
    		    		
    		Thread.sleep(2000);    		
    		  		    	
    		webelementactions.applyFilter(ClientNameFilterbox, ClientNameFilter,clientname);
    		Thread.sleep(1000);
    		ExpandAll.click();
    	}
    	
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	
    }
    
    public boolean clientresultsValidation(String Clientname)
    {    
    	
    	return(clientFirstRow.getText().contains(Clientname));
    }
    
    public void clickonViewTransaction()
    {
        try
        {
    	ViewTransaction.click();
    	
    	Pendingheader.isDisplayed();
    	
    	
        }
        
        catch(Exception e)
        {
        	e.printStackTrace();
        }
    	
    	
    }
    
    
	public void retrieveTransactiondetails()
    {
		 
    	    	
    	try{
    		disapprovebutton.isDisplayed();

    		cancelbutton.isDisplayed();

    		transdetails.put("Expiration date",expdatevalue.getText().trim());

    		transdetails.put("Program name",progname.getText().trim());

    		transdetails.put("Policy number",Policyvalue.getText().trim());

    		JavascriptExecutor jse = (JavascriptExecutor) driver;

    		jse.executeScript("arguments[0].scrollIntoView()", ContactsTeam);

    		transdetails.put("Team name",FSGTeamname.getText().trim());


    	
    	}
    	
    	catch(Exception e)
    	{e.printStackTrace();
    		
    	}
    	
    	
    		
    	
    }
	
	
	public void clickonDisapprovebutton()
	{
		
		try {
			disapprovebutton.click();
			
			if (disapproveOkpopup.isDisplayed())
				disapproveOkpopup.click();

			Approvalsheader.isDisplayed();
				
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		
	}
	
	}
	

