package runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		publish = true,
		features="src//test//resources//features//Prod//Others//Utilities.feature",
		//features="src//test//resources//features//Create client//Createprogram.feature",
		glue={"stepDefs"},
		dryRun =false,
		monochrome =true,
		plugin= {"pretty",
				 "html:target/reports/HtmlReport.html",
				 "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
		},
		tags="@current"
		)
public class ACTSmokesuiteRunner extends AbstractTestNGCucumberTests {
	
	

}



//C:\Users\A0766051\eclipse-workspace\BDDACTAutomation\src\test\resources\features\ViewPolicy