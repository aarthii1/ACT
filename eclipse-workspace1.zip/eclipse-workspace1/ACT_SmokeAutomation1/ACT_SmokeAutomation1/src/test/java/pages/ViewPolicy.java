package pages;

import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class ViewPolicy extends TestBase{

	//View Policy Icon
		@FindBy(xpath="//img[@id='ctl00_PlaceHolderMain_rpnlSearchPolicy_i1_radgrdSearchResults_ctl00_ctl04_imgPolicy']")
		WebElement ViewPolicyIcon;
		
		//View Policy Header
		@FindBy(xpath="//h2[contains(text(),'View Policy')]")
		WebElement ViewPolicy;
		
		//Extend Policy Button
		@FindBy(xpath="//a[@id='ctl00_PlaceHolderMain_rbtnExtend']")
		WebElement ExtendPolicyBtn;
		
		//Update details Pop-up
		@FindBy(xpath="//iframe[@name='rwValidateASTDetails']")
		WebElement UpdateDetScreen;
		
		//Continue Button
		@FindBy(xpath="//a[@id='ctl00_PlaceHolderMain_btnContinueWithoutUpdate']")
		WebElement ContinueButton;
		
		//Confirmation Pop-Up
		@FindBy(xpath="//div[@class='rwDialogPopup radconfirm']/div[contains(text(),'Do you want to attach any documents for this adjustment?')]")
		WebElement ConfirmPopup;
		
		//Pop up No Button
		@FindBy(xpath="//span[@class='rwInnerSpan'][text()='No']")
		WebElement NoBtn;
		
		
		WebElementActions webeleactions;
		
		public ViewPolicy() {
			try {
			PageFactory.initElements(driver, this);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		public void navigate_to_view_policy_screen() {
			try {
				
				
				String originalWindow = driver.getWindowHandle();
				
				//System.out.println("Parent window id is: "+ originalWindow);
				
				ViewPolicyIcon.click();
				
				Thread.sleep(3000);
				
				Set<String> allWindows = driver.getWindowHandles();
				
				int count = allWindows.size();
				
				//System.out.println("Total window "+ count);
				
				for(String child:allWindows) {
					if(!originalWindow.equalsIgnoreCase(child)) {
						
						driver.switchTo().window(child);
						
						//System.out.println(driver.getTitle());
						
						webeleactions = new WebElementActions();
						
						webeleactions.Explicitwait(ViewPolicy);		
						
					}
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		public void validate_user_on_view_policy_page() {
			try {
				Assert.assertTrue(ViewPolicy.isDisplayed());
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}

	
	
	public void extend_policy_selection() throws InterruptedException {
		
			try {
			
			ExtendPolicyBtn.click();
			
			Thread.sleep(3000);
			
			webeleactions = new WebElementActions();
			
			Boolean isPresent = webeleactions.isElementPresent("//div[@class='rwDialogPopup radconfirm']/div[contains(text(),'Do you want to attach any documents for this adjustment?')]");
			
			//System.out.println(isPresent);
			
			if(isPresent==true) {
				
				Assert.assertTrue(ConfirmPopup.isDisplayed());
				
				NoBtn.click();
			}
			
			else if(isPresent==false){
				
				UpdateDetScreen.isDisplayed();
				
				driver.switchTo().frame(UpdateDetScreen);			
				
				ContinueButton.click();
				
				driver.switchTo().defaultContent();
				
				Assert.assertTrue(ConfirmPopup.isDisplayed());
				
				NoBtn.click();
			}
			
			
			
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		
		
	}


}
