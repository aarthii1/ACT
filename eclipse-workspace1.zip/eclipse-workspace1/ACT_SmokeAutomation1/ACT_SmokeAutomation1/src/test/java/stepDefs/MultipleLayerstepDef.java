package stepDefs;

import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import pages.AllClientsPage;
import pages.ApprovalPT;
import pages.CreatePolicy;
import pages.CreatePremiumTransaction;
import pages.Dashboard;
import pages.HomePage;
import pages.MultiLayerPolicy;
import pages.PTDisApprovals;

public class MultipleLayerstepDef extends TestBase {
	HomePage homepage;
	Dashboard dashboard;
	AllClientsPage allclients;
	Utility utility;
	MultiLayerPolicy multilayerpolicy;
	CreatePolicy createpolicy;
	CreatePremiumTransaction createpretran;
	PTDisApprovals ptmultiapproval;
	ApprovalPT approvals;
	
	@Given("User Launch ACT application")
	public void user_launch_act_application() {
		try {
			initialize();
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Then("User is on the ACT Homepage")
	public void user_is_on_the_act_homepage() {
		try {
	    	homepage = new HomePage();
	    	homepage.userOnHomePageValidation();
	    	
	    	
	    }
	    
	    catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Given("User clicks on All Clients option")
	public void user_clicks_on_all_clients_option() {
		try {
			dashboard =new Dashboard();
			
			dashboard.navigateToAllClients();
			
			
			
			}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User search for the expected client name")
	public void user_search_for_expected_client_name() {
		try {
			allclients = new AllClientsPage();
			
			allclients.allClientsvalidation();
			
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			allclients.applyClientNameFilter(SPClientName);
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Expected clientname should display")
	public void expected_clientname_should_display() {
		
		try {
			allclients = new AllClientsPage();
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			Assert.assertTrue(allclients.verifyClientFilterresults(SPClientName));
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@And("User clicks on view program icon")
	public void user_clicks_on_view_program_icon() {
		try {
			multilayerpolicy = new MultiLayerPolicy();
			multilayerpolicy.exapand_client_and_click_view_program_icon();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User is on View Program page")
	public void user_is_on_view_program_page() {
		try {
			multilayerpolicy = new MultiLayerPolicy();
			
			multilayerpolicy.validate_user_on_view_program_page();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks on Add Policy Option")
	public void user_clicks_on_add_policy_button() {
	
			try {
				multilayerpolicy = new MultiLayerPolicy();
				multilayerpolicy.click_on_add_policy();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	
	@Then("User should validate the pop up")
	public void user_should_validate_the_pop_up() {
		try {
			multilayerpolicy = new MultiLayerPolicy();
			multilayerpolicy.validating_pop_up();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User is on the CreatePolicy page")
	public void user_is_on_the_create_policy_page()
	{
		try {
			dashboard = new Dashboard();
			dashboard.verifyCreatePolicy();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User fills all the mandatory details")
	public void user_fills_all_the_mandatory_details() {
		try {
			
			multilayerpolicy = new MultiLayerPolicy();
			
			multilayerpolicy.validate_policy_information();
			
			
			multilayerpolicy.fill_policy_information();
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User fill the coverage details with package")
	public void user_fill_the_coverage_details_with_package() {
		try {
			multilayerpolicy = new MultiLayerPolicy();
			
			multilayerpolicy.fill_coverage_details();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User clicks on Save button")
	public void user_clicks_on_save_button() {
		try {
			multilayerpolicy = new MultiLayerPolicy();
			
			multilayerpolicy.click_on_save_button();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User is on the Premium Transaction page")
	public void user_is_on_the_premium_transaction_page() {
		try {
			createpretran = new CreatePremiumTransaction();
			createpretran.user_on_premium_page_validation();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("The Transaction type should be as {string}")
	public void the_transaction_type_should_be_as_new_business(String extType) {
		try {
			createpretran = new CreatePremiumTransaction();
			createpretran.transaction_type_validation(extType);
			
			createpretran.validate_details();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	@When("User fills the Transaction details and coverage details")
	public void user_fills_the_transaction_details_and_coverage_details() {
		try {
			createpretran = new CreatePremiumTransaction();
			
			createpretran.fill_multi_layer_tran_details();
			
			createpretran.fill_coverage_details();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User validates the coverage as {string}")
	public void user_validates_the_coverage_as_package(String value) {
		try {
			createpretran = new CreatePremiumTransaction();
			
			//System.out.println(value);
			
			createpretran.coverage_field_validation(value);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User clicks on Submit for Approval and validates the submission")
	public void user_clicks_on_submit_for_approval_and_validates_the_submission() {
		try {
			createpretran = new CreatePremiumTransaction();
			
			createpretran.user_clicks_on_submit_approval();
			
			createpretran.validate_new_business_submission();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User navigates to the PT Approvals page")
	public void user_navigates_to_the_pt_approvals_page() {
		try {
			
			dashboard =  new Dashboard();
			
			dashboard.navigateToPTapproval();
			
			boolean flag= dashboard.verifyPTApproval();
			
			Assert.assertTrue(flag);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("Search for the clientname and it displays")
	public void search_for_the_clientname() {
		try {
			
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			ptmultiapproval = new PTDisApprovals();
			
			ptmultiapproval.applyFilterPTapprovals(SPClientName);
			
			ptmultiapproval.clientresultsValidation(SPClientName);
		}
	
		catch(Exception e) {
			e.printStackTrace();
		}
}
	@Then("User clicks on view transaction option")
	public void user_clicks_on_view_transaction_option() {
		try {
			ptmultiapproval = new PTDisApprovals();
			
			ptmultiapproval.clickonViewTransaction();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User validates the layer as {string} and transaction type value as {string}")
	public void user_validates_the_layer_and_transaction_type_values(String layerValue,String transactionTypeValue) {
		try {
			//System.out.println("Layer - "+layerValue +"TType - "+transactionTypeValue);
			
			approvals = new ApprovalPT();
			
			
			approvals.validate_details("New Business", "1");
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User clicks on Approve button")
	public void user_clicks_on_approve_button() {
		try {
			approvals = new ApprovalPT();
			approvals.click_on_approve_button();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("Once approved User close the browser")
	public void once_approved_user_close_the_browser() {
		try {
			closeAllBrowsers();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
