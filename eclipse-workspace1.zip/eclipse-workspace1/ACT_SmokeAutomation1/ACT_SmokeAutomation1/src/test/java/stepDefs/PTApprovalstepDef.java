package stepDefs;

import java.util.HashMap;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AllClientsPage;
import pages.ApprovalPT;

public class PTApprovalstepDef extends TestBase {
	
	String tN;
	String eD;
	ApprovalPT ptApproval;
	AllClientsPage allclients;
	
	
	@When("User selects PT Approvals")
	public void User_selects_the_PT_Approvals()
	{
	  try
	  {
		ptApproval = new ApprovalPT();
		ptApproval.clickOnApprovalButton();
		ptApproval.clickOnPendingApprovalButton();
		ptApproval.verifyApprovalPage();
	  }	
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }	
	}   
	
	@When("User Search for the expected client name {string}")
	public void User_Search_for_the_expected_client_name(String clientname)
	{

		try 
		{
			allclients = new AllClientsPage();
	        allclients.applyClientNameFilter(clientname);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("Expected client name should display as {string}")
	public void Expected_client_name_should_display_as(String clientname)
	{
	  try
	  {
		ptApproval = new ApprovalPT();
		ptApproval.clientresultsValidation(clientname);
		
	  }
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}
	
    
	@Given("User selects clients")
	public void User_selects_the_clients()
	{
	  try
	  {
		ptApproval = new ApprovalPT();
		ptApproval.clickExpand();
		ptApproval.clickonViewTransaction();
	  }
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}

	@When("User validates Client details")
	public void User_validates_the_Client_details()
	{
	  try
	  {
		ptApproval = new ApprovalPT();
		ptApproval.verifyClientDetailsPage();
		ptApproval.verifyClientDetails();
		ptApproval.retrieveTransactiondetails();
       
	  }	
	  catch(Exception e)
	  {
			e.printStackTrace();
	  }
	}

    @When("User validates Transaction details")
    public void User_validates_the_Transaction_details()
    {
       try
       {
    	ptApproval = new ApprovalPT();
    	ptApproval.verifyTransactionDetails();
       }
       catch(Exception e)
 	   {
 			e.printStackTrace();
 	   }
   }
       

    @Then("User clicks on approve button")
    public void User_clicks_on_the_Approve_button()
    {
    	
      try
      {
    	ptApproval = new ApprovalPT();
    	ptApproval.clickApproveButton();
    	
      }
      catch(Exception e)
	  {
			e.printStackTrace();
	  }
    }

	
	
    @Given("User selects the Premium Transaction Approved")
    public void User_selects_the_Premium_Transaction_Approved()
    {
    	try
    	{
    		
    	ptApproval = new ApprovalPT();
    	ptApproval.approvedTransactionPage();
    	
    	}
        catch(Exception e)
  	    {
  			e.printStackTrace();
  	    }
    }	
    
   @When("User fills Company Name and Expiration Date") 
   public void User_fills_Company_Name_and_Expiration_Date()
   {
	   try
	   {
		   
	   ptApproval = new ApprovalPT();
	   ptApproval.fillCompanyAndFilter(transdetails.get("Team name"));
	   }
	   catch(Exception e)
 	   {
 			e.printStackTrace();
 	   }
	   
   }
   
   @When("User filter transaction details")
   public void User_filter_the_transaction_details()
   {
	  try
	  {
	   ptApproval = new ApprovalPT();
	   ptApproval.fillexpdateAndFilter(transdetails.get("Expiration date"));
	   
	  }
	   catch(Exception e)
	   {
			e.printStackTrace();
	   }
	   
   }
    	
    @Then("User expand the filtered transactions")
    public void User_expand_the_filtered_transactions() 
     {
       try
       {
    	 ptApproval = new ApprovalPT();
    	 ptApproval.expandCompanyOnApprovedTransactionPage();
    	 ptApproval.expandClientOnApprovedTransactionPage();
    	 
       }
       catch(Exception e)
	   {
			e.printStackTrace();
	   }
       
     }
    
     @Then("User clicks View Transaction")
     public void User_clicks_View_Transaction()
     {
    	try 
    	{
    		
    	 ptApproval = new ApprovalPT();
    	 ptApproval.viewTransactionAfterClientExpand();
    	
    	}
       catch(Exception e)
 	   {
 			e.printStackTrace();
 	   }
     }

     @Then("User validates View transaction details")
     public void User_validates_the_View_transaction_details()
     {
    	
      try
      {
    	 ptApproval = new ApprovalPT();
    	 ptApproval.verifyViewTransactionPage();
      }
      catch(Exception e)
	   {
			e.printStackTrace();
	   }
     } 
    
    @After
  	public void takescreenshot(Scenario scenario)
  	{
  		try
  		{ 
  			Utility.generateScreenshot(scenario);
  		
  		}
  		
  		catch(Exception e)
  		{
  			e.printStackTrace();
  		} 
  	}
    
}
 


