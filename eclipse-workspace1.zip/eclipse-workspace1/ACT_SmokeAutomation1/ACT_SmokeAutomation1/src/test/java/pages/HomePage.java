package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;

public class HomePage extends TestBase {

	@FindBy(id="ctl00_PlaceHolderMain_lblRestWord")
	WebElement ApplicationName;
	
	public HomePage() {
		try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void userOnHomePageValidation() {
		try {
			
			
				Assert.assertEquals("Client Tracking System (ACT)", ApplicationName.getText()); 
			}
			
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
}
