
package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import commonUtils.WebElementActions;


public class SearchPolicy extends TestBase{
	
	//Search Policy
	@FindBy(xpath="//h2[contains(text(),\"Search Policy\")]")
	WebElement SearchPolicy;
	
	//Client Name Input TextBox
	@FindBy(xpath="//*[@id='ctl00_PlaceHolderMain_rpnlSearchPolicy_i0_rcbClientName_Input']")
	WebElement ClientName;
	
	//Client Name Value
	@FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_rpnlSearchPolicy_i0_rcbClientName_DropDown']/div/ul/li")
	WebElement ClientNameValue;
	
	//Search Button
	@FindBy(xpath="//*[@id='ctl00_PlaceHolderMain_rpnlSearchPolicy_i0_radbtnSearch_input']")
	WebElement SearchBtn;
	
	//Grid Data
	@FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_rpnlSearchPolicy_i1_radgrdSearchResults_GridData']/table/tbody/tr/td/div")
	WebElement GridData;
	

	//Layer Text Box
	@FindBy(xpath="//input[contains(@id,'radnumtxtLayer_text')]")
    WebElement layertxt;

	@FindBy(id="ctl00_PlaceHolderMain_rpnlSearchPolicy_i0_radnumtxtLayer_text")
	WebElement Layerno;
	
	@FindBy(xpath="(//div[contains(@id,'SearchPolicy_i1_radgrdSearchResults_GridData')]//tbody//tr//td[4])")
	WebElement Layergrid;

	
	WebElementActions webeleactions;
	
	Utility utility;
	
	
	
	public SearchPolicy() {
		try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public boolean verifySearchPolicy() {
		return(SearchPolicy.isDisplayed());
	}
	
	public void enter_client_name() {
		try {
			
			utility = new Utility();
			
			//String SPClientName = "AutoTest061322035131";
			
			String SPClientName = utility.getClientName();
			
			ClientName.sendKeys(SPClientName);
			
			Thread.sleep(7000);
			
			ClientNameValue.click();
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_on_search() {
		try {
			SearchBtn.click();
			
			webeleactions = new WebElementActions();
			
			webeleactions.Explicitwait(GridData);
			
			//System.out.println("GridData: " + GridData.getText());
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void client_name_validation() {
		try {
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			Assert.assertEquals(GridData.getText(),SPClientName);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clickonlayertxtbox(String layer) {
        try {
            layertxt.sendKeys(layer);
        }
        catch(Exception e) {
		e.printStackTrace();
		}
	}
	
	public void click_on_layertxtbox(String Layer) {
		try {
			 Layerno.sendKeys(Layer);
			 Thread.sleep(1000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void layernumber_validation() {
		try {
			Assert.assertTrue(Layergrid.isDisplayed());
		}
			catch(Exception e)
			{
				e.printStackTrace();
        }
			}
    

		}



