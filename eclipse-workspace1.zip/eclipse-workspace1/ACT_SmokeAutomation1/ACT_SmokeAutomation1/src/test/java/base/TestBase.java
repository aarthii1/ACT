package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {
	
	public static Properties prop;
	public static WebDriver driver;
	
	public static HashMap<String, String> transdetails = new HashMap<String, String>();
	
	
	public TestBase() 
	{  prop =new Properties();
	 String path = System.getProperty("user.dir")
			 + "//src//test//resources//configFiles//config.properties";
	 
	 FileInputStream fin;
	
	 try {
		fin =new FileInputStream(path);
		prop.load(fin);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
		
	}
	
	// return driver in initialize functions
	// Type event and click event
	public static void initialize()
	{
		String execumode=prop.getProperty("executionmode");
		String strBrowser = prop.getProperty("browser");
		if (execumode.equalsIgnoreCase("local"))
		{	
		if (strBrowser.equalsIgnoreCase("chrome"))
		  {
			 
			ChromeOptions handlingssl = new ChromeOptions();
			handlingssl.setAcceptInsecureCerts(true);
			 WebDriverManager.chromedriver().setup();
			  driver= new ChromeDriver(handlingssl);
			  //driver = new ChromeDriver (handlSSLErr);
			  
		  }
		  
		  else if (strBrowser.equalsIgnoreCase("edge"))
		  {

			  WebDriverManager.chromedriver().setup();
			  driver= new EdgeDriver();
		  }
			
		 try {
				
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(50));
			driver.manage().window().maximize();
		    driver.manage().deleteAllCookies();
		    driver.get(prop.getProperty("url"));
		    if(driver.getPageSource().contains("Sign in as a different user")) {
				
				System.out.println("Windows Authentication Required!");
				
				driver.findElement(By.id("ctl00_PlaceHolderMain_HLinkLoginAsAnother")).click();
				
				
				Thread.sleep(2000);
				
				Runtime.getRuntime().exec("src/test/resources/authentication/WindowsAuthentication_AWTest8.exe");
				
				Thread.sleep(5000);
				}
				else {
					System.out.println("Single Sign On Authentication!");
				}
				
				String expected_text = driver.findElement(By.id("ctl00_PlaceHolderMain_lblRestWord")).getText();
				if (expected_text.contains("Client Tracking System (ACT)")) {
						System.out.println("Authentication is successful and expected text is present!");
					}
					else {
						System.out.println("Authentication is not successful and expected text is not present!");
					}
		 }
		 catch (Exception e) {
				e.printStackTrace();
			}
		 
		}
		
		else
		{
			
			String node=prop.getProperty("node");
			
			DesiredCapabilities capability =  new DesiredCapabilities();
			capability.setCapability(CapabilityType.BROWSER_NAME, "chrome");
		
			capability.setBrowserName("chrome");
			capability.setPlatform(Platform.XP);
			
			//WebDriver driver;
			//WebDriverManager.chromedriver().setup();
			  try {
				driver= new RemoteWebDriver(new URL(node),capability);
				driver.get(prop.getProperty("url"));
				//Assert.assertEquals("ACT Home", driver.getTitle());
				
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		    
				
		}
	
	public static void initializeBIReport()
	{
		String strBrowser = prop.getProperty("browser");
		 if (strBrowser.equalsIgnoreCase("chrome"))
		  {
			  WebDriverManager.chromedriver().setup();
			  driver= new ChromeDriver();
			  
		  }
		  
		  else if (strBrowser.equalsIgnoreCase("edge"))
		  {

			  WebDriverManager.chromedriver().setup();
			  driver= new EdgeDriver();
		  }
			
		 try {
				
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(50));
			driver.manage().window().maximize();
		    driver.manage().deleteAllCookies();
		    driver.get(prop.getProperty("Reporturl"));
		    if(driver.getPageSource().contains("Sign in as a different user")) {
				
				System.out.println("Windows Authentication Required!");
				
				driver.findElement(By.id("ctl00_PlaceHolderMain_HLinkLoginAsAnother")).click();
				
				
				Thread.sleep(2000);
				
				Runtime.getRuntime().exec("src/test/resources/authentication/WindowsAuthentication_AWTest8.exe");
				
				Thread.sleep(5000);
				}
				else {
					System.out.println("Single Sign On Authentication!");
				}
				
				String expected_text = driver.findElement(By.xpath("//div[text()='BIReports']")).getText();
				if (expected_text.contains("BIReports")) {
						System.out.println("Authentication is successful and expected text is present!");
					}
					else {
						System.out.println("Authentication is not successful and expected text is not present!");
					}
		 }
		 catch (Exception e) {
				e.printStackTrace();
			}
		    
		}
	
	public static WebDriver  returnDriver()
	
	{
		
		return driver;
		
		
		
		
	}
	
	//XML File Reader
	
	public static Map<String,String> xmlfileReader()
	{

		HashMap<String, String> values = new HashMap<String, String>();
        //String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><user><kyc>123</kyc><address>test</address><resiFI>asds</resiFI></user>";
        //Document xml = convertStringToDocument(xmlString);
        String path = System.getProperty("user.dir")
				 + "//src//test//resources//TestData//testData.xml";
        File file = new File(path);
    	//DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();  
    	//Document document = documentBuilder.parse(file); 
        //Document xml = convertStringToDocument(document);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
      try
      {
            builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
//      
        Node user = doc.getFirstChild();
        NodeList childs = user.getChildNodes();
        Node child;
        

        for (int i = 0; i < childs.getLength(); i++) {
            child = childs.item(i);
            if (child instanceof Text) {
                continue;
            }
            System.out.println(child.getNodeName());
            System.out.println(child.getTextContent());
         
        values.put(child.getNodeName().trim(), child.getTextContent().trim());
        
        
        }
      }
        
        catch(Exception e)
        {
        	e.printStackTrace();
        }
      
      return values;
      

	}
	
	public static void closeAllBrowsers()
	{
		
		try{
			driver.quit();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
	
	
	



	