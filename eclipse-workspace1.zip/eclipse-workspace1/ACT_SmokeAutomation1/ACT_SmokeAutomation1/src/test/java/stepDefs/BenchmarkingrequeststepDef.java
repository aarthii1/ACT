package stepDefs;

import java.util.Map;



import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import pages.Benchmarkingrequest;
import pages.HomePage;



public class BenchmarkingrequeststepDef extends TestBase {

	    
		Map<String, String> values = xmlfileReader();
		Benchmarkingrequest request;
		HomePage homePage ;
		
		
		
	    @Given("Launching application")
		public void Launch_application() 
		{
			
			try {
			initialize();
			//Map<String, String> values = xmlfileReader();
			
			//System.out.println("Root element name is: " + values);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
		 }
		 
		
		@Given("User is On home Page")
		public void User_is_on_Home_page()
		{
		  try
		  {
			homePage = new HomePage();
		  	homePage.userOnHomePageValidation();
		  	
		  }
		  catch(Exception e)
		  {
				e.printStackTrace();
		  }
		}
	
		@When("User selects the Benchmarking Request")
		public void User_selects_the_Benchmarking_Request()
		{
			try
			{
				request = new Benchmarkingrequest();
				request.clickBenchmarkButton();
		   }
			
		   catch(Exception e)
		   {
				e.printStackTrace();
		   }	
		}
		
		@Then("User is on the Benchamarking Request page")
         public void User_is_on_the_Benchamarking_Request_page()
         {
			try
			{
				
			
        	 request = new Benchmarkingrequest();
			 request.verifyBenchmarkPage();
			 
		   }
		   catch(Exception e)
		   {
					e.printStackTrace();
		   }		
       }

         @When("User select a client through searcher")
         public void User_select_a_client_through_searcher()
         {
           try
           {
        	   
           
        	 request = new Benchmarkingrequest();
        	 request.selectCompany();
           }	 
           catch(Exception e)
		   {
					e.printStackTrace();
		   }		
           
         }

         @Then("User validates its details")
         public void User_validates_its_details()
         {
        	try 
        	{
        		
        	 request = new Benchmarkingrequest();
        	 request.verifyBenchmark();
           }
        	 catch(Exception e)
 		   {
 					e.printStackTrace();
 		   }		
            
       }
        
         
        @After
     	public void takescreenshot(Scenario scenario)
     	{
     		try
     		{ 
     			Utility.generateScreenshot(scenario);
     		
     		}
     		
     		catch(Exception e)
     		{
     			e.printStackTrace();
     		}
     		
     	}
}
		
		
		
		
		
	
	
	

