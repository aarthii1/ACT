package stepDefs;

import java.util.List;
import java.util.Map;

import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Dashboard;
import pages.HomePage;
import pages.SearchPolicy;
import pages.ViewPolicy;

public class SearchPolicystepDef extends TestBase{

	SearchPolicy searchpolicy;
	HomePage homepage;
	Dashboard dashboard;
	ViewPolicy viewpolicy;
	
	@Given("Login to application")
	public void login_to_application() {
		try { 
			initialize();
			Map<String, String> values = xmlfileReader();
			
			System.out.println("Root element name is: " + values);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}		
	}
	
	@Then("Home page is displayed")
	public void home_page_is_displayed() {
		try
		{
			homepage = new HomePage();
			
			homepage.userOnHomePageValidation();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User selects Policy Search option")
	public void user_selects_policy_search_option() {
	   try
	   {
		   dashboard =new Dashboard();
			
			dashboard.navigateToPolicyListSearch();
			
		    searchpolicy = new SearchPolicy();
		    Assert.assertTrue(searchpolicy.verifySearchPolicy());
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	
	@When("Search for the layer number")
	public void search_for_the_layer_number(DataTable data) {
		try {
			
			 List<List<String>> d = data.asLists();
				
			 String Layer = d.get(0).get(0);
			 searchpolicy = new SearchPolicy();
			 searchpolicy.click_on_layertxtbox(Layer);
			 searchpolicy.click_on_search();
			 
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User validate the layer number")
	public void user_validate_the_layer_number() {
		try {
			  
			 searchpolicy = new SearchPolicy();
			 
			 searchpolicy.layernumber_validation();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks on view policy icon")
	public void user_clicks_on_view_policy_icon() {
		try {
            viewpolicy = new ViewPolicy();
			
			viewpolicy.navigate_to_view_policy_screen();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("View policy page should display")
	public void view_policy_page_should_display() {
		try {
            viewpolicy = new ViewPolicy();
			
			viewpolicy.validate_user_on_view_policy_page();
			
			Thread.sleep(3000);
			 
			 closeAllBrowsers();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	 @After
		public void takescreenshot(Scenario scenario)
		{
			try
			{Utility.generateScreenshot(scenario);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
}
	
