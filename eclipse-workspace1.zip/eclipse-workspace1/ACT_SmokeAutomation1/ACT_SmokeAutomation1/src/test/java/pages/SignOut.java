package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;

public class SignOut extends TestBase{
	
	//Menu
	@FindBy(xpath = "//span[@id='zz15_Menu_t']")
	WebElement ClickOnMenu;
	
	//Sign Out Button
	@FindBy(xpath="//*[@id='mp1_0_3_Anchor']")
	WebElement SignOutBtn;
	
	//Sign Out Header which displays after Sign Out action
	@FindBy(xpath="//div[@id='s4-simple-content']/h1")
	WebElement SignOutSuccHeader;
	
	public SignOut() {
		try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void clickOnMenu()
	{
		try {
			ClickOnMenu.click();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clickOnSignOut() {
		try {
			SignOutBtn.click();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void verifySignOut() {
		try {
			Assert.assertTrue(SignOutSuccHeader.isDisplayed());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
