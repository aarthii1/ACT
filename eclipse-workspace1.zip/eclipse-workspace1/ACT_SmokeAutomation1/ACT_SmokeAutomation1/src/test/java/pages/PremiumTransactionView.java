package pages;

import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class PremiumTransactionView extends TestBase{
	@FindBy(xpath="//h2[contains(text(),'Premium Transactions Pending for Approval')]")
	WebElement PremiumTransactionPendingScreen;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_TransactionType')]")
	WebElement TransactionTypeTextBox;
	
	@FindBy(xpath="//input[contains(@name,'Filter_TransactionType')]")
	WebElement TransactionTypeFilter;
	
	@FindBy(xpath="//*[@id='ctl00_PlaceHolderMain_radGridPTViewHeader_ctl00__0']/td[6]")
	WebElement TransactionTypeResults;
	
	@FindBy(xpath="//img[@id='ctl00_onetidHeadbnnr2']")
	WebElement AonLogo;
	
	@FindBy(xpath="//h2[contains(text(),'View All Premium Transactions By Team And Expiration Dates')]")
	WebElement PremiumTransactionApprovedScreen;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_TeamName')]")
	WebElement TeamNameTextBox;
	
	@FindBy(xpath="//input[contains(@name,'RDIFPolicyExpiryDate_text')]")
	WebElement ExpiryDateTextBox;
	
	@FindBy(xpath="//input[contains(@name,'Filter_PolicyExpiryDate')]")
	WebElement ExpiryDateFilter;
	
	@FindBy(xpath="//a/span[(text()='GreaterThan')]")
	WebElement GreaterThan;
	
	@FindBy(xpath="//*[@id='ctl00_PlaceHolderMain_radGridPTViewTeamHeader_ctl00__0']/td[3]")
	WebElement expiryDateResult;
	
	@FindBy(xpath="//h2[contains(text(),'Installments Due By Month')]")
	WebElement PremiumPendingInstallmentsScreen;
	
	@FindBy(xpath="//input[contains(@name,'Filter_TeamName')]")
	WebElement TeamNameFilter;
	
	@FindBy(xpath="//*[@id='ctl00_PlaceHolderMain_radGridPTViewTeamHeader_ctl00__0']/td[2]")
	WebElement TeamNameResult;
	
	@FindBy(xpath="//h2[contains(text(),'Disapproved Premium Transactions')]")
	WebElement PremiumDisapprovedScreen;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_ClientName')]")
	WebElement ClientNameTextBox;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_PolicyNumber')]")
	WebElement PolicyNumberTextBox;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_ProgramName')]")
	WebElement ProgramNameTextBox;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_Layer')]")
	WebElement LayerNoTextBox;
	
	@FindBy(xpath="//input[contains(@name,'RDIFDisApprovedDate_text')]")
	WebElement DisApprovedDateTextBox;
	
	@FindBy(xpath="//input[contains(@name,'FilterTextBox_Author')]")
	WebElement AuthorTextBox;
	
	@FindBy(xpath="//input[contains(@name,'Filter_Layer')]")
	WebElement LayerNoFilter;
	
	@FindBy(xpath="//*[@id='ctl00_PlaceHolderMain_radGridPTViewHeader_ctl00__0']/td[4]")
	WebElement LayerNoResult;
	
	WebElementActions webeleactions;
	public PremiumTransactionView() {
		try {
			
			PageFactory.initElements(driver, this);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean verifyPreTraPendAppScreen()
	{
		return(PremiumTransactionPendingScreen.isDisplayed());
		
	}
	
	public void TransactionTypeBoxValidation()
	{
		try {

		Assert.assertTrue(TransactionTypeTextBox.isDisplayed());
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void applyTransactionTypeFilter(String type)

	{
		TransactionTypeTextBox.sendKeys(type);
		
		TransactionTypeFilter.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
	public boolean transactionTypeFilterresults(String type)
	{
		boolean flag= false;
		
		try
		{
		
		if ((TransactionTypeResults.getText()).contains(type))
			
			{System.out.println(TransactionTypeResults.getText());
		
			flag =true;
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
		
	}
	
	public void click_on_aon_logo() {
		try {
			
			AonLogo.click();
			
			Thread.sleep(5000);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean verifyPreTraApprovedAppScreen()
	{
		return(PremiumTransactionApprovedScreen.isDisplayed());
		
	}
	
	public void TeamNameBoxValidation()
	{
		try {

		Assert.assertTrue(TeamNameTextBox.isDisplayed());
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void ExpiryDateBoxValidation()
	{
		try {

		Assert.assertTrue(ExpiryDateTextBox.isDisplayed());
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void expirationDateFilter(String date) {
	
		try {
			ExpiryDateTextBox.sendKeys(date);
			
			ExpiryDateFilter.click();
			
			Thread.sleep(6000);
			
			ExpiryDateFilter.click();
			
			GreaterThan.click();
			
			Thread.sleep(6000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void expiryDateResult() {
		try {
			Assert.assertTrue(expiryDateResult.isDisplayed());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean verifyPreTraPendInstAppScreen()
	{
		return(PremiumPendingInstallmentsScreen.isDisplayed());
		
	}
	
	public void teamNameFilter(String name) {
		
		try {
			TeamNameTextBox.sendKeys(name);
			
			TeamNameFilter.click();
			
			Thread.sleep(6000);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void teamNameResult() {
		try {
			Assert.assertTrue(TeamNameResult.isDisplayed());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean verifyPreTraDisapprAppScreen() {
		
			return(PremiumDisapprovedScreen.isDisplayed());
		
	}
	
	public void disAppTextBoxValidation() {
		try {
			Assert.assertTrue(ClientNameTextBox.isDisplayed());
			
			Assert.assertTrue(PolicyNumberTextBox.isDisplayed());
			
			Assert.assertTrue(ProgramNameTextBox.isDisplayed());
			
			Assert.assertTrue(LayerNoTextBox.isDisplayed());
			
			Assert.assertTrue(DisApprovedDateTextBox.isDisplayed());
			
			Assert.assertTrue(AuthorTextBox.isDisplayed());
			
			Assert.assertTrue(TransactionTypeTextBox.isDisplayed());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void layerNoFilter(String layerno) {
		
		try {
			LayerNoTextBox.sendKeys(layerno);
			
			LayerNoFilter.click();
			
			Thread.sleep(6000);
			
			LayerNoFilter.click();
			
			GreaterThan.click();
			
			Thread.sleep(6000);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void layerNoResult() {
	try {
		Assert.assertTrue(LayerNoResult.isDisplayed());
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	}
}
