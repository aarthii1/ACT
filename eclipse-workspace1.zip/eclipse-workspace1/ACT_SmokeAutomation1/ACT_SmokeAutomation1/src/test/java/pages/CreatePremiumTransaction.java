package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class CreatePremiumTransaction extends TestBase {

    WebElementActions webeleactions;
	
	Dashboard dashboard;
	
	//For transaction type
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_lblTransactionTypeValue")
	WebElement TransType;
	
	//for policy number
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_lblPolicyNumberValue")
	WebElement PolicyNo;
	
	//for layer
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_lblLayerValue")
	WebElement layer;
	
	//for carrier
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_lblCarrierValue")
	WebElement carrier;
	
	//for effective date
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_lblPolicyEffectiveDateValue")
	WebElement Effectivedate;
	
	//for expiration date
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_lblPolicyExpiryDate")
	WebElement Expirationdate;
	
	//for revenue
	@FindBy(xpath="//input[contains(@id,'RecurringRevenue_Input')]")
    WebElement Revenue;
	
	//for Cap commission
	@FindBy(xpath="//input[contains(@id,'CappedCommission_Input')]")
	WebElement CapCommission;
	
	//for comment
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_radtxtComments_contentIframe")
	WebElement Comment;
	
	//for select coverage button
	@FindBy(xpath="//input[@value='Select Coverage']")
	WebElement SelCoverage;
	
	//for coverage
	@FindBy(xpath="//input[contains(@id,'rcbCoverage_Input')]")
	WebElement Coverage;
	
	//for Premium
	@FindBy(xpath="//input[contains(@id,'txtPremium_text')]")
	WebElement Premium;
	
	//for Commission
	@FindBy(xpath="//input[contains(@id,'CommissionPct_text')]")
	WebElement Commission;
	
	//for Commission fee
	@FindBy(xpath="//input[contains(@id,'Commission_text')]")
	WebElement Commisionfee;
	
	//for fee
	@FindBy(xpath="//input[contains(@id,'radtxtFee_text')]")
	WebElement fee;
	
	//for FeeType dropdown
	@FindBy(xpath="//a[contains(@id,'rcbFeeType_Arrow')]")
	WebElement feeType;
	
	//for revenue type
	@FindBy(xpath="//a[contains(@id,'rcbRevenueType_Arrow')]")
	WebElement RevenueType;
	
	//for Insert button
	@FindBy(xpath="//input[@title='Insert']")
	WebElement Insert;
	
	//for save
	@FindBy(xpath="//input[contains(@id,'btnSave_input')]")
	WebElement save;
	
	//for pop up confirmation
	@FindBy(id="ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_butOk_input")
	WebElement Confirmation;
	
	@FindBy(xpath="//tr[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00__0']")
	WebElement gridData;
	
	//**************************************************
	
	//Create Premium Transaction Header
	@FindBy(xpath="//h2[contains(text(),'Create Premium Transaction')]")
	WebElement CreatePreTran;
	
	//Transaction Type
	@FindBy(xpath="//span[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_lblTransactionTypeValue']")
	WebElement TransactionType;
	
	//Recurring Revenue
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_radcmbRecurringRevenue_Input")
	WebElement RecurRev;
	
	//Recurring Revenue - No
	@FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_radcmbRecurringRevenue_DropDown']/div/ul/li[text()='No']")
	WebElement RecurRevValue;
	
	//Recurring Revenue Value
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_radcmbRecurringRevenue_Input")
	WebElement RecurringRevValue;
	
	//Capped Commission
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_radcmbCappedCommission_Input")
	WebElement CappedCom;
	
	//Capped Commission Value
	@FindBy(id="ctl00_PlaceHolderMain_RadPanelBar1_i0_radcmbCappedCommission_Input")
	WebElement CappedComValue;
	
	
	//Select Coverage Option
	@FindBy(xpath="//input[@value='Select Coverage']")
	WebElement SelectCoverage;
	
	//Coverage Text Box
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbCoverage_Input']")
	WebElement CoverageTxtBox;
	
	//Premium Text Box
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtPremium_text']")
	WebElement PremiumTxtBox;
	
	//Commission Percent
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtCommissionPct_text']")
	WebElement CommissionPercent;
	
	//Commission $
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtCommission_text']")
	WebElement CommissionDol;
	
	//Fee
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_radtxtFee_text']")
	WebElement Fee;
	
	//Fee Type
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbFeeType_Input']")
	WebElement FeeType;
	
	//Revenue Type
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbRevenueType_Input']")
	WebElement RevType;
	
	//Insert Button
	@FindBy(xpath="//input[@title='Insert']")
	WebElement InsertBtn;
	
	//Grid Data After Insert
	@FindBy(xpath="//tr[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00__0']")
	WebElement GridData;
	
	//Submit for approval Button
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_radbtnSave_input']")
	WebElement SubmitApprBtn;
	
	//Extension Effective Date Calendar icon
	@FindBy(xpath="//a[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_dtExtensionInceptionDate_popupButton']")
	WebElement ExtEffCalBtn;
	
	//Extension Expiry Date
	@FindBy(xpath="//a[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_dtExtensionDate_popupButton']")
	WebElement ExtExpiryCalBtn;
	
	//Extension sent for approval pop-up
	@FindBy(xpath="//span[@id='ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_lblMessage']")
	WebElement ExtAppPopup;
	
	//Pop-up ok button
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_butOk_input']")
	WebElement ExtAppOkBtn;
	
	//Layer
	@FindBy(xpath="//span[contains(@id,'LayerValue')]")
	WebElement LayerValue;
	
	//Policy Number
	@FindBy(xpath="//span[contains(@id,'PolicyNumberValue')]")
	WebElement PolicyNumberValue;
	
	//Carrier Value
	@FindBy(xpath="//span[contains(@id,'CarrierValue')]")
	WebElement CarrierValue;
	
	//Policy Effective Date Value
	@FindBy(xpath="//span[contains(@id,'PolicyEffectiveDateValue')]")
	WebElement PolicyEffDateValue;
	
	//Policy Expiration Date Value
	@FindBy(xpath="//span[contains(@id,'PolicyExpiryDateValue')]")
	WebElement PolicyExpDateValue;
	
	//Comments
	@FindBy(xpath="//iframe[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_radtxtComments_contentIframe']")
	WebElement Comments;
	
	//Coverage Validation
	@FindBy(xpath="//span[contains(@id,'CoverageID')]")
	WebElement CoverageIDValue;
	
	
  public CreatePremiumTransaction() {
		
		try {
			
		PageFactory.initElements(driver, this);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public boolean verifyTransactiontype(String Transactiontype) {
		
		boolean flag = false;
		
		try
		   {
			if(TransType.getText().equalsIgnoreCase(Transactiontype))
			
			{
				flag = true;
			}
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}
	
	public void verifyTransactiondetails() {
		
		try
		{
			Assert.assertTrue(layer.isDisplayed());
			
			Assert.assertTrue(PolicyNo.isDisplayed());
			
			Assert.assertTrue(carrier.isDisplayed());
			
			Assert.assertTrue(Effectivedate.isDisplayed());
			
			Assert.assertTrue(Expirationdate.isDisplayed());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void revenueDetails() {
		
		try
		   {
            
			webeleactions= new WebElementActions();
			
			webeleactions.isValuePresentinTxtBx(CapCommission);
			
			webeleactions.isValuePresentinTxtBx(Revenue);
			
			Comment.sendKeys("testing");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	

	public void selectCoverage() {
		
		try
		{
			SelCoverage.click();
			
            webeleactions = new WebElementActions();
			
			webeleactions.Explicitwait(Coverage);
			
			 String data = Coverage.getAttribute("value");
			    
			 Assert.assertEquals(data, "Employment Practices Liability(EPL)");
			 
			 Thread.sleep(2000);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void premiumDetails(String Premium1, String Commission1, String fee1) {
		
		try
		  {
			Premium.sendKeys(Premium1);
			
			Thread.sleep(2000);
			
			Commission.sendKeys(Commission1);
			
//			Thread.sleep(2000);
			
			fee.sendKeys(fee1);
			
//			Thread.sleep(2000);
			
            webeleactions= new WebElementActions();
			
		    webeleactions.isValuePresentinTxtBx(Commisionfee);
			
		  }
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void feeTypeDetail() 
	{
		try
		{
			feeType.click();
			
			Thread.sleep(3000);
			
	List<WebElement> options = driver.findElements(By.xpath("//div[contains(@id,'FeeType_DropDown')]/div/ul/li"));
	
	    Thread.sleep(3000);
	    
	    for(int i=0; i<=options.size()-1; i++) {
			  
		  	if(options.get(i).getText().equalsIgnoreCase("Aon Bermuda Limited Fee(ABL )")) 
		  	{
		  		options.get(i).click();
	
		  		break;
		  	}
		  
		  }
	    
//	   webelementactions = new WebElementActions();
//	  
//	   webelementactions.selectCombobox(FeeType,options,"Aon Bermuda Limited Fee(ABL )");
//	   
	   Thread.sleep(4000);
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void revenueTypeDetails() {
		
		try
		  {
			RevenueType.click();
			
			Thread.sleep(3000);
			
		List<WebElement> option1 = driver.findElements(By.xpath("//div[contains(@id,'RevenueType_DropDown')]/div/ul/li"));
		
		   Thread.sleep(3000);	
		   
		   for(int i=0; i<=option1.size()-1; i++) {
				  
			  if(option1.get(i).getText().equalsIgnoreCase("New Existing (NE)")) 
			  {
			  	option1.get(i).click();
		
			  	break;
			   }
			  
		   }
		   
//		   webelementactions = new WebElementActions();
//		  
//		   webelementactions.selectCombobox(RevenueType,option1,"New Existing (NE)");
//		   
		   Thread.sleep(2000);
		  }
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


    public void insertCoverage() {
	try {
		
		Insert.click();
		
		webeleactions = new WebElementActions();
		
		webeleactions.Explicitwait(GridData);
		
		dashboard =new Dashboard();
		
		Assert.assertTrue(dashboard.VerifyContactAccountscreen());
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

    public void saveTransaction() {
	   try
	      {
		   
		  save.click();
		  Thread.sleep(4000);
		  
		  Confirmation.click();
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

 //****************************************Karthik's code********************************************************************************************
    
	public void wait_until_premium_page_load() {
		try {
			webeleactions = new WebElementActions();
			webeleactions.Explicitwait(CreatePreTran);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void user_on_premium_page_validation() {
		try {
			Assert.assertTrue(CreatePreTran.isDisplayed());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void transaction_type_validation(String extType) {
		try {
			Assert.assertEquals(TransactionType.getText(), extType);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fill_premiumtr_details() {
		try {
			webeleactions = new WebElementActions();
			
			Actions action = new Actions(driver);
			
			action.doubleClick(RecurRev).perform();
			
			RecurRevValue.click();
			
			
			
			Thread.sleep(3000);
			
			//Capped Commission Values
			List<WebElement> CappedComValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_radcmbCappedCommission_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(CappedCom, CappedComValues, "No");
			
			
			//DateValues
			List<WebElement> ExtEffDateValues = driver.findElements(By.xpath("//table[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_dtExtensionInceptionDate_calendar_Top']/tbody/tr/td/a"));
			
			webeleactions.datePickerSelection(ExtEffCalBtn, ExtEffDateValues);
			
			List<WebElement> ExtExpiryDateValues= driver.findElements(By.xpath("//table[@id='ctl00_PlaceHolderMain_RadPanelBar1_i0_dtExtensionDate_calendar_Top']/tbody/tr/td/a"));
			
			webeleactions.datePickerSelection(ExtExpiryCalBtn, ExtExpiryDateValues);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fill_coverage_details() {
		try {
			
			webeleactions = new WebElementActions();
			
			SelectCoverage.click();
			
			webeleactions.Explicitwait(CoverageTxtBox);
			
			webeleactions.isValuePresentinTxtBx(CoverageTxtBox);
			
			PremiumTxtBox.sendKeys("500");
			
			CommissionPercent.sendKeys("5");
			
			CommissionDol.click();
			
			webeleactions.isValuePresentinTxtBx(CommissionDol);
			
			Fee.sendKeys("2");
			
			//Fee Type Values
			List<WebElement> FeeTypeValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbFeeType_DropDown']/div/ul/li"));
			
			
			webeleactions.selectCombobox(FeeType, FeeTypeValues, "Aon Bermuda Limited Fee(ABL )");
			

			//Revenue Type Values
			List<WebElement> RevTypeValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_RadPanelBar1_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbRevenueType_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(RevType, RevTypeValues, "New Existing (NE)");
			
			InsertBtn.click();
			
			webeleactions.Explicitwait(GridData);
			
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void user_clicks_on_submit_approval() {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", SubmitApprBtn);
			
			SubmitApprBtn.click();
			
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void user_validates_submission() {
		try {
			Assert.assertEquals("Extension Premium Transaction has been successfully created and sent for approval.", ExtAppPopup.getText());
			
			ExtAppOkBtn.click();
			
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void validate_details() {
		try {
			
			String layerVal = LayerValue.getText();
			
			String policyVal = 	PolicyNumberValue.getText();

			String carrierVal = CarrierValue.getText();
			
			String policyEffDateVal = PolicyEffDateValue.getText();
			
			String policyExpDateVal = PolicyExpDateValue.getText();
			
			String recuRev = RecurringRevValue.getAttribute("value");
				
			String capCom = CappedComValue.getAttribute("value");
			
			//System.out.println("Recurring Revenue: "+recuRev);
			//System.out.println("Capped Commision: "+capCom);
			
			
			Assert.assertFalse(layerVal.isEmpty());
			Assert.assertFalse(policyVal.isEmpty());
			Assert.assertFalse(carrierVal.isEmpty());
			Assert.assertFalse(policyEffDateVal.isEmpty());
			Assert.assertFalse(policyExpDateVal.isEmpty());
			
			Assert.assertEquals(recuRev, "Yes");
			Assert.assertEquals(capCom,"No");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fill_multi_layer_tran_details() {
		try {
			
			
			Comments.sendKeys("Test Comment");
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void coverage_field_validation(String value) {
		try {
			String covgValue = CoverageIDValue.getText();
			
			Assert.assertEquals(value, covgValue);
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void validate_new_business_submission() {
		try {
			
		
			Assert.assertEquals("New Business Premium Transaction has been successfully created and sent for approval.", ExtAppPopup.getText());
			
			ExtAppOkBtn.click();
			
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	}


