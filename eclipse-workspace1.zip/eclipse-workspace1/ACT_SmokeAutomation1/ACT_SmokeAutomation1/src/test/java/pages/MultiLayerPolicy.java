package pages;

import static org.testng.Assert.assertFalse;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class MultiLayerPolicy extends TestBase{
	
	
	//Expand client button xpath
	@FindBy(xpath="//tr[contains(@id,'ClientList_ctl00__0')]//td[1]")
	WebElement ExpandClient;
		
	//View Program Icon
	@FindBy(xpath="//img[contains(@id,'ctl04_imgProgram')]")
	WebElement ViewProgramIcon;
	
	//View Program Header
	@FindBy(xpath="//h2[contains(text(),'View Program')]")
	WebElement ViewProgramHeader;
	
	//For click the Addpolicy button
	@FindBy(xpath="//input[contains(@id,'AddPolicyT_input')]")
	WebElement AddPolicyBtn;
	
	//Update details Pop-up
	@FindBy(xpath="//iframe[@name='rwValidateASTDetails']")
	WebElement UpdateDetScreen;
	
	//Continue Button
	@FindBy(xpath="//a[@id='ctl00_PlaceHolderMain_btnContinueWithoutUpdate']")
	WebElement ContinueButton;
	
	//Client Name
	@FindBy(xpath="//span[contains(@id,'ClientName')]")
	WebElement ClientName;
	
	//Program name
	@FindBy(xpath="//span[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_lblProgramName']")
	WebElement ProgramName;
	
	//Layer Number Text Box
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rntxtLayerNumber_text']")
	WebElement LayerNumber;
	
	//Policy Number
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rtxtPolicyNumber_text']")
	WebElement PolicyNumber;
	
	//Policy Effective date
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rdpPolicyEffectiveDate_dateInput_text']")
	WebElement PolicyEffecDate;

	//Policy Expiration Date
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rdpPolicyExpirationDate_dateInput_text']")
	WebElement PolicyExpDate;
	
	//Other Broker
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbOtherBrokerPlacement_Input")
	WebElement OtherBroker;
	
	//Punitive Wrap
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbPunitiveWrap_Input")
	WebElement PunitiveWrap;
	
	
	//RunOff
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbRunOffPolicy_Input")
	WebElement RunOff;
	
	
	//Foreign
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbForeignPlacement_Input")
	WebElement ForeignPlacement;
	

	//Quota Share
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbQuotaShareLayer_Input")
	WebElement QuotaShare;


	//MidTerm Bor
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbMidTermBOR_Input")
	WebElement MidtermBor;

	
	//SPS
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbSPS_Input")
	WebElement SPS;
	
	//Carrier Group
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbCarrierGroup_Input")
	WebElement CarrierGroup;

	//Carrier
	@FindBy(id="ctl00_PlaceHolderMain_rpbPolicy_i0_rcbCarrier_Input")
	WebElement Carrier;
	
	//Attachment Point
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rntxtAttachmentPoint_text']")
	WebElement AttachmentPoint;
	
	//Comments
	@FindBy(xpath="//textarea[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rtxtComments_text']")
	WebElement Comments;
	
	//Save Button
	@FindBy(id="ctl00_PlaceHolderMain_rbtnSaveBottom_input")
	WebElement SaveBtn;
	
	//Add Coverage Button
	@FindBy(xpath="//input[@value='Add Coverage']")
	WebElement AddCoverageBtn;
	
	//Coverage Details
	@FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbCoverage']")
	WebElement CoverageDetails;
	
	//Coverage Field
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbCoverage_Input']")
	WebElement CoverageField;
	
	//Limit
	
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rntxtLimit_text']")
	WebElement Limit;
	
	//Aggregate Limit
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rntxtAggregateLimit_text']")
	WebElement AggregateLimit;
	
	//Aggregate Limit Type
	@FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbAggLimitType_Input']")
	WebElement AggLimitType;
	
	//CPP Flag

	@FindBy(xpath="//input[contains(@id,'chkIsCPP')]")
	WebElement CPPFlag;
	
	//Insert Button
	@FindBy(xpath="//input[@title='Insert']")
	WebElement InsertBtn;
	
	//GridData 1
	@FindBy(xpath="//tr[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00__0']")
	WebElement GridData1;
	
	//GridData 2
	@FindBy(xpath="//tr[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00__1']")
	WebElement GridData2;
	
	//Confirmation Pop-Up
	@FindBy(xpath="//div[@class='rwDialogPopup radconfirm']/div[contains(text(),'Do you want to attach any documents for this policy?')]")
	WebElement ConfirmPopup;
		
	//Pop up No Button
	@FindBy(xpath="//span[@class='rwInnerSpan'][text()='No']")
	WebElement NoBtn;
	
	//Create Policy Message
	@FindBy(xpath="//span[@id='ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_lblMessage']")
	WebElement PolicyMessage;
	
	//Create Policy Pop Up
	@FindBy(xpath="//div[@id='RadWindowWrapper_ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox']")
	WebElement PolicyPopUp;
	
	//Yes Button
	@FindBy(xpath="//input[@value='Yes']")
	WebElement YesBtn;
	
	WebElementActions webeleactions;
	
	CreatePremiumTransaction createpretran;
	
	public MultiLayerPolicy() {
		
		try {
			
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void exapand_client_and_click_view_program_icon() {
		
		try 
		    {
			
			ExpandClient.click();
			
			Thread.sleep(3000);
			
			ViewProgramIcon.click();
			
			Thread.sleep(3000);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void validate_user_on_view_program_page() {
		try {
			Assert.assertTrue(ViewProgramHeader.isDisplayed());
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_on_add_policy() {
		try {
			AddPolicyBtn.click();
			Thread.sleep(4000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void validating_pop_up() {
		try {
			if(UpdateDetScreen.isDisplayed()) {
				//Assert.assertTrue(UpdateDetScreen.isDisplayed());
				driver.switchTo().frame(UpdateDetScreen);
				ContinueButton.click();
				driver.switchTo().defaultContent();
			}
			else {
				WebElement page = driver.findElement(By.xpath("//h2[contains(text(),'Create Policy')]"));
				Assert.assertTrue(page.isDisplayed());
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void validate_policy_information() {
		try {
			
			
			String clientNameval =ClientName.getText();
			
			String programNameval = ProgramName.getText();
			
			
			
			//System.out.println("ClientName: "+ clientNameval + "ProgramName: "+ programNameval);
			
			Assert.assertFalse(clientNameval.isEmpty());
			
			Assert.assertFalse(programNameval.isEmpty());
			
			webeleactions = new WebElementActions();
			
			
			webeleactions.isValuePresentinTxtBx(PolicyEffecDate);
			
			webeleactions.isValuePresentinTxtBx(PolicyExpDate);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fill_policy_information() {
		try {
			
			//Layer
			LayerNumber.sendKeys("1");
			Thread.sleep(2000);
			
			//Policy Number
			PolicyNumber.sendKeys("TestPolicy1");
			
			//OtherBroker
			List<WebElement> OtherBrokerValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbOtherBrokerPlacement_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(OtherBroker, OtherBrokerValues, "No");
			
			//Punitive Wrap
			List<WebElement> PunWrapValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbPunitiveWrap_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(PunitiveWrap, PunWrapValues, "No");
			
			//Run Off Policy
			List<WebElement> RunOffValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbRunOffPolicy_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(RunOff, RunOffValues, "No");
			
			//Foreign Placement
			List<WebElement> ForeignPlacementValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbForeignPlacement_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(ForeignPlacement, ForeignPlacementValues, "No");
			
			//Quota Share
			
			List<WebElement> QuotaShareValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbQuotaShareLayer_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(QuotaShare, QuotaShareValues, "No");
			
			//Midterm Bor
			List<WebElement> MidtermBorValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbMidTermBOR_DropDown']/div/ul/li"));
			webeleactions.selectCombobox(MidtermBor, MidtermBorValues, "No");
			
			//SPS
			List<WebElement> SPSValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbSPS_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(SPS, SPSValues, "No");
			
			//Carrier Group
			List<WebElement> CGValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbCarrierGroup_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(CarrierGroup, CGValues, "Baldwin & Lyons");
			
			Thread.sleep(3000);
			
			//Carrier
			List<WebElement> CarrierValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i0_rcbCarrier_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(Carrier, CarrierValues, "Protective Specialty Insurance Company");
			
			Thread.sleep(3000);
			
			//Attachment Point
			AttachmentPoint.sendKeys("1");
			
			//Comments
			Comments.sendKeys("Test");
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fill_coverage_details()
	{
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			
			AddCoverageBtn.click();
			
			webeleactions = new WebElementActions();
			
			webeleactions.Explicitwait(CoverageDetails);
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			
			//Coverage Field
			List<WebElement> CoverageFieldValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbCoverage_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(CoverageField, CoverageFieldValues, "Employment Practices Liability (EPL)");
			
			Thread.sleep(3000);
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			
			Limit.sendKeys("1000");
			
			AggregateLimit.sendKeys("500");
			
			//Aggregate Limit Type
			List<WebElement> AggLimitTypeValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbAggLimitType_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(AggLimitType, AggLimitTypeValues, "Annual Aggregate");
			
			//CPP Flag
			CPPFlag.click();
			
			//Insert Button
			InsertBtn.click();
			
			Thread.sleep(3000);
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			
			
			//Click on Coverage Button
			AddCoverageBtn.click();
			
			Thread.sleep(3000);
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			
			Thread.sleep(3000);
			//Coverage Field
			List<WebElement> CoverageFieldValues1 = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbCoverage_DropDown']/div/ul/li"));
			webeleactions.selectCombobox(CoverageField, CoverageFieldValues1, "Program EPL (PEPL)");
			
			Thread.sleep(3000);
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			//Limit
			Limit.sendKeys("1000");
			
			//Aggregate Limit
			AggregateLimit.sendKeys("500");
			
			//Aggregate Limit Type
			List<WebElement> AggLimitTypeValues1 = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_rpbPolicy_i1_radgrdCoverageDetails_ctl00_ctl02_ctl02_rcbAggLimitType_DropDown']/div/ul/li"));
			webeleactions.selectCombobox(AggLimitType, AggLimitTypeValues1, "Annual Aggregate");
			
			//CPP Flag
			CPPFlag.click();
			
			//Insert Button
			InsertBtn.click();
			
			Thread.sleep(3000);
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			
			Assert.assertTrue(GridData1.isDisplayed());
			
			Assert.assertTrue(GridData2.isDisplayed());
			
			
			

		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_on_save_button() {
		try {
			
			SaveBtn.click();
			
			Thread.sleep(2000);
			
			Assert.assertTrue(ConfirmPopup.isDisplayed());
			
			NoBtn.click();
			
			webeleactions = new WebElementActions();
			
			
			webeleactions.Explicitwait(PolicyPopUp);
			
			String message = PolicyMessage.getText();
			
			//System.out.println(message);
			
			Assert.assertEquals(message, "Policy TestPolicy1 has been successfully created. Do you want to create New Business Premium Transaction?");
			
			YesBtn.click();
			
			createpretran = new CreatePremiumTransaction();
			
			createpretran.wait_until_premium_page_load();
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
