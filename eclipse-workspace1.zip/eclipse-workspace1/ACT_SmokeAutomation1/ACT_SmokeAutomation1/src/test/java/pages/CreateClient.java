package pages;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import commonUtils.WebElementActions;
import base.TestBase;
import commonUtils.DynamicClientNameCreation;
import commonUtils.Utility;

public class CreateClient extends TestBase{
	
	DynamicClientNameCreation dyclientname;
	WebElementActions webeleactions;
	Utility utility;
	
	//Create Client Header
	@FindBy(xpath="//h2[contains(text(),\"Create Client\")]")
	WebElement CreateClientHeader;
	
	//Client Name Text Box
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_cboClientName_Input")
	WebElement ClientNameTxtBox;
	
	//GV Key Search Button
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_btnSearchGVKey_input")
	WebElement GVKeySearchBtn;
	
	//Bridge Client Number Text Box
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtBridgeClientID_text")
	WebElement BridgeClientNoTxtBox;
	
	//Search Screen of GV Key
	@FindBy(xpath="//iframe[contains(@name,'rwSearchSNPGVKey')]")
	WebElement SearchGVKeyIframe;
	
	//Company Name Text Box
	@FindBy(id="ctl00_PlaceHolderMain_txtCompanyNameSearch_text")
	WebElement CompanyNameTxtBox;
	
	//Search GV Key Value Button
	@FindBy(id="ctl00_PlaceHolderMain_btnSearch_input")
	WebElement SearchGVKeyBtn;
	
	//GV Key Value
	@FindBy(xpath="//table[@id='ctl00_PlaceHolderMain_radGridResults_ctl00']/tbody/tr/td[text()='001004']")
	WebElement SelectGVKeyValue;

	//Company Status Drop Down
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_cboCompanyStatus_Input")
	WebElement CmpStatusDrpDwn;
	
	//Bridge Client Search Button
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_btnSearchBridgeClientID_input")
	WebElement SearchBridgeCltNoBtn;
	
	//Bridge Client Number Search Screen
	@FindBy(xpath="//iframe[contains(@name,'rwSearchBridgeClient')]")
	WebElement SearchBrdgeCltNoIframe;
	
	//Bridge Client Number Value
	@FindBy(xpath="//table[@id='ctl00_PlaceHolderMain_radGridResults_ctl00']/tbody/tr/td[text()='10000000']")
	WebElement SelectBridgeCltNo;
	
	//Bridge Comments Text Box
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtBridgeComments_text")
	WebElement BridgeComments;
	
	//Country Value
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_cboCountry_Input")
	WebElement CountryValue;
	
	//City Value
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtCity_text")
	WebElement CityValue;
	
	//State Value
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_cboState_Input")
	WebElement StateValue;
	
	//ZIP Code
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtZIP_text")
	WebElement ZIPValue;
	
	//Bridge Client Number
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtBridgeClientID_text")
	WebElement BridgeCltNoValue;
	
	//Bridge Client Name
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtBridgeClientName_text")
	WebElement BridgeCltNameValue;
	
	//GV Key
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtGVKey_text")
	WebElement GVKeyValue;
	
	//GV Company Name
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_txtGVCompanyName_text")
	WebElement GVCmpNameValue;
	
	//Industry - Sector 
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtSNPGICSSector_text")
	WebElement IdstyCSectorValue;
	
	//Industry - Industry
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtSNPGICSIndustry_text")
	WebElement IdstyCIndustryValue;
	
	//Industry - Group
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtSNPGICSIndustryGroup_text")
	WebElement IdstyCGroupValue;
	
	//Industry - Sub-Industry
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtSNPGICSSubIndustry_text")
	WebElement IdstyCSubIDYValue;
	
	//ARS Office Name
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_cboARSOfficeName_Input")
	WebElement CoOfiARSNameDrpDwn;
	
	//FSG Office
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_cboFSGClientOffice_Input")
	WebElement CoOfiFSGCODrpDwn;
	
	//FSG Team Drop Down
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_cboClientTeamName_Input")
	WebElement CoOfiFSGTeamDrpDwn;
	
	//FSG Team Name Value
	@FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_cboClientTeamName_DropDown']/div/ul/li[text()='E&O Team2']")
	WebElement CoOfiFSGTeamName;
	
	//ARS Office Search Button
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_btnSearchARSOfficeContact_input")
	WebElement SearchCoOfiARSOfiContactBtn; 
	
	//ARS Contact Search Screen
	@FindBy(xpath="//iframe[contains(@name,'rwSearchARSContact')]")
	WebElement SearchARSOfcCtIframe;
	
	//ARS Contact Name 
	@FindBy(xpath="//table[@id='ctl00_PlaceHolderMain_radGridResults_ctl00']/tbody/tr/td/nobr[text()='Aaliyah Denay Reed']")
	WebElement SelectARSOfcCtName;
	
	//Company Status
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_cboARSContact_Input")
	WebElement CoOfiARSOfiContact;
	
	//Alternative Asset Management
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboAlternativeAssetManagement_Input")
	WebElement AlterAsstMgmt;

	//Parent Company Text Box
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboParentCompany_Input")
	WebElement PrntCmpTxtBox;
	
	//Parent Company Value
	@FindBy(xpath="//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboParentCompany_DropDown']/div/ul/li[text()=\" State Building Company LLC\"]")
	WebElement PrntCmpValue;
	
	//Managed Asset Text Box
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_txtManagedAssets_text")
	WebElement MngdAssetTxtBox;
	
	//Public Debt
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboPublicDebtMarketing_Input")
	WebElement PublicDebtDrpDwn;
	
	//As Of Date
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_dtManagedAssetsAsOfDate_dateInput_text")
	WebElement AsOfDate;
	
	//Save Button - Bottom area
	@FindBy(xpath="//a/input[@id='ctl00_PlaceHolderMain_btnSaveClientBottom_input']")
	WebElement SaveBtn;
	
	//GV Key Confirmation
	@FindBy(id="RadWindowWrapper_ctl00_PlaceHolderMain_ucMsgBoxDuplicateGVKey_rwMessageBox")
	WebElement GVKeyConfirmation;
	
	//Confirmation Yes Button
	@FindBy(xpath="//a/input[@value='Yes']")
	WebElement ConfirmBtn;
	
	//Client Creation Message Box
	@FindBy(id="ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_lblMessage")
	WebElement ClientCreationMsg;
	
	//Cancel (No) Button
	@FindBy(id="ctl00_PlaceHolderMain_ucMsgBox_rwMessageBox_C_butCancel_input")
	WebElement CancelBtn;
	
	//SIC Code Search Button
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_btnSearchSIC_input")
	WebElement SearchSICCodeBtn;
	
	//NAICS Code Search Button
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_btnSearchNAICS_input")
	WebElement SearchNAICSCodeBtn;
	
	//Search Screen SIC Code
	@FindBy(xpath="//iframe[contains(@name,'SICCode')]")
	WebElement SearchSICCodeIframe;
	
	//SIC CODE Value
	@FindBy(xpath="//table[@id='ctl00_PlaceHolderMain_radGridResults_ctl00']/tbody/tr/td[text()='0111']")
	WebElement SICValue;
	
	//Search Screen NAICS COde
	@FindBy(xpath="//iframe[contains(@name,'NAICSCode')]")
	WebElement SearchNAICSCodeIframe;
	
	//NAICS CODE Value
	@FindBy(xpath="//table[@id='ctl00_PlaceHolderMain_radGridResults_ctl00']/tbody/tr/td[text()='111110']")
	WebElement NAICSValue;
	
	//Country of Registration
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboRegistrationCountry_Input")
	WebElement RegCountry;
	
	//State of Registration
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboRegistrationState_Input")
	WebElement RegState;
	
	//Number of Employees Text Box
	@FindBy(xpath="//input[contains(@id,'NumberOfEmployees_text')]")
	WebElement NoOfEmployeesTxtBox;
	
	//Market Capitalization Text Box
	@FindBy(xpath="//input[contains(@id,'MarketCapitalization_text')]")
	WebElement MarketCapitalizationTxtBox;
	
	//Total Annual Revenue
	@FindBy(xpath="//input[contains(@id,'TotalAnnualRevenue_text')]")
	WebElement TotalAnnualRevTxtBox;
	
	//Total Assets Text Box
	@FindBy(xpath="//input[contains(@id,'Assets_text')]")
	WebElement TotalAssetsTxtBox;
	
	//Total Liabilities Text Box
	@FindBy(xpath="//input[contains(@id,'Liabilities_text')]")
	WebElement TotalLiabilitiesTxtBox;
	
	//Share Holder Equity Text Box
	@FindBy(xpath="//input[contains(@id,'Equity_text')]")
	WebElement ShareHolderEquityTxtBox;
	
	
	//Market Cap AsOfDate
	@FindBy(xpath="//input[contains(@id,'MarketCapAsOfDate_dateInput_text')]")
	WebElement MarCapAsOfDate;

	//Total Annual Revenue AsOfDate
	@FindBy(xpath="//input[contains(@id,'RevenueAsOfDate_dateInput_text')]")
	WebElement TotalRevenueAsOfDate;

	//Total Assets AsOfDate
	@FindBy(xpath="//input[contains(@id,'AssetsAsOfDate_dateInput_text')]")
	WebElement TotalAssetsAsOfDate;

	//Total Liabilities
	@FindBy(xpath="//input[contains(@id,'LiabilitiesAsOfDate_dateInput_text')]")
	WebElement TotalLiabilitiesAsOfDate;

	//Share Holder Equity AsOfDate
	@FindBy(xpath="//input[contains(@id,'EquityAsOfDate_dateInput_text')]")
	WebElement EquityAsOfDate;

	//Cancel Bottom Button
	@FindBy(xpath="//a/input[@id='ctl00_PlaceHolderMain_btnCancelBottom_input']")
	WebElement CancelButton;
	
	//Yes Button
	@FindBy(xpath="//span[text()='Yes']")
	WebElement YesBtn;
	
	//Industry codes
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtSICCode_text")
	WebElement SICCodeValue;
	
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtNAICSCode_text")
	WebElement NAICSCodeValue;
	
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtSICDesc_text")
	WebElement SICDesc;
	
	@FindBy(id="ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i2_txtNAICSDesc_text")
	WebElement NAICSDesc;
	
	public CreateClient() {
		try {
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void enterClientName() {
		try {
			
			dyclientname = new DynamicClientNameCreation();
			
			String finalClientName = dyclientname.clientname();
			
			ClientNameTxtBox.sendKeys(finalClientName);
			
			BridgeClientNoTxtBox.click();
			
		}
			
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void clickOnGVSearch() {
		try {
			GVKeySearchBtn.click();
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void clearCmpNameTxtBx() {
		try {
			driver.switchTo().frame(SearchGVKeyIframe);
			CompanyNameTxtBox.click();
			CompanyNameTxtBox.clear();
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void clickOnSearchGVKeyBtn() {
		try {
			SearchGVKeyBtn.click();
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void selectGVKeyValue() {
		try {
			
			Actions action = new Actions(driver);
			
			action.doubleClick(SelectGVKeyValue).perform();
			
			driver.switchTo().defaultContent();
		}
		catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void selectCmpStatus() {
		try {
			
			List <WebElement> CompanyStatusValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_cboCompanyStatus_DropDown']/div/ul/li"));
			
			webeleactions = new WebElementActions();
			
			webeleactions.selectCombobox(CmpStatusDrpDwn,CompanyStatusValues,"Public");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clickOnBridgeCltNoSrchBtn() {
		try {
		SearchBridgeCltNoBtn.click();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectBridgeClientNo() {
	try {	
		
		
		driver.switchTo().frame(SearchBrdgeCltNoIframe);
		
		
		Actions action = new Actions(driver);
		
		action.doubleClick(SelectBridgeCltNo).perform();
		
		
		driver.switchTo().defaultContent();
		
		BridgeComments.sendKeys("Test");
		
		
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	}
	
	public void client_info_validation() {
		try {
			
			webeleactions = new WebElementActions();
			
			webeleactions.isValuePresentinTxtBx(CountryValue);
			
			webeleactions.isValuePresentinTxtBx(CityValue);
			
			webeleactions.isValuePresentinTxtBx(StateValue);
			
			webeleactions.isValuePresentinTxtBx(ZIPValue);
			
			webeleactions.isValuePresentinTxtBx(BridgeCltNoValue);
			
			webeleactions.isValuePresentinTxtBx(BridgeCltNameValue);
			
			webeleactions.isValuePresentinTxtBx(GVKeyValue);
			
			webeleactions.isValuePresentinTxtBx(GVCmpNameValue);
			
			
		}
		catch( Exception e) {
			e.printStackTrace();
		}
	}
	
	public void industry_codes_validation(){
		try {
			
			webeleactions = new WebElementActions();
			
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", AlterAsstMgmt);
			
			webeleactions.isValuePresentinTxtBx(IdstyCSectorValue);
			
			webeleactions.isValuePresentinTxtBx(IdstyCIndustryValue);
			
			webeleactions.isValuePresentinTxtBx(IdstyCGroupValue);
			
			webeleactions.isValuePresentinTxtBx(IdstyCSubIDYValue);
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void contact_office_selection() {
		try {
			
			
			
			webeleactions = new WebElementActions();
			
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", CreateClientHeader);
			
			
			List <WebElement> ARSOfficeName = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_cboARSOfficeName_DropDown']/div/ul/li"));
					
			List <WebElement> FSGClientOffice = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i1_cboFSGClientOffice_DropDown']/div/ul/li"));
			
			
			webeleactions = new WebElementActions();
			
			webeleactions.selectCombobox(CoOfiARSNameDrpDwn,ARSOfficeName,"Alexandria, LA"); 
			
			webeleactions.selectCombobox(CoOfiFSGCODrpDwn,FSGClientOffice,"Chicago"); 
			
			Thread.sleep(12000);
			
			
			SearchCoOfiARSOfiContactBtn.click();
			
			driver.switchTo().frame(SearchARSOfcCtIframe);
			
			Actions action = new Actions(driver);
			
			action.doubleClick(SelectARSOfcCtName).perform();
			
			driver.switchTo().defaultContent();
			
			
			CoOfiFSGTeamDrpDwn.click();
			
			CoOfiFSGTeamName.click();
			
			Thread.sleep(2000);		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void contact_office_validation() {
		try {
			webeleactions = new WebElementActions();
			
			webeleactions.isValuePresentinTxtBx(CoOfiARSNameDrpDwn);
			
			webeleactions.isValuePresentinTxtBx(CoOfiFSGCODrpDwn);
			
			webeleactions.isValuePresentinTxtBx(CoOfiARSOfiContact);
			
			webeleactions.isValuePresentinTxtBx(CoOfiFSGTeamDrpDwn);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void market_info_assmgmt_selection() {
		try {
			
			webeleactions = new WebElementActions();
			
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", AlterAsstMgmt);
			
			Thread.sleep(3000);
			
			List <WebElement> AlterAsstMgmtValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboAlternativeAssetManagement_DropDown']/div/ul/li/div/label"));
			
			webeleactions.selectCombobox(AlterAsstMgmt,AlterAsstMgmtValues,"Hedge Fund");
			
			Thread.sleep(3000);
			
			PrntCmpTxtBox.click();
			
			//validation for managed asset field
			Assert.assertTrue(MngdAssetTxtBox.isDisplayed());
			
			
		}
		catch (Exception e) {
			
			e.printStackTrace();
			
		}
	}
	
	public void market_info_fill_details() {
		try {
			
			webeleactions = new WebElementActions();
			
			utility = new Utility();
			
			List <WebElement> PublicDebtValue = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboPublicDebtMarketing_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(PublicDebtDrpDwn,PublicDebtValue,"No");
			
			PrntCmpTxtBox.sendKeys("Empire");
			
			PrntCmpValue.click();
			
			MngdAssetTxtBox.sendKeys("100");
			
			String todayDate = utility.todaysDate();
			
			//System.out.println(todayDate);
			
			AsOfDate.sendKeys(todayDate);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_on_Save_button() {
		try {
			
			SaveBtn.click();
			Thread.sleep(5000);
			
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void validating_gv_pop_up() {
		try {
			Assert.assertTrue(GVKeyConfirmation.isDisplayed());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_on_cnfrm_btn() {
		try {

			ConfirmBtn.click();
			
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void validating_pop_up() {
		try {
			
			
			String CltCrtMsg = ClientCreationMsg.getText();
			
			
			Assert.assertTrue(CltCrtMsg.contains("has been created successfully"));
			
			//System.out.println(ClientCreationMsg.getText());
			
			String nwClientMessage = ClientCreationMsg.getText();
			
			String[] splitClientMessage = nwClientMessage.split(" ");
			
			String nwClientName = splitClientMessage[1];
			
			//System.out.println(nwClientName);
			
			//Updates the clientname.properties file with newly created client name.
			utility = new Utility();
			
			utility.updateConfig("clientname", nwClientName, "//src//test//resources//configFiles//clientname.properties");
			
			CancelBtn.click();
			
			Thread.sleep(5000);
			
		
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fill_client_details() {
		try {
			
			List <WebElement> CountryValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_cboCountry_DropDown']/div/ul/li"));
			
			webeleactions = new WebElementActions();
			
			webeleactions.selectCombobox(CountryValue,CountryValues,"UNITED STATES");
			
			List <WebElement> StateValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i0_cboState_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(StateValue,StateValues,"ILLINOIS");
			
			ZIPValue.sendKeys("60191");
			
			CityValue.sendKeys("Wood Dale");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void client_info_validation_prod() {
		try {
			
			webeleactions = new WebElementActions();
			
			webeleactions.isValuePresentinTxtBx(CountryValue);
			
			webeleactions.isValuePresentinTxtBx(CityValue);
			
			webeleactions.isValuePresentinTxtBx(StateValue);
			
			webeleactions.isValuePresentinTxtBx(ZIPValue);
			
			webeleactions.isValuePresentinTxtBx(BridgeCltNoValue);
			
			webeleactions.isValuePresentinTxtBx(BridgeCltNameValue);
		
			
			
		}
		catch( Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fill_industry_codes() {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			
			jse.executeScript("arguments[0].scrollIntoView()", SaveBtn);
			
			Thread.sleep(3000);
			
			//Block for filling SIC Code
			
			SearchSICCodeBtn.click();
			Thread.sleep(5000);
			
			driver.switchTo().frame(SearchSICCodeIframe);
			
			Actions action = new Actions(driver);
			
			action.doubleClick(SICValue).perform();
			
			driver.switchTo().defaultContent();
			
			Thread.sleep(5000);
			
			//Block for filling NAICS Code
			SearchNAICSCodeBtn.click();
			
			Thread.sleep(5000);
			
			driver.switchTo().frame(SearchNAICSCodeIframe);
			
			action.doubleClick(NAICSValue).perform();
			
			driver.switchTo().defaultContent();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void market_info_fill_details_prod() {
		try {
			
			webeleactions = new WebElementActions();
			
			utility = new Utility();
			
			List <WebElement> PublicDebtValue = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboPublicDebtMarketing_DropDown']/div/ul/li"));
			
			webeleactions.selectCombobox(PublicDebtDrpDwn,PublicDebtValue,"No");
			
			PrntCmpTxtBox.sendKeys("Empire");
			
			PrntCmpValue.click();
			
			MngdAssetTxtBox.sendKeys("20");
			
			String todayDate = utility.todaysDate();
			
			//System.out.println(todayDate);
			
			AsOfDate.sendKeys(todayDate);
			
			//STATE OF REGISTRATION
			List <WebElement> RegCountryValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboRegistrationCountry_DropDown']/div/ul/li"));
			
			List <WebElement> RegStateValues = driver.findElements(By.xpath("//div[@id='ctl00_PlaceHolderMain_wzdCompanyStatusChange_rpnlCreateClient_i3_cboRegistrationState_DropDown']/div/ul/li"));
			
			
			webeleactions = new WebElementActions();
			
			webeleactions.selectCombobox(RegCountry,RegCountryValues,"UNITED STATES"); 
			
			webeleactions.selectCombobox(RegState,RegStateValues,"ALASKA"); 
			
			NoOfEmployeesTxtBox.sendKeys("100");

			MarketCapitalizationTxtBox.sendKeys("100");

			TotalAnnualRevTxtBox.sendKeys("500");

			TotalAssetsTxtBox.sendKeys("100");

			TotalLiabilitiesTxtBox.sendKeys("50");

			ShareHolderEquityTxtBox.sendKeys("50");

			MarCapAsOfDate.sendKeys(todayDate);
			
			TotalRevenueAsOfDate.sendKeys(todayDate);
			
			TotalAssetsAsOfDate.sendKeys(todayDate);
			
			TotalLiabilitiesAsOfDate.sendKeys(todayDate);
			
			EquityAsOfDate.sendKeys(todayDate);
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_on_cancel_button() {
		try {
			
			CancelButton.click();
			
			Thread.sleep(5000);
			
			webeleactions = new WebElementActions();
			
			webeleactions.Explicitwait(YesBtn);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_on_yes_button() {
		try {
			YesBtn.click();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void industry_codes_validation_prod() {
		try {
			
			webeleactions = new WebElementActions();
			
			webeleactions.isValuePresentinTxtBx(SICCodeValue);
			webeleactions.isValuePresentinTxtBx(NAICSCodeValue);
			webeleactions.isValuePresentinTxtBx(SICDesc);
			webeleactions.isValuePresentinTxtBx(NAICSDesc);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
