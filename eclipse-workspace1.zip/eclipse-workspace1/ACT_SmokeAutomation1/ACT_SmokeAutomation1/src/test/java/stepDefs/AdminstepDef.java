package stepDefs;

import java.util.Map;

import base.TestBase;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AdminPage;
import pages.HomePage;

public class AdminstepDef extends TestBase{

	HomePage homepage;
	AdminPage adminpage;
	
	@Given("Launches the act application")
	public void launches_the_act_application() {
		try { 
			initialize();
			Map<String, String> values = xmlfileReader();
			
			System.out.println("Root element name is: " + values);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}	
		
	}
	
	@Then("user is on homepage")
	public void user_is_on_homepage() {
		try
		{
			homepage = new HomePage();
			
			homepage.userOnHomePageValidation();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User expands Adminsetup")
	public void user_expands_adminsetup() {
		try {
			adminpage = new AdminPage();
			adminpage.click_on_Adminsetups();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User verify all the pages under adminsetup")
	public void user_verify_all_the_pages_under_adminsetup() {
		try {
			adminpage = new AdminPage();
			adminpage.click_on_Aggregate();
			adminpage.click_on_ARS();
			adminpage.click_on_Audit();
			adminpage.click_on_Cancellation();
			adminpage.click_on_Carriercode();
			adminpage.click_on_Carrierg();
			adminpage.click_on_Carriergp();
			adminpage.click_on_Competitor();
			adminpage.click_on_Specificlimit();
			adminpage.click_on_Teammember();
			adminpage.click_on_Coverage();
			adminpage.click_on_Coveragegroup();
			adminpage.click_on_Deductible();
			adminpage.click_on_Fee();
			adminpage.click_on_FOS();
			adminpage.click_on_FSG();
			adminpage.click_on_FSGTeams();
			adminpage.click_on_Interdatory();
			adminpage.click_on_Parent();
			adminpage.click_on_Region();
			adminpage.click_on_Benchmarking();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
