package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;

public class ViewClient extends TestBase {
	
	//input#ctl00_PlaceHolderMain_radGridClientList_ctl00_ctl02_ctl02_FilterTextBox_ClientName
	
	
	@FindBy(css="input#ctl00_PlaceHolderMain_radGridClientList_ctl00_ctl02_ctl02_FilterTextBox_ClientName")
	WebElement ClientnameFilter;
	
	@FindBy(xpath="//h2")
	WebElement Header;
	
//	@FindBy(xpath="//input[@name='ctl00$PlaceHolderMain$btnAddProgram']")
	@FindBy(id="ctl00_PlaceHolderMain_btnAddProgram_input")
	WebElement AddProgram;
	
	public ViewClient()
	{
		try {
		PageFactory.initElements(driver, this);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void viewClientValidation() 
	{
		
		try
		{
		
		//if ((Header.getText()).equalsIgnoreCase("View Client"))
			
			//{
		
			Assert.assertTrue(Header.isDisplayed());
		//	}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
	

	public void clickOnAddProgramButton()
	{
		AddProgram.click();
		
	}
	
	
	
}