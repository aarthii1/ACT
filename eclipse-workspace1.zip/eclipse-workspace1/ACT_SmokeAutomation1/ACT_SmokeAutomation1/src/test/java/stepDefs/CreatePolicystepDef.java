package stepDefs;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AllClientsPage;
import pages.ApprovalPT;
import pages.CreatePolicy;
import pages.CreatePremiumTransaction;
import pages.Dashboard;
import pages.HomePage;
import pages.PTDisApprovals;
import pages.SignOut;

public class CreatePolicystepDef extends TestBase{
	
    Dashboard dashboard;
	
	AllClientsPage allclients;
	
	CreatePolicy createpolicy;
	
	HomePage homepage;
	
	SignOut signout;
	
	Utility utility;
	
	PTDisApprovals ptmultiapproval;
	
	ApprovalPT approvals;
	
	CreatePremiumTransaction createpremiumtrans;

	@Given("Launch Application")
	public void launch_application() {
		
		try {
		initialize();
		Map<String, String> values = xmlfileReader();
		
		System.out.println("Root element name is: " + values);
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	@Then("User is on Home page")
	public void user_is_on_home_page() {
		
		try
		{
			homepage = new HomePage();
			
			homepage.userOnHomePageValidation();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	@When("User clicks on the All Clients")
	public void user_clicks_on_the_all_clients() {
		try
		{
		
		dashboard =new Dashboard();
		
		dashboard.navigateToAllClients();
		
		Assert.assertTrue(dashboard.veifyAllClients());
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("user search for the expected client name")
	public void user_search_for_the_expected_client_name() {
		try
		{
			
            allclients = new AllClientsPage();
			
			allclients.allClientsvalidation();
			
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			allclients.applyClientNameFilter(SPClientName);
	}
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
	}
	
	@Then("Expected client name should display")
	public void expected_client_name_should_display() {
		
		try
		{ 
			allclients = new AllClientsPage();
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			Assert.assertTrue(allclients.verifyClientFilterresults(SPClientName));
		}
        catch(Exception e)
		
		{
			e.printStackTrace();
		}
	}
	
	@Then("User clicks on the view program icon")
	public void user_clicks_on_the_view_program_icon() {
	   
		try
		{
			
		createpolicy = new CreatePolicy();
		
		createpolicy.selectClient();
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
	}
	
	@Given("User is on View program page")
	public void user_is_on_view_program_page() {
		
		try
		{
			dashboard =new Dashboard();
			
			Assert.assertTrue(dashboard.verifyViewProgramPage());
		}
		
         catch(Exception e)
		
		{
			e.printStackTrace();
		}
	}
	
	@When("User clicks on Add policy")
	public void user_clicks_on_add_policy() {
	   
		try {
			
			createpolicy = new CreatePolicy();
			
			//createpolicy.addPolicy();
			createpolicy.click_on_add_policy();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User is on the Create Policy page")
	public void user_is_on_the_create_policy_page() {
		
		try
		{
			
             dashboard = new Dashboard();
			
			Assert.assertTrue(dashboard.verifyCreatePolicy());
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	@When("User fill all the mandatory details")
	public void user_fill_all_the_mandatory_details(DataTable data) {
		
		try 
		{
			List<List<String>> d = data.asLists();
			
			String layer = d.get(0).get(0);
			String policy = d.get(0).get(1);
			
		createpolicy = new CreatePolicy();
		
		createpolicy.layerValidation(layer, policy);
		
		createpolicy.allfieldsValidation();
	
		createpolicy.carrierGpfieldValidation();
		
		createpolicy.carrierfieldValidation();
	
        }
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User fill coverage details")
	public void user_fill_coverage_details(DataTable data) {
		
		try
		{
			List<List<String>> d = data.asLists();
			
			String limit1 = d.get(0).get(0);
			String Agglimit1 = d.get(0).get(1);
			String PrimaryDec1 = d.get(0).get(2);
			String Secondarydec1 = d.get(0).get(3);
			
			createpolicy = new CreatePolicy();
			
			createpolicy.addCoverage();
			
			createpolicy.coverageDetails(limit1, Agglimit1, PrimaryDec1, Secondarydec1);;
			
			createpolicy.insertCoverage();
		
		}

		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User clicks on the Save button")
	public void user_clicks_on_the_save_button() {
		
		try
		{
			createpolicy =new CreatePolicy();
			
			createpolicy.contactAccountTeamValidation();
			
			createpolicy.savePolicy();
			
			createpolicy.validatePopUp();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Given("User is on the Premium Transactionpage")
	public void user_is_on_the_premium_transactionpage() {
		
		try
		{
			dashboard = new Dashboard();
			Assert.assertTrue(dashboard.verifyPremiumTransactionPage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Given("the Transaction type should be as {string}")
	public void the_transaction_type_should_be_as(String Transactiontype) {
		
		try {
			createpremiumtrans = new CreatePremiumTransaction();
			
			createpremiumtrans.verifyTransactiontype(Transactiontype);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User fills the Transactions Details")
	public void user_fills_the_transactions_details() {
		
		try {
			createpremiumtrans = new CreatePremiumTransaction();
			
			createpremiumtrans.verifyTransactiondetails();
			
			createpremiumtrans.revenueDetails();
			
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User fills the coverage details")
	public void user_fills_the_coverage_details(DataTable data) {
		
		try {
			
           List<List<String>> d = data.asLists();
			
			String Premium1= d.get(0).get(0);
			String Commission1 = d.get(0).get(1);
			String fee1 = d.get(0).get(2);
			
			createpremiumtrans.selectCoverage();
			
			createpremiumtrans.premiumDetails(Premium1, Commission1, fee1);
			
			createpremiumtrans.feeTypeDetail();
			
			createpremiumtrans.revenueTypeDetails();
			
			createpremiumtrans.insertCoverage();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User clicks on Submit for Approval")
	public void user_clicks_on_submit_for_approval() {
		
		try {
			
			createpremiumtrans = new CreatePremiumTransaction();
			
			createpremiumtrans.saveTransaction();	
			
			Thread.sleep(4000);
			
			dashboard =new Dashboard();
			
			dashboard.verifyViewClient();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	 @Given("User clicks on PT Approval")
	 public void user_clicks_on_pt_approval() {
		
		 try {
			    dashboard =  new Dashboard();
				
				dashboard.navigateToPTapproval();
				
				boolean flag= dashboard.verifyPTApproval();
				
				Assert.assertTrue(flag);
		 }
		 catch(Exception e)
			{
				e.printStackTrace();
			}
	 }
	 
	 @When("User Search for the Client name")
	 public void user_search_for_the_client_name() {
		 try {
		

				utility = new Utility();
				
				String SPClientName = utility.getClientName();
				
				ptmultiapproval = new PTDisApprovals();
				
				ptmultiapproval.applyFilterPTapprovals(SPClientName);
				
				ptmultiapproval.clientresultsValidation(SPClientName);
					
				ptmultiapproval.clickonViewTransaction();
				 
		 }
		 catch(Exception e)
			{
				e.printStackTrace();
			}
   }
	 
	 @When("User validates the layer value as {string} and the Transaction Type value as {string}")
		public void user_validates_the_layer_value_and_the_transaction_type_values(String layerValue,String transactionTypeValue) {
			try {
				System.out.println("Layer - "+layerValue +"TType - "+transactionTypeValue);
				
				approvals = new ApprovalPT();
				
				
				approvals.validate_details("New Business", "0");
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	 
	 @Then("User Clicks on Approve button")
	 public void user_clicks_on_approve_button() {
		 try {
			 
			 approvals = new ApprovalPT();
			 approvals.click_on_approve_button();
			 
			 Thread.sleep(3000);
			 
			 closeAllBrowsers();
	 }
		 catch(Exception e)
			{
				e.printStackTrace();
			}
	 }
	 
	
	@After
	public void takescreenshot(Scenario scenario)
	{
		try
		{Utility.generateScreenshot(scenario);
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
    }
