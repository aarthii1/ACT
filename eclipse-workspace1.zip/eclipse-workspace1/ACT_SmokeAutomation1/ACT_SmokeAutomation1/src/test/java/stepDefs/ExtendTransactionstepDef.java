package stepDefs;

import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WindowType;
import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.en.*;
import pages.ApprovalPT;
import pages.CreatePremiumTransaction;
import pages.Dashboard;
import pages.HomePage;
import pages.PTDisApprovals;
import pages.SearchPolicy;
import pages.SignOut;
import pages.ViewPolicy;
import pages.PTDisApprovals;


public class ExtendTransactionstepDef extends TestBase{
	HomePage homepage;
	Dashboard dashboard;
	SearchPolicy searchpolicy;
	ViewPolicy viewpolicy;
	CreatePremiumTransaction createpretran;
	Utility utility;
	PTDisApprovals ptmultiapproval;
	ApprovalPT approvals;
	
	@Given("User Launches the ACT application")
	public void launch_act_application() {
			
		try {
			initialize();
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Then("User is on the Home Page")
	public void user_is_on_home_page() {
	 try {
		    	homepage = new HomePage();
		    	homepage.userOnHomePageValidation();
		    	
		    	
	    }
		    
		    catch(Exception e)
		{
				e.printStackTrace();
			}
	}
	
	@When("User selects Policy list Search option")
	public void user_selects_policy_list_search_option(){
		try {
			dashboard =new Dashboard();
			
			dashboard.navigateToPolicyListSearch();
			
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	@Then("Policy list Search screen should displayed")
	public void policy_list_search_screen_should_displayed() {
		try {
			dashboard =new Dashboard();
			searchpolicy = new SearchPolicy();
			Assert.assertTrue(searchpolicy.verifySearchPolicy());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("Search for the client name in Search Policy screen")
	public void search_for_the_client_name_in_search_policy_screen() {
		try {
			searchpolicy = new SearchPolicy();
			
			searchpolicy.enter_client_name();
			
			searchpolicy.click_on_search();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Expected client name displays")
	public void expected_client_name_displays() {
		try {
			searchpolicy = new SearchPolicy();
			searchpolicy.client_name_validation();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User is on the View Policy Screen")
	public void user_is_on_the_view_policy_screen() {
		try {
			
			viewpolicy = new ViewPolicy();
			
			viewpolicy.navigate_to_view_policy_screen();
			
			viewpolicy.validate_user_on_view_policy_page();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User selects Extend Policy option")
	public void user_selects_extend_policy_option() {
		try {
			
			viewpolicy = new ViewPolicy();
			
			viewpolicy.extend_policy_selection();
			
			createpretran = new CreatePremiumTransaction();
			
			createpretran.wait_until_premium_page_load();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User is on the Premium Transaction Page")
	public void user_is_on_the_premium_transaction_page() {
		try {
			
			createpretran = new CreatePremiumTransaction();
			
			createpretran.user_on_premium_page_validation();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User Validates the Transaction Type as Extension")
	public void user_validates_the_transaction_type_as_extension() {
		try {
			createpretran = new CreatePremiumTransaction();
			
			createpretran.transaction_type_validation("Extension");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User fill the Transaction details")
	public void user_fill_the_transaction_details() {
		try {
			createpretran = new CreatePremiumTransaction();
			createpretran.fill_premiumtr_details();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User fill the coverage details")
	public void user_fill_the_coverage_details() {
		try {
			createpretran = new CreatePremiumTransaction();
			createpretran.fill_coverage_details();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Given("User clicks on the Submit for Approval")
	public void user_clicks_on_the_submit_for_approval() {
		try {
			createpretran = new CreatePremiumTransaction();
			createpretran.user_clicks_on_submit_approval();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User validates the submission")
	public void user_validates_the_submission() {
		try {
			createpretran = new CreatePremiumTransaction();
			createpretran.user_validates_submission();
			
			dashboard = new Dashboard();
			
			dashboard.verifyViewClient();
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User navigates to PT Approvals page")
	public void user_navigates_to_pt_approvals_page() {
		try {
			
			dashboard =  new Dashboard();
			
			dashboard.navigateToPTapproval();
			
			boolean flag= dashboard.verifyPTApproval();
			
			Assert.assertTrue(flag);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	@And("User searches for the clientname and it displays")
	public void user_searches_for_the_clientname_and_it_displays() {
		try {
			
			utility = new Utility();
			
			String SPClientName = utility.getClientName();
			
			ptmultiapproval = new PTDisApprovals();
			
			ptmultiapproval.applyFilterPTapprovals(SPClientName);
			
			ptmultiapproval.clientresultsValidation(SPClientName);
		}
	
		catch(Exception e) {
			e.printStackTrace();
		}
}
	
	@Then("User clicks on the view transaction option")
	public void user_clicks_on_the_view_transaction_option() {
		try {
			ptmultiapproval = new PTDisApprovals();
			
			ptmultiapproval.clickonViewTransaction();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User validates the layer value as {string} and the transaction type value as {string}")
	public void user_validates_the_layer_value_and_the_transaction_type_values(String layerValue,String transactionTypeValue) {
		try {
			System.out.println("Layer - "+layerValue +"TType - "+transactionTypeValue);
			
			approvals = new ApprovalPT();
			
			
			approvals.validate_details("Extension", "0");
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Then User clicks on the Approve button for extension approval")
	public void user_clicks_on_the_approve_button_extension_approval() {
		try {
			approvals = new ApprovalPT();
			approvals.click_on_approve_button();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("Once approved User closes the browser")
	public void once_approved_user_closes_the_browser() {
		try {
			closeAllBrowsers();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
