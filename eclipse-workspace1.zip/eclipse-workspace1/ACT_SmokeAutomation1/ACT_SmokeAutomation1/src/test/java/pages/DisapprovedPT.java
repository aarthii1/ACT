package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;
import stepDefs.PTDisapprovalstepDef;

public class DisapprovedPT extends TestBase {
	
	
	//View/Search WebElement
	@FindBy(xpath="//span[text()='View/Search']")
	WebElement ViewSearch;
	
	
	//Premium Transaction view WebElement
	@FindBy(xpath="//span[text()='Premium Transactions View']")
	WebElement PremiumTransaction;
	
	//Disapproved Transaction
	@FindBy(xpath="//a[@title='View Disapproved Premium Transactions']")
	WebElement DisapprovedMenu;
	
	//ClientName Filter
	@FindBy(css="input#ctl00_PlaceHolderMain_radGridPTViewHeader_ctl00_ctl02_ctl02_FilterTextBox_ClientName")
	WebElement ClientNameFilter;
	
	//ProgramName Filter
	@FindBy(css="input#ctl00_PlaceHolderMain_radGridPTViewHeader_ctl00_ctl02_ctl02_FilterTextBox_ProgramName")
	WebElement ProgramNameFilter;
	
	//PolicyNumber Filter
	@FindBy(css="input#ctl00_PlaceHolderMain_radGridPTViewHeader_ctl00_ctl02_ctl02_FilterTextBox_PolicyNumber")
	WebElement PolicyNoFilter;
	
	//ExpandFirstRow
	@FindBy(xpath="//input[@name='ctl00$PlaceHolderMain$radGridPTViewHeader$ctl00$ctl04$GECBtnExpandColumn']")
	WebElement expandfirstrow;
	
	//ExpandFirstRow
	@FindBy(css="tr#ctl00_PlaceHolderMain_radGridPTViewHeader_ctl00__0")
	WebElement expandfirstrow1;
	
	// View Transaction link	
	@FindBy(css="a#ctl00_PlaceHolderMain_radGridPTViewHeader_ctl00_ctl06_radgrdPremiumTransactionDetails_ctl00_ctl04_lnkPremiumTransaction")
	WebElement ViewTransaction;	
	
	// View Transaction heading
	@FindBy(xpath="//h2[contains(text(),'View Premium Transaction')]")
	WebElement ViewTransactionheading;
	
	//Approval status
	@FindBy(css="span#ctl00_PlaceHolderMain_RadPanelBar1_i3_lblApprivalStatusValue")
	WebElement approvalstatusheading;
	
	 //Contacts Team section
    @FindBy(xpath="//span[contains(text(),'Contact and Account Service Team')]")
    WebElement ContactsTeam;
	
	@FindBy(css="span#ctl00_PlaceHolderMain_RadPanelBar1_i0_lblPolicyNumberValue")
	WebElement Policynumbervalue;
	
	
	WebElementActions webelementactions ;
	
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	 public DisapprovedPT() {
			try {
			PageFactory.initElements(driver, this);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	 
	 public void navigateToDisapprovedPT()
	 {
		
		 try {
			 Actions action = new Actions(driver);
		 
			
			 action.doubleClick(ViewSearch).perform();
			 
			
			Thread.sleep(1000);
			
			action.doubleClick(PremiumTransaction).perform();
			Thread.sleep(1000);
			
			action.doubleClick(DisapprovedMenu).perform();
			
		 }
		 
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
			 
	 }
		 
		 public void applyfiltertransaction(String clientname,String progname,String policyno)
		 {
			 try
			 {
				 //ClientNameFilter.sendKeys(clientname);
				 
				 //Thread.sleep(1500);
				 
				 //ProgramNameFilter.sendKeys(progname);
				 
				//Thread.sleep(500);
				 
				 			 
				 PolicyNoFilter.sendKeys(policyno+ Keys.TAB);
				 Thread.sleep(3000);
				 
				 
			 }
			 
			 catch(Exception e)
			 {
				 e.printStackTrace();
			 }
			 
		 }
		 
		 public void clickonViewTransaction()
		    {
		        try
		        {
		        		        	

		        	jse.executeScript("arguments[0].click()", expandfirstrow);
		        	
		        	Thread.sleep(1000);
		        	ViewTransaction.click();
		        	Thread.sleep(1000);
		        	Assert.assertTrue(ViewTransactionheading.isDisplayed());


		        }
		        
		        catch(Exception e)
		        {
		        	e.printStackTrace();
		        }
		    	
		    	
		    }
		 
		 public void validateTransdetails(String policyno)
		 {

			 try {
				 
				 if (Policynumbervalue.isDisplayed())
				 Assert.assertTrue(Policynumbervalue.getText().contains(policyno));
				 else
				 {
					 Thread.sleep(2000);
					 Assert.assertTrue(Policynumbervalue.getText().contains(policyno));
				 }


				 
				 jse.executeScript("arguments[0].scrollIntoView()", ContactsTeam);

				 Assert.assertTrue(approvalstatusheading.getText().contains("Disapproved"));

			 }

			 catch(Exception e)
			 {
				 e.printStackTrace(); 
			 }


		 }
		
		 
		

}
