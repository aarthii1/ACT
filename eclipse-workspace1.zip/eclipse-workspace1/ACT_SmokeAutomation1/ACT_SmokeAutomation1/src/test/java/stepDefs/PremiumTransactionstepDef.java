package stepDefs;

import base.TestBase;
import io.cucumber.java.*;
import io.cucumber.java.en.*;
import pages.Dashboard;
import pages.HomePage;
import pages.PremiumTransactionView;
import pages.SignOut;

public class PremiumTransactionstepDef extends TestBase{
	
	HomePage homepage;
	Dashboard dashboard;
	PremiumTransactionView premiumtransactionview;
	SignOut signout;
	
	
	@Given("Users launch the ACT application")
	public void launch_act_application() {
			
			try {
			initialize();
			
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Then("User is on the ACT application Homepage")
	public void user_is_on_the_act_application_homepage() {
		    try {
		    	homepage = new HomePage();
		    	homepage.userOnHomePageValidation();
		    }
		    
		    catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Given("User selects View Search option and Premium Transactions View")
	public void user_selects_view_search_option_and_premium_transactions_view() {
		try {
			dashboard = new Dashboard();
			dashboard.navigateToPremiumTransactionsView();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("Premium Transaction view should be expanded")
	public void premium_transaction_view_should_be_expanded() {
		try {
			dashboard = new Dashboard();
			dashboard.verifyPremiumPendingOption();
			dashboard.verifyPremiumApprovedOption();
			dashboard.verifyPremiumPendingInstallmentsOption();
			dashboard.verifyPremiumDisapprovedOption();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	@When("User clicks on Pending option")
	public void user_clicks_on_pending_option() {
		try {
			dashboard = new Dashboard();
			dashboard.navigateToPremiumPremiumPendingPage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Premium Transactions pending for approval screen should be open")
	public void premium_transactions_pending_for_approval_screen_should_be_open() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.verifyPreTraPendAppScreen();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User search for {string} under Transaction Type and use filter contains")
	public void user_search_for_transaction_type_and_use_filer_contains(String type) {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.TransactionTypeBoxValidation();
			
			premiumtransactionview.applyTransactionTypeFilter(type);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Transaction having type as {string} should get filtered")
	public void transaction_having_transaction_type_should_get_filtered(String type) {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			
			premiumtransactionview.transactionTypeFilterresults(type);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User navigates to the Homepage")
	public void user_navigates_to_the_homepage() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.click_on_aon_logo();
			
			homepage = new HomePage();
	    	
			homepage.userOnHomePageValidation();
			
			dashboard = new Dashboard();
			
			dashboard.navigateBackToViewSearch();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks on Approved option")
	public void user_clicks_on_approved_option() {
		try {
			dashboard = new Dashboard();
			dashboard.navigateToPremiumApprovedPage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Premium Transactions approved screen should be open")
	public void premium_transactions_approved_screen_should_be_open() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.verifyPreTraApprovedAppScreen();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User enters Expiration Date Filter by entering some value and choose greater than from filter")
	public void user_enters_expiration_date_filter_by_entering_some_value_and_choose_greater_than_from_filter() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.TeamNameBoxValidation();
			
			premiumtransactionview.ExpiryDateBoxValidation();
			
			premiumtransactionview.expirationDateFilter("04/25/2022");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("The data should get filtered out if present")
	public void the_data_should_get_filtered_out_if_present() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			premiumtransactionview.expiryDateResult();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks on Pending installment")
	public void user_clicks_on_pending_installment() {
		try {
			dashboard = new Dashboard();
			dashboard.navigateToPremiumPendingInstallmentsPage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Premium Transactions Pending installment screen should be open")
	public void premium_transactions_pending_installment_screen_should_be_open() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.verifyPreTraPendInstAppScreen();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("Verify the Team Name Filter by entering some value and choose contains from filter")
	public void verify_the_team_name_filter_by_entering_some_value_and_choose_contains_from_filter() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.TeamNameBoxValidation();
			
			premiumtransactionview.teamNameFilter("Denver");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("The teams should get filtered out if present")
	public void the_teams_should_get_filtered_out_if_present() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.teamNameResult();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User clicks on disapproved")
	public void user_clicks_on_disapproved() {
		try {
		dashboard = new Dashboard();
		
		dashboard.navigateToPremiumDisApprovedPage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("Premium Transactions disapproved screen should be open")
	public void premium_transactions_disapproved_screen_should_be_open() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			premiumtransactionview.verifyPreTraDisapprAppScreen();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("User verifies the Layer No Filter by entering some value and choose greater than from filter")
	public void user_verifies_the_layer_no_filter_by_entering_some_value_and_choose_greater_than_from_filter() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			
			premiumtransactionview.disAppTextBoxValidation();
			
			premiumtransactionview.layerNoFilter("0");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Then("The layer data should get filtered out if present")
	public void the_layer_data_Should_get_filtered_out_if_present() {
		try {
			premiumtransactionview = new PremiumTransactionView();
			premiumtransactionview.layerNoResult();
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@After("@LastScenario")
	public void sign_out_of_the_application() {
		try {
			signout = new SignOut();
			
			signout.clickOnMenu();
			
			signout.clickOnSignOut();
			
			signout.verifySignOut();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
}
