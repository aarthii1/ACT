   package pages;

	import java.text.SimpleDateFormat;
	import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.testng.Assert;

	import base.TestBase;
import commonUtils.WebElementActions;

	public class CreateProgramPage extends TestBase 
	{
		
		
		String date ;
		String four;
		String eight;
		String p6;
		String headCountValue;
		String USCountValue;
		String sumProd;
		String sumProdPerc;
		WebElementActions webElementActions;
		
		@FindBy(xpath = "//h2")
		WebElement Header;
	
		
		@FindBy(xpath = "//input[(contains(@id ,'ProgramEffectiveDate_dateInput_text' ))]")
		WebElement dateTextbox;
	    
	    @FindBy(xpath="//input[contains(@id,'Bar_i0_btnCoverageSelectionGroup_input')]")
	    WebElement clickSelectButton;
	    
	    @FindBy(xpath="//input[contains(@id,'ctl01_ctl45_ClientSelectColumnSelectCheckBox')]")
	    WebElement selectEPLCoverage;
	    
	    @FindBy(xpath="//input[@name='ctl00$PlaceHolderMain$rwCoverageGroup$C$btnCvgOk']")
	    WebElement clickOKButton;
	    
	    @FindBy(xpath="//span[contains(@id,'ProgramBar_i0_lblProgramNameValue')]")
	    WebElement programDate;
	    
	    @FindBy(xpath=" //a[contains(@id , 'ProgramBar_i0_cboEPLBrodereauReporting_Arrow')]")
	    WebElement EPlBordereau ;
	    
	    @FindBy(xpath = "//div[contains(@id , 'ProgramBar_i0_cboEPLBrodereauReporting_DropDown')]/div/ul/li[1]")
	    WebElement selectAnnual;
	    
	    @FindBy(xpath = "//input[contains(@id , 'ProgramBar_i0_txtTotalHeadCount_text')]")
	    WebElement fillTotalHeadCount;
	    
	    @FindBy(xpath="//input[contains(@id , 'Program_ProgramBar_i0_txtUS_text')]")
	    WebElement fillUSCount;
	    
	    @FindBy(xpath="//input[contains(@id , 'wzdRenewProgram_ProgramBar_i0_txtFullTime_text')]")
	    WebElement fillFullTime;
	    
	    //@FindBy(xpath="//span[contains(@id , 'ProgramBar_i0_txtTotalHeadCount_wrapper')]/input[3]")
	   // WebElement totalHeadCount;
	    
	    @FindBy(xpath="//span[contains(@id , 'Program_ProgramBar_i0_txtUS_wrapper')]/input[3]")
	    WebElement totalUSCount;
	    
	    @FindBy(xpath = "//span[contains(@id , 'ProgramBar_i0_lblNonUSValue')]")
	    WebElement totalNonUSCount;
	    
	    @FindBy(xpath="//span[contains(@id , 'Program_ProgramBar_i0_txtFullTime_wrapper')]/input[3]")
	    WebElement totalFullTime;
	    
	    @FindBy(xpath = "//span[contains(@id , 'ProgramBar_i0_lblPartTimeValue')]")
	    WebElement totalPartTime;
	    
	    @FindBy(xpath = "//a[contains(@id , 'i0_cboTop1StateCode_Arrow')]")
	    WebElement clickStateDropdown;
	    
	    @FindBy(xpath = "//div[contains(@id, 'i0_cboTop1StateCode_DropDown')]/div/ul/li[3]")
	    WebElement selectstate1;
	    
	    @FindBy(xpath="//input[contains(@id , 'i0_txtTop1StateHeadCount_text')]")
	    WebElement fillState1Value;
	    
	    @FindBy(xpath = "//a[contains(@id , 'i0_cboTop2StateCode_Arrow')]")
	    WebElement clickStateDropdown2;
	    
	    @FindBy(xpath = "//div[contains(@id, 'i0_cboTop2StateCode_DropDown')]/div/ul/li[4]")
	    WebElement selectstate2;
	    
	    @FindBy(xpath="//input[contains(@id , 'i0_txtTop2StateHeadCount_text')]")
	    WebElement fillState2Value;
	    
	    
	    @FindBy(xpath = "//a[contains(@id , 'i0_cboTop3StateCode_Arrow')]")
	    WebElement clickStateDropdown3;
	    
	    @FindBy(xpath = "//div[contains(@id, 'i0_cboTop3StateCode_DropDown')]/div/ul/li[5]")
	    WebElement selectstate3;
	    
	    @FindBy(xpath="//input[contains(@id , 'i0_txtTop3StateHeadCount_text')]")
	    WebElement fillState3Value;
	    
	    @FindBy(xpath = "//a[contains(@id , 'i0_cboTop4StateCode_Arrow')]")
	    WebElement clickStateDropdown4;
	    
	    @FindBy(xpath = "//div[contains(@id, 'i0_cboTop4StateCode_DropDown')]/div/ul/li[6]")
	    WebElement selectstate4;
	    
	    @FindBy(xpath="//input[contains(@id , 'i0_txtTop4StateHeadCount_text')]")
	    WebElement fillState4Value;
	    
	    @FindBy(xpath = "//a[contains(@id , 'i0_cboTop5StateCode_Arrow')]")
	    WebElement clickStateDropdown5;
	    
	    @FindBy(xpath = "//div[contains(@id, 'i0_cboTop5StateCode_DropDown')]/div/ul/li[7]")
	    WebElement selectstate5;
	    
	    @FindBy(xpath="//input[contains(@id , 'i0_txtTop5StateHeadCount_text')]")
	    WebElement fillState5Value;
	    
	    @FindBy(xpath="//li[@class='rpItem rpLast']/div/div/table[1]")
	    WebElement officeFields;
	    
	   @FindBy(xpath="//a[contains(@id , '_ProgramBar_i1_cboRole1_Arrow')]")
	    WebElement role1Arrow;
	    
	    @FindBy(xpath="//div[contains(@ id , '_i1_cboRole1_DropDown')]/div/ul/li[2]")
	    WebElement selectRole1;
	    
	    @FindBy(xpath="//a[contains(@id , '_ProgramBar_i1_cboRole2_Arrow')]")
	    WebElement role2Arrow;
	    
	    @FindBy(xpath="//div[contains(@ id , '_i1_cboRole2_DropDown')]/div/ul/li[4]")
	    WebElement selectRole2;
	    
	    @FindBy(xpath="//a[contains(@id , '_ProgramBar_i1_cboEmployeeId1_Arrow')]")
	    WebElement employee1Arrow;
	    
	    @FindBy(xpath="//div[contains(@id , '_i1_cboEmployeeId1_DropDown')]/div/ul/li[2]")
	    WebElement employee1Select;
	    
	   @FindBy(xpath="//input[contains(@id , 'ProgramBar_i1_btnSearchEmployee2_input')]")
	    WebElement employee2Search; 
	    
	    @FindBy(xpath="//tr[contains(@id ,'GrdEmployeeSearchResults_ctl00__0')]")
	    WebElement name1Select; 
	    
	    @FindBy(xpath="//input[@id='ctl00_PlaceHolderMain_btnOk_input']")
	    WebElement clickOkButton; 
	    
	    @FindBy(xpath="//input[(contains(@id , '_i1_txtProduction1_text'))]")
	    WebElement prod1Textbox; 
	    
	    @FindBy(xpath="//input[(contains(@id , '_i1_txtProduction2_text'))]")
	    WebElement prod2Textbox;
	    
	    @FindBy(xpath="//input[(contains(@id , '_i1_txtProduction3_text'))]")
	    WebElement prod3Textbox;
	    
	    
	    @FindBy(xpath="//span[contains(text(),'Account Service Team')]")
	    WebElement Contact;
	    
	    @FindBy(name="rwSearchEmployee")
	    WebElement empFrame;
	    
	    @FindBy(xpath="//a[text() ='Employee Name']")
	    WebElement emp;
	    
	    @FindBy(xpath="//td[(@class = 'rwTitlebar')]/table/tbody/tr/td[2]/em")
	    WebElement titleBar;
	    
	    @FindBy(xpath="//input[contains(@name , 'Main$btnSaveProgram2_input')]")
	    WebElement saveButton;
	    
	    @FindBy(xpath="//span[contains(@id ,'MsgBox_rwMessageBox_C_lblMessage')]")
	    WebElement programCreationMsg;
	    
	    @FindBy(xpath="//input[contains(@id ,'Main_ucMsgBox_rwMessageBox_C_butCancel_input')]")
	    WebElement clickNoButton;
	    
	    @FindBy(xpath="//em[text()='Duplicate Program']")
	    WebElement duplicateProgram;
	    
	    @FindBy(xpath="//input[contains(@id , 'ucMsgBox_rwMessageBox_C_butOk_input')]")
	    WebElement ClickYes;
	    
	    @FindBy(xpath="//input[contains(@id , '_i1_cboARSOfficeName_Input')]")
	    WebElement ARSOfficeNameTextbox;
	    
	    @FindBy(xpath="//input[contains(@id , '_i1_cboARSContact_Input')]")
	    WebElement ARSOfficeContactTextbox;
	    
	    @FindBy(xpath="//input[contains(@id , '_cboFSGProgramOffice_Input')]")
	    WebElement FSGProgramOfficeTextbox;
	    
	    @FindBy(xpath="//input[contains(@id , 'i1_cboFSGProgramTeamName_Input')]")
	    WebElement FSGProgramTeamNameTextbox;
	    
	    @FindBy(xpath="//em[text() = 'Create Program']")
	    WebElement createProgramConfirm;
	    
	    WebElementActions webeleactions;
	    
	    
	    
	    
	    
	    public CreateProgramPage()
		{
			try
			{
			PageFactory.initElements(driver, this);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		 }
		
	    
		public void createProgramValidation() 
		{
			
			try
			{
			
			    if ((Header.getText()).equalsIgnoreCase("Create Program"))
				
				{
			
				    Assert.assertTrue(Header.isDisplayed());
				}
			}
			
			catch(Exception e)
			{
				    e.printStackTrace();
			}
			
		}
		
			
		
		
		public String getTodayDate()
		{
			
			try 
			{
				  Date d= new Date();
		            SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		            date = formatter.format(d);
		           
				
		    }
			catch(Exception e)
			{
				e.printStackTrace();
				
			}
			return date ;	
			
		}
		
		
		 public void fillTodayDate() 	
	     {
			 try
			 {
				 
				 dateTextbox.sendKeys(date);
				 
			 }
		     catch(Exception e)
		     {
				 e.printStackTrace();
					
		      }	 
		 
	     }
		
		
		
	   public void selectCoverage()
	   {
		   
			   try {
					  Thread.sleep(3000);
					  clickSelectButton.click();
				      selectEPLCoverage.click();
				      clickOKButton.click();
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		      
		 
			
		    }	
		   
	   
	   
	   public void validateProgramName()
	   
	   {
		   try 
		   {    Thread.sleep(3000);
			    Date d= new Date();
	            SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
	            String date = formatter.format(d);
	           // System.out.println(date);
		       
		        Thread.sleep(3000) ;
		        String dateCoverage = (date +"_EPL");
		    	//System.out.println(dateCoverage);
		    	String text = programDate.getText();
		    	//System.out.println(text);
		    	Assert.assertEquals(dateCoverage,text);
		       
		        
		       
		   }
		   catch(Exception e)
		    {
			   e.printStackTrace();
			
		    }	
	   }		   
	   
	   
	  
	   
	   public void fillHeadCountAndUSValues(String Value , String Value1)
	   {
		    try 
		    {
			   // String Val ="100";
				//String Val1="70";
				EPlBordereau.click();
				Thread.sleep(3000);
				selectAnnual.click();
				fillTotalHeadCount.sendKeys(Value);
				fillUSCount.sendKeys(Value1);
				headCountValue = fillTotalHeadCount.getAttribute("value");
				//System.out.println("headCountValue: " + headCountValue);
				 USCountValue =fillUSCount.getAttribute("value");
				 //System.out.println("USCountValue: " +USCountValue);
				 
				 int one = Integer.parseInt(USCountValue);
				 
				 fillFullTime.click();
				 String NonUSCountValue = totalNonUSCount.getText();
				 
				 //System.out.println("NonUSCountValue:" + NonUSCountValue);
				 int two = Integer.parseInt(NonUSCountValue);
				 
				 int three = one + two;
				 four =String.valueOf(three);
					
				 //System.out.println("Value of US and Non US is " + four);
				 //System.out.println("Value of Total Head Count is  is " + headCountValue);
				 
				 
		     }
	      
		   
		     catch(Exception e)
		     {
			    e.printStackTrace();
			
		     }	 
		  
	   }
				 
				 
		 public void VerifyHeadCountAndUSNonUSValues() 	
		 {
					  try
					  {
						  Assert.assertEquals(four, headCountValue);  
					  }
					  catch(Exception e)
					  {
						   e.printStackTrace();
						
					  }	 
					  
		 }
					
			 public void fillFullTimeValues(String Value)
		     {
					 
				  try
				  {
					  //String Val2="70";
					  fillFullTime.sendKeys(Value);
					  String fullTimeValue =fillFullTime.getAttribute("value");
					
					   //System.out.println(fillFullTime.getAttribute("value"));
					
					   int five = Integer.parseInt(fullTimeValue);
					
					   clickStateDropdown.click();
					
					   //System.out.println(totalPartTime.getText());
					
					   String partTimeValue = totalPartTime.getText();
					
					   int six = Integer.parseInt(partTimeValue);
					   Thread.sleep(3000);
					
				
					   int seven = five + six;
					   eight =String.valueOf(seven);
					
					   //System.out.println("Value of Total Head Count is  is " + headCountValue);
					   //System.out.println("Value of Part Time and Full Time  is " + eight);
					
				   }
				  
				   catch(Exception e)
				   {
						   e.printStackTrace();
						
				    }	  
			  }
			 
			 public void verifyHeadCountAndFullPartTimeValues () 	
			 {
				  try
				  {
					  Assert.assertEquals(eight, headCountValue);  
				  }
				  catch(Exception e)
				  {
					   e.printStackTrace();
					
				  }	 
				  
		     }
					
			 public void fillStateValues(String Value1 , String Value2 , String Value3 , String Value4 , String Value5)
			 {
					
				try
				{
				
				//	String V= "20";
				//	String V1= "20";
				//	String V2= "20";
				//	String V3= "5";
				//	String V4= "5";
					
					selectstate1.click();
					fillState1Value.sendKeys(Value1);
					String Q1 =fillState1Value.getAttribute("value");
					int p = Integer.parseInt(Q1);
					Thread.sleep(3000);
					
					clickStateDropdown2.click();
					Thread.sleep(3000);
					selectstate2.click();
					fillState2Value.sendKeys(Value2);
					String Q2 =fillState2Value.getAttribute("value");
					int p1 = Integer.parseInt(Q2);
					Thread.sleep(3000);
					
					clickStateDropdown3.click();
					Thread.sleep(3000);
					selectstate3.click();
					fillState3Value.sendKeys(Value3);
					String Q3 =fillState3Value.getAttribute("value");
					int p2 = Integer.parseInt(Q3);
					Thread.sleep(3000);
					
					clickStateDropdown4.click();
					Thread.sleep(3000);
					selectstate4.click();
					fillState4Value.sendKeys(Value4);
					String Q4 =fillState4Value.getAttribute("value");
					int p3 = Integer.parseInt(Q4);
					Thread.sleep(3000);
					
					clickStateDropdown5.click();
					Thread.sleep(3000);
					selectstate5.click();
					fillState5Value.sendKeys(Value5);
					String Q5 =fillState5Value.getAttribute("value");
					int p4 = Integer.parseInt(Q5);
					
					int p5 =p+p1+p2+p3+p4;
				    p6 =String.valueOf(p5);
					
					//System.out.println("Value of US Count is " + USCountValue);
					//System.out.println("Value of All Five States is " + p6);
					
				}		
					
				 
		  
		        catch(Exception e)
		        {
			       e.printStackTrace();
			
		         }	
	          }
		 
			 public void verifyUSAndStateValues() 	
		     {
				 try
				 {
				     Assert.assertEquals(p6, USCountValue);
				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			      }	 
				 
			 }
	   
	    
			 public void verifyOfficeFields() 	
		     {
				 try
				 {
					 webElementActions = new WebElementActions();
					 Assert.assertTrue(officeFields.isDisplayed()); 
					 webElementActions.isValuePresentinTxtBx(ARSOfficeNameTextbox);
					 webElementActions.isValuePresentinTxtBx(ARSOfficeContactTextbox);
					 webElementActions.isValuePresentinTxtBx(FSGProgramOfficeTextbox);
					 webElementActions.isValuePresentinTxtBx(FSGProgramTeamNameTextbox);
					 
				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			      }	 
			 
		     }
			 
			 public void selectRoleFields() 	
		     {
				 try
				 {   
					 
					JavascriptExecutor jse = (JavascriptExecutor) driver;

					 jse.executeScript("arguments[0].scrollIntoView()", Contact);
					 Thread.sleep(3000);
					 role1Arrow.click();
					 Thread.sleep(3000);
					 selectRole1.click();
					 Thread.sleep(3000);
					 role2Arrow.click();
					 Thread.sleep(3000);
					 selectRole2.click();

				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			      }	 
			 
		     }
			 
			 public void selectEmployeeFields() 	
		     {
				 try
				 {
					 employee1Arrow.click(); 
					 Thread.sleep(3000);
					 employee1Select.click();
					 Thread.sleep(3000);
					 employee2Search.click();
					 Thread.sleep(3000);
					 if(titleBar.getText().equalsIgnoreCase("Resource Employee Search"))
					 {
					 
					     driver.switchTo().frame(empFrame);
					     Thread.sleep(3000);
					     name1Select.click();
						 Thread.sleep(3000);
						 clickOkButton.click();
						 Thread.sleep(3000);
						 driver.switchTo().defaultContent();
					    
					 }
						
					  
					 
				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			      }	 
			 
		     }
			 
			 
			 public void fillProductionPercentage( String Value1 , String Value2) 	
		     {
				 try
				 {
					// String P1="50.0";
					// String P2="50.0";
					 prod1Textbox.sendKeys(Value1);
					 prod2Textbox.sendKeys(Value2);
					 
				     String	P3=prod1Textbox.getAttribute("value");
					 //System.out.println(P3);
					 prod3Textbox.click();
					 String P4=prod2Textbox.getAttribute("value");
					 //System.out.println(P4);
					 
					 String splitter[]= P3.split(" ");
					 String P5= splitter[0];
					 //System.out.println(P5);
					 
					
					 String splitter1[]= P4.split(" ");
					 String P6= splitter1[0];
					 //System.out.println(P6);
					
					 float q=Float.parseFloat(P5);
					 float q1=Float.parseFloat(P6);
					 //int q = Integer.parseInt(P5);
					 //int q1 =Integer.parseInt(P6);
					 Float q2 = q+q1;
					 
					 //System.out.println(q2);
					 
					 
					 sumProd = String.valueOf(q2);
					 //System.out.println("sumProd: " + sumProd );
					 
					 
				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			      }	 
			 
		     } 
			 
			 public void verifyProductionPercentage() 	
		     {
				 try
				 {
					 
					 String totalProdPercentage = "100.0";
					 Assert.assertEquals(totalProdPercentage,sumProd); 
					 
				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			      }	 
			 
		     } 
			 
			 
			 public void clickOnSave() 	
		     {
				 try
				 {
					saveButton.click();
				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			      }	 
			 
		    } 
			 
			 public void verifyPopup() 	
		     {
				 try
				 { 
					
					 webeleactions = new WebElementActions();
					 Boolean isPresent = webeleactions.isElementPresent("//em[text() = 'Create Program']");
					 System.out.println(isPresent);
					 if(isPresent==true) 
					 {
						createProgramConfirm.isDisplayed();
						String Msg = programCreationMsg.getText();
						Thread.sleep(3);		
						Assert.assertTrue(Msg.contains("has been created successfully"));
						clickNoButton.click();
					  }
					  else if(isPresent==false)
					  {
						   Assert.assertTrue(duplicateProgram.isDisplayed());
						   ClickYes.click();
				    	   Thread.sleep(3);
				    	   String Msg = programCreationMsg.getText();
				           Thread.sleep(3);		
						   Assert.assertTrue(Msg.contains("has been created successfully"));
					       clickNoButton.click();
					       Thread.sleep(3000);
				      }
				 }
			     catch(Exception e)
			     {
					 e.printStackTrace();
						
			     }	 
			 
		   }  
	}
		
	
	
