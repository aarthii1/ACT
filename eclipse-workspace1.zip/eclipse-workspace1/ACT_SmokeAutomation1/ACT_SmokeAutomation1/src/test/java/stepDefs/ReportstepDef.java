package stepDefs;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.testng.Assert;

import base.TestBase;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.PTDisApprovals;
import pages.Reports;

public class ReportstepDef extends TestBase {
	
	Reports reports;
	String reportname;

	@Given("Launch ACT BI report")
	public void launch_act_bi_report() {
	   
		try {
			initializeBIReport();
			
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    
	}
	
	@Then("User is on the BI Home page")
	public void user_is_on_the_bi_home_page() {
	    
		try {
			
			reports =new Reports();
			
			reports.verifyReportsLandingPage();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	@When("User selects Report")
	public void user_selects_report() {
		

		try {
			
						
			reports =new Reports();
					
			
			reports.OpenReport();
			
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
	   
	}
	@Then("The expected report page gets open")
	public void the_expected_report_page_gets_open() {
		
		try {
			reports =new Reports();
			
			
		}

		catch(Exception e) {
			e.printStackTrace();
		}
	}
//	@Then("User validates the Report with expected data")
//	public void user_validates_the_report_with_expected_data() {
//		
//		try {
//			reports =new Reports();
//			reports.applyParametersReport();
//					
//			Assert.assertTrue(reports.verifyParameters());
//				
//		}
//		
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		
//		
//		
//	   
//	}
	
	@Then("User validates the Report with expected data {string} and {string}")
	public void user_validates_the_report_with_expected_data_and(String string, String string2) {
	    
		try {
			reports =new Reports();
			reports.applyParametersReport(string,string2);
					
			Assert.assertTrue(reports.verifyParameters(string,string2));
				
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
	   
	}
		
	



}
