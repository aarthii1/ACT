package stepDefs;

import java.util.Map;

import org.testng.Assert;

import base.TestBase;
import commonUtils.DynamicClientNameCreation;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import pages.CreateClient;
import pages.Dashboard;
import pages.HomePage;
import pages.SignOut;
import commonUtils.DynamicClientNameCreation;


public class CreateClientstepDef extends TestBase {
	HomePage homepage;
	Dashboard dashboard;
	CreateClient createclient;
	SignOut signout;
	
@Given("Launch ACT application")
public void launch_act_application() {
		
		try {
		initialize();
		
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
	
@Then("User is on the Home page")
public void user_is_on_the_home_page() {
	    try {
	    	homepage = new HomePage();
	    	homepage.userOnHomePageValidation();
	    }
	    
	    catch(Exception e)
		{
			e.printStackTrace();
		}
}
	
@Given("User is on the ACT Home page")
public void user_is_on_the_act_home_page() {
	    try {
	    	homepage = new HomePage();
	    	homepage.userOnHomePageValidation();
	    }
	    
	    catch(Exception e)
		{
			e.printStackTrace();
		}
}

@When("User Clicks on Create Client page")
public void user_clicks_on_create_client_page() {
	try
	{
	
	dashboard =new Dashboard();
	
	dashboard.navigateToCreateClient();
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

@Then("User gets displayed with the Create Client page")
public void user_gets_displayed_with_the_create_client_page() {
	try
	{
	
	dashboard =new Dashboard();
	Assert.assertTrue(dashboard.verifyCreateClient());
	
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}


@Given("User is on the Create Client page")
public void user_is_on_the_create_client_page() {
	try
	{
	
	dashboard =new Dashboard();
	Assert.assertTrue(dashboard.verifyCreateClient());
	
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

@When("User selects the client name")
public void user_selects_the_client_name() {
	try {
	createclient = new CreateClient();
	createclient.enterClientName();
	
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

@And("User fills the mandatory details")
public void user_fills_mandatory_details() {
	try {
		createclient = new CreateClient();
		
		createclient.clickOnGVSearch();
		
		createclient.clearCmpNameTxtBx();
		
		Thread.sleep(2000);
		
		createclient.clickOnSearchGVKeyBtn();
		
		Thread.sleep(1000);
		
		createclient.selectGVKeyValue();
		
		Thread.sleep(2000);
		
		createclient.selectCmpStatus();
		
		Thread.sleep(1000);
		
		createclient.clickOnBridgeCltNoSrchBtn();
		
		Thread.sleep(1000);
		
		createclient.selectBridgeClientNo();
		
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}

@Then("User validates the Client Info and Bridge client details")
public void user_validates_the_client_info_and_bridge_client_details() {
	try {
		createclient = new CreateClient();
		
		createclient.client_info_validation();
		
	}
	catch (Exception e) {
		e.printStackTrace();
	}
}

@And("User validates Industry codes")
public void user_validates_industry_codes() {
	try {
		createclient = new CreateClient();
		
		createclient.industry_codes_validation();
		
		
	}
	catch (Exception e) {
		e.printStackTrace();
	}
}

@Given("User is on Create Client page")
public void user_is_on_create_client_page() {
	try {
		dashboard =new Dashboard();
		Assert.assertTrue(dashboard.verifyCreateClient());
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@When("User selects the value of Contacts and offices")
public void when_user_selects_the_value_of_contacts_and_offices() {
	try {
		
		createclient = new CreateClient();
		
		createclient.contact_office_selection();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@Then("User validates the Contact and Offices fields are updated")
public void user_validates_the_contact_and_offices_fields_are_updated() {
	try {
		createclient = new CreateClient();
		
		createclient.contact_office_validation();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@Given("Validation of User on the Create Client page")
public void validation_of_user_on_the_create_client_page() {
	try {
		dashboard =new Dashboard();
		Assert.assertTrue(dashboard.verifyCreateClient());
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@When("User selects the Alternative Asset Managment")
public void user_selects_the_alternative_asset_managment() {
	try {
		createclient = new CreateClient();
		
		createclient.market_info_assmgmt_selection();
		
		
	}
	catch(Exception e) {
		
	}
}

@And("User fills all the details")
public void user_fills_all_the_details() {
	try {
		createclient = new CreateClient();
		
		createclient.market_info_fill_details();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@Then("User clicks on the save button")
public void User_clicks_on_the_save_button() {
	try {
		createclient = new CreateClient();
		createclient.click_on_Save_button();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@Given("User validates the GVKey Confirm pop up")
public void user_validates_the_gvkey_confirm_pop_up() {
	try {
		createclient = new CreateClient();
		createclient.validating_gv_pop_up();
	}
	catch(Exception e) {
		
	}
}

@When("User provides confirmation")
public void user_provides_confirmation() {
	try {
		createclient = new CreateClient();
		createclient.click_on_cnfrm_btn();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@Then("User should validates the pop up")
public void user_should_validates_the_pop_up() {
	try {
		createclient = new CreateClient();
		createclient.validating_pop_up();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@And("User is on View Client page")
public void user_is_on_view_client_page() {
	try {
		dashboard = new Dashboard();
		dashboard.verifyViewClient();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

@And("Log off the application")
public void log_off_the_application() {
	try {
		signout = new SignOut();
		
		signout.clickOnMenu();
		
		signout.clickOnSignOut();
		
		signout.verifySignOut();
		
		closeAllBrowsers();
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}

}
