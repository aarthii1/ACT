package stepDefs;

import java.util.List;
import java.util.Map;

import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AllClientsPage;
import pages.ApprovalPT;
import pages.CreatePolicy;
import pages.Dashboard;
import pages.EndorsementPolicy;
import pages.HomePage;
import pages.PTDisApprovals;
import pages.SearchPolicy;
import pages.ViewPolicy;

public class EndorsementstepDef extends TestBase{

	HomePage homepage;
	SearchPolicy searchpolicy;
	EndorsementPolicy endopolicy;
	ViewPolicy viewpolicy;
	Dashboard dashboard;
	AllClientsPage allclients;
	Utility utility;
	PTDisApprovals ptmultiapproval;
	ApprovalPT approvals;
	
	@Given("Launch ACT Application")
	public void launch_act__application() {
		
		try {
		initialize();
		Map<String, String> values = xmlfileReader();
		
		System.out.println("Root element name is: " + values);
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	@Then("User is on Home Page")
	public void user_is_on_home_page() {
		
		try
		{
			homepage = new HomePage();
			
			homepage.userOnHomePageValidation();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	@When("User select Policy list Search option")
	public void user_select_policy_list_search_option() {
		
		try {
             dashboard =new Dashboard();
			
			dashboard.navigateToPolicyListSearch();
			
			searchpolicy = new SearchPolicy();
			Assert.assertTrue(searchpolicy.verifySearchPolicy());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("Search for the client name")
	public void search_for_the_client_name() {
		
		try {
		
            searchpolicy = new SearchPolicy();
			
			searchpolicy.enter_client_name();
			
			searchpolicy.click_on_search();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("expected client name displays")
	public void expected_client_name_displays() {
		try {
			
			searchpolicy = new SearchPolicy();
			searchpolicy.client_name_validation();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Given("User is on the View Policy screen")
	public void user_is_on_the_view_policy_screen() {
		try {
			
			viewpolicy = new ViewPolicy();
			
			viewpolicy.navigate_to_view_policy_screen();
			
			viewpolicy.validate_user_on_view_policy_page();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@When("User clicks on Endorsement Policy")
	public void user_clicks_on_endorsement_policy() {
		try {
			endopolicy= new EndorsementPolicy();
			
			endopolicy.click_on_Endorsement();
			
			endopolicy.wait_until_endorsement_page_load();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User is on Endorsement Policy page")
	public void user_is_on_endorsement_policy_page() {
		try 
	   	{
           dashboard = new Dashboard();
			
		   dashboard.verifyEndorsementpolicypage();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User validates the Policy section")
	public void user_validates_the_policy_section() {
		
		try {
            endopolicy= new EndorsementPolicy();
            
            endopolicy.verifydetails();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User clicked on save button")
	public void user_clicked_on_save_button() {
		  try
		  {
			  endopolicy= new EndorsementPolicy();
			  
			  endopolicy.saveEndorsementPolicy();
			  
			  endopolicy.wait_until_premium_page_load();
		  }
		  catch(Exception e)
			{
				e.printStackTrace();
			}
	  }
	  
	@Given("User is on Premium Transaction page")
    public void user_is_on_premium_transaction_page() {
		try 
	   	{
           dashboard = new Dashboard();
			
		   dashboard.verifyPremiumTransactionPage();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	  
	@When("User validates the Transaction type as Endorsement")
	public void user_validates_the_transaction_type_as_endorsement() {
	  try
	  {
		  endopolicy= new EndorsementPolicy();
		  endopolicy.transaction_type_validation();
		  
	  }
	  catch(Exception e)
		{
			e.printStackTrace();
		}
	  }
	  
	 @When("User fill the Transaction details and coverage details")
	 public void user_fill_the_transaction_details_and_coverage_details(DataTable data) {
		  
		 try
		  {
			  endopolicy= new EndorsementPolicy();
			  endopolicy.verify_revenue_details();
			  endopolicy.fill_inception_dates();
			  
			  List<List<String>> d = data.asLists();
				
			  String Premium = d.get(0).get(0);
			  String Commission = d.get(0).get(1);
			  String Fee1 = d.get(0).get(2);
			  endopolicy.fill_coverage_details(Premium, Commission, Fee1);
			  
		  }
		  catch(Exception e)
			{
				e.printStackTrace();
			}
	  }
	  
	 @Then("User clicks on submit for Approval")
	 public void user_clicks_on_submit_for_approval() {
		 
		 try
		  {
			  endopolicy= new EndorsementPolicy();
			  endopolicy.user_clicks_on_submit_approval();
			  endopolicy.user_validates_submission();
	  }
		 catch(Exception e)
			{
				e.printStackTrace();
			}
        }
	 
	 @Given("User clicks on Pt approval")
	 public void user_clicks_on_pt_approval() {
		
		 try {
			    dashboard =  new Dashboard();
				
				dashboard.navigateToPTapproval();
				
				boolean flag= dashboard.verifyPTApproval();
				
				Assert.assertTrue(flag);
		 }
		 catch(Exception e)
			{
				e.printStackTrace();
			}
	 }
	 
	 @When("User search for the client name")
	 public void user_search_for_the_client_name() {
		 try {
			 utility = new Utility();
				
				String SPClientName = utility.getClientName();
				
				ptmultiapproval = new PTDisApprovals();
				
				ptmultiapproval.applyFilterPTapprovals(SPClientName);
				
				ptmultiapproval.clientresultsValidation(SPClientName);
				
				ptmultiapproval.clickonViewTransaction();
			 
		 }
		 catch(Exception e)
			{
				e.printStackTrace();
			}
   }
	 
	 @When("User validates the layer value as {string} and the Transaction type value as {string}")
		public void user_validates_the_layer_value_and_the_transaction_type_values(String layerValue,String transactionTypeValue) {
			try {
				System.out.println("Layer - "+layerValue +"TType - "+transactionTypeValue);
				
				approvals = new ApprovalPT();
				
				
				approvals.validate_details("Endorsement", "0");
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	 
	 @Then("user clicks on Approve button")
	 public void user_clicks_on_approve_button() {
		 try {
			 
			 approvals = new ApprovalPT();
			 approvals.click_on_approve_button();
			 
			 Thread.sleep(3000);
			 
			 closeAllBrowsers();
	 }
		 catch(Exception e)
			{
				e.printStackTrace();
			}
	 }
	 
	 @After
		public void takescreenshot(Scenario scenario)
		{
			try
			{Utility.generateScreenshot(scenario);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	 }
