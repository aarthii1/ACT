package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;

public class Benchmarkingrequest extends TestBase {
	
	@FindBy(xpath ="//span[contains(text(),'Clients')]")
	WebElement Clients;
	
	@FindBy(xpath = "//a[text()='Benchmarking Request']")
	WebElement benchmarkButton;
	
	@FindBy(xpath = "//span[text()='Benchmarking Request Section']")
	WebElement benchmarkHeader;
	
	@FindBy(xpath ="//input[@value = 'Search']")
	WebElement searchButton;
	
	@FindBy(xpath="//iframe[@name = 'rwSearchCompany']")
	WebElement navigateframe;
	
	@FindBy(xpath="//em[text() =  'Search Client']")
	WebElement searchClient;
	
	@FindBy(xpath="//td[text()='01 Communique Laboratory Inc']")
	WebElement selectCompany;
	
	@FindBy(xpath="//input[contains(@name , 'HolderMain$btnOk')]")
	WebElement okButton;
	
	@FindBy(xpath="//tr[contains(@id , 'REquest_i0_rpbCompany_i0_trCompany3')]/td[2]/span")
	WebElement GVKey;
	
	@FindBy(xpath="//tr[contains(@id , 'REquest_i0_rpbCompany_i0_trCompany4')]/td[2]/span")
	WebElement dataSource;
	
	@FindBy(xpath="//input[contains(@id , 'Main_btnCancel_input')]")
	WebElement cancelButton;
	
	@FindBy(xpath="//span[text() ='OK']")
	WebElement clickOkButton;
	  
    public Benchmarkingrequest()
	{
		try
		{
		PageFactory.initElements(driver, this);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	 }
	
    
    
    public void clickBenchmarkButton()
	{
		try
		{
			Actions action = new Actions(driver);
			
			action.doubleClick(Clients).perform();
			benchmarkButton.click(); 
			
			Thread.sleep(3000);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	 }

     
    public void verifyBenchmarkPage()
	{
		try
		{
			if(benchmarkHeader.isDisplayed()) 
			{
				
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				
				jse.executeScript("arguments[0].click()",searchButton );
				
       		}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	 }
    
    public void selectCompany()
	{
		try
		{
			if(searchClient.isDisplayed()) 
			{
				
			  driver.switchTo().frame(navigateframe);
			  
			  selectCompany.click();
			  Thread.sleep(3000);
			  okButton.click();
			  
			  
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	 }

    public void verifyBenchmark()
	{
		try
		{
			Assert.assertTrue(GVKey.isDisplayed());
			Assert.assertTrue(dataSource.isDisplayed());
				
			cancelButton.click();
			Thread.sleep(4000);
			clickOkButton.click();
		}
		
		
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	 }

   
   		
   	 }
    
         







