package stepDefs;

import org.testng.Assert;

import base.TestBase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.CreateClient;
import pages.Dashboard;
import pages.HomePage;
import pages.SignOut;

public class CreateClientProdstepDef extends TestBase{
	HomePage homepage;
	Dashboard dashboard;
	CreateClient createclient;
	SignOut signout;
	
	@Given("User launches the ACT application")
	public void user_launches_the_act_application() {
			
			try {
			initialize();
			
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
		
	@Then("User is on the application HomePage")
	public void user_is_on_the_application_homepage() {
		    try {
		    	homepage = new HomePage();
		    	homepage.userOnHomePageValidation();
		    }
		    
		    catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@Given("User is on the ACT application Home page")
	public void user_is_on_the_act_application_home_page() {
		    try {
		    	homepage = new HomePage();
		    	homepage.userOnHomePageValidation();
		    }
		    
		    catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	@When("User Clicks on the Create Client page")
	public void user_clicks_on_the_create_client_page() {
		try
		{
		
		dashboard =new Dashboard();
		
		dashboard.navigateToCreateClient();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User gets displayed with Create Client page")
	public void user_gets_displayed_with_create_client_page() {
		try
		{
		
		dashboard =new Dashboard();
		Assert.assertTrue(dashboard.verifyCreateClient());
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Given("User is on CreateClient page")
	public void user_is_on_createclient_page() {
		try
		{
		
		dashboard =new Dashboard();
		Assert.assertTrue(dashboard.verifyCreateClient());
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	@When("User enters the client name and selects the company status as public")
	public void user_enters_the_client_name_and_selects_the_company_status_as_public() {
		try {
			createclient = new CreateClient();
			createclient.enterClientName();
			
			Thread.sleep(2000);
			
			createclient.selectCmpStatus();
			
			Thread.sleep(1000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User selects the bridge details")
	public void user_selects_the_bridge_details() {
		try {
			
			createclient = new CreateClient();
			
			createclient.clickOnBridgeCltNoSrchBtn();
			
			Thread.sleep(1000);
			
			createclient.selectBridgeClientNo();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User fills the client information details")
	public void user_fills_the_client_information_details() {
		try {
			createclient = new CreateClient();
			
			createclient.fill_client_details();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User validates the Client Information and Bridge client details")
	public void user_validates_the_client_information_and_bridge_client_details() {
		try {
			createclient = new CreateClient();
			
			createclient.client_info_validation_prod();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User is on the CreateClient page")
	public void user_is_on_the_createclient_page() {
		try {
			dashboard =new Dashboard();
			Assert.assertTrue(dashboard.verifyCreateClient());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	@When("User selects the value of the Contacts and Offices section")
	public void user_selects_the_value_of_the_contacts_and_offices_section() {
		try {
			
			createclient = new CreateClient();
			
			createclient.contact_office_selection();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User selects the value of Industry codes")
	public void user_selects_the_value_of_industry_codes() {
		try {
			createclient = new CreateClient();
			
			createclient.fill_industry_codes();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User validates the fields")
	public void user_validates_the_fileds() {
		try {
			createclient = new CreateClient();
			createclient.contact_office_validation();
			createclient.industry_codes_validation_prod();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("Validation of user is on the Create Client page")
	public void validation_of_user_is_on_the_create_client_page() {
		try {
			dashboard =new Dashboard();
			Assert.assertTrue(dashboard.verifyCreateClient());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User fills the Marketing and financial information")
	public void user_fills_the_marketing_and_financial_information() {
		try {
			createclient = new CreateClient();
			
			createclient.market_info_assmgmt_selection();
			
			createclient.market_info_fill_details_prod();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("User clicks on Cancel button")
	public void user_clicks_on_cancel_button() {
		try {
			createclient = new CreateClient();
			
			createclient.click_on_cancel_button();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("Clicks on the Yes button")
	public void clicks_on_the_yes_button() {
		try {
			createclient = new CreateClient();
			
			createclient.click_on_yes_button();
			
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Then("User successfully navigates to Client List page")
	public void user_successfully_navigates_to_client_list_page() {
		try {
			dashboard = new Dashboard();
			
			dashboard.veifyAllClients();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@And("User logs out of the ACT application")
	public void user_logs_out_of_the_act_application() {
		try {
			signout= new SignOut();
			signout.clickOnMenu();
			signout.clickOnSignOut();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
