package pages;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;
import commonUtils.WebElementActions;

public class Reports extends TestBase {
	
	//ReportHeader
	@FindBy(xpath ="//a[contains(text(),'BIReports')]")
	WebElement BIReportheading;
	
	//ReportLink
	@FindBy(xpath ="//a[contains(text(),'ExpirationHotList')]")
	WebElement Reportname;
	
	//ReportNameheading
	@FindBy(xpath="//div[text()='Expiration HotList']")
    WebElement Reportheading;
	
	//Parameters
	@FindBy(xpath="//span[text()='Parameters']")
	WebElement parameters;
	
	//FilterparameterYear
	@FindBy(css="select#m_sqlRsWebPart_ctl00_ctl19_ctl06_ctl03_ddValue")
	WebElement Yearfilter;
	
	//Filterparametermonth
		@FindBy(css="input#m_sqlRsWebPart_ctl00_ctl19_ctl06_ctl05_txtValue")
		WebElement Monthfilter;
		
		//Filterparamtermonthvalues
		
//		@FindAllBy(xpath="//div[@id='m_sqlRsWebPart_ctl00_ctl19_ctl06_ctl05_divDropDown']//table//td//input")
//		List <WebElement> monthfiltervalues;
//		
		@FindAll(@FindBy(how = How.XPATH, using = "//div[@id='m_sqlRsWebPart_ctl00_ctl19_ctl06_ctl05_divDropDown']//table//td//label"))
		List<WebElement> monthfiltervalues;
		
	//FilterparameterTeam
		@FindBy(css="input#m_sqlRsWebPart_ctl00_ctl19_ctl06_ctl07_txtValue")
		WebElement TeamName;
		

		@FindAll(@FindBy(how = How.XPATH, using = "//div[@id='m_sqlRsWebPart_ctl00_ctl19_ctl06_ctl07_divDropDown']//table//td//label"))
		List<WebElement> TeamNamefiltervalues;
		
		
		// ReportMonthname label
		////div[@class='Aef7ef0ee98984c969735204dc88708c135']
		@FindBy(xpath="(//div[contains(text(),'Policy Expiration Month')]//..//..//div)[2]")
		WebElement PolicyExplabel;
		
		//Reportyear label
		@FindBy(xpath="(//div[contains(text(),'Policy Expiration Year')]//..//..//div)[2]")
		WebElement Policyyearlabel;
	
	
		WebElementActions action;
		
	public Reports() {
		
		PageFactory.initElements(driver, this);
		
	}
	
	public void verifyReportsLandingPage()
	{
		try
		{
			
			Assert.assertTrue(BIReportheading.isDisplayed());
			
			System.out.println(driver.getTitle());
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void  OpenReport()
	{
		boolean flag= false;
		try
		{
			Reportname.click();
			Thread.sleep(2000);
			//flag = action.Explicitwait(Reportheading);
			
			//flag=parameters.isDisplayed();
//			String javascript = "document.evaluate('//div[text()='Expiration HotList']',document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue;";  
//			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
//			WebElement element = (WebElement) jsExecutor.executeScript(javascript);
			
			System.out.println(driver.getTitle());
			
			if (!Reportheading.isDisplayed())

			 Thread.sleep(5000);				
						
			Assert.assertTrue(Reportheading.isDisplayed());
			
			System.out.println(Reportheading.getText());
			
			Assert.assertTrue(parameters.isDisplayed());
			
		}
		

		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		//System.out.println(flag);
		//return flag;
	}
	
	public void applyParametersReport(String Yearvalue, String monthvalue)
	{
		
		
		try {
			
			action = new WebElementActions();
			
			//String Yearvalue ="2021";
			
			if (Yearvalue.isEmpty())
			
			action.selectDropdown(Yearfilter, "VALUE", "22");
			
			else
			{
				Yearvalue=Yearvalue.substring(2, 4);
				int yearvalue=((Integer.parseInt(Yearvalue))+1);
				
				Yearvalue= String.valueOf(yearvalue);		
								
				action.selectDropdown(Yearfilter, "VALUE",Yearvalue );
				
			}
			
			action.selectDropdown(Yearfilter, "VALUE", "22");
			Thread.sleep(1000);
			
			action.selectCombobox(Monthfilter, monthfiltervalues, monthvalue);
			
			Monthfilter.sendKeys(Keys.ENTER);
			
			
			Thread.sleep(1000);
			
			
		}
		

		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public boolean verifyParameters(String Yearvalue, String monthvalue)
	
	{  
		boolean flag =false;
		
		try
		{
			 if ((PolicyExplabel.getText().contains(monthvalue)) && (Policyyearlabel.getText().contains(Yearvalue)))
			 
			 flag=true;			 
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}
	

	

}
