package stepDefs;

import java.util.Map;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ApprovalPT;
import pages.Dashboard;
import pages.HomePage;
import pages.LeftMenuSelection;

public class PremiumApprovalstepDef extends TestBase{
	HomePage homepage;
	ApprovalPT approvalpt;
	Dashboard dashboard;
	
	@Given("Launches the ACT application")
	public void launches_the_act_application() {
		try { 
			initialize();
			Map<String, String> values = xmlfileReader();
			
			System.out.println("Root element name is: " + values);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}	
		
	}
	
	@Then("User is on homepage")
	public void user_is_on_homepage() {
		try
		{
			homepage = new HomePage();
			
			homepage.userOnHomePageValidation();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User selects the PT Approvalpage")
	public void user_seler_pt_approval() {
	   try {
			dashboard = new Dashboard();
			dashboard.navigateToPTapproval();
			dashboard.verifyPTApproval();
			}
	   catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User verifies the expected fields are getting displayed in Approvals")
	public void User_verifies_the_expected_fields_are_getting_displayed_in_Approvals()
	{
		 try
		   {
			 approvalpt = new ApprovalPT();
			 approvalpt.verifyPTApprovalFields();
		   
		   }
		   
		   catch(Exception e)
		   {
				e.printStackTrace();
		   }
	}

    @When("User Verify the Layer No Filter by entering value {string}")
    public void User_Verify_the_Layer_No_Filter_by_entering_value(String layerNumber)
    {
    	try
		   {
    		approvalpt = new ApprovalPT();
			approvalpt.fillLayerNo(layerNumber);

		   }
		   
		   catch(Exception e)
		   {
				e.printStackTrace();
		   }
    }

    @When("User select filter")
    public void User_select_filter()
    {
    	try
		   {
    		approvalpt = new ApprovalPT();
			approvalpt.clickOnFilter(); 
		   
		   }
		   
		   catch(Exception e)
		   {
				e.printStackTrace();
		   }	
    }

    @Then("The clients should get filtered out with layer value {string}")
    public void The_clients_should_get_filtered_out_with_layer_value(String layer)
    {
    	try
		   {
    		approvalpt = new ApprovalPT();
			approvalpt.verifyLayerDetail(layer);  

		   }
		   
		   catch(Exception e)
		   {
				e.printStackTrace();
		   }	
    }
    
    @Given("User is on the Pt Approvalpage")
    public void user_clicks_on_the_pt_approvalpage() {
    	 try {
 			dashboard = new Dashboard();
 			dashboard.verifyPTApproval();
 			}
 	   catch(Exception e)
 		{
 			e.printStackTrace();
 		}
    }

	@When("User selects ExpandApprovals, Pending approvals and PT Exception approvals")
	public void user_selects_expand_approvals_pending_approvals_and_pt_exception_approvals() {
		try {
			approvalpt = new ApprovalPT();
			approvalpt.click_on_Exceptionapproval();	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("Exception Approvals should be open")
	public void exception_approvals_should_be_open() {
		try{
				approvalpt = new ApprovalPT();
				
				approvalpt.validate_Exceptionpage();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Then("User verifies the expected fields are getting displayed in Exception Approvals")
	public void user_verifies_the_expected_fields_are_getting_displayed_in_exception_approvals() {
		try{
			approvalpt = new ApprovalPT();
			approvalpt.validates_client();
			approvalpt.validates_policydetails();
			approvalpt.validates_progdetails();
			approvalpt.validates_carrierdetails();
			approvalpt.validates_statusdetails();
			approvalpt.validates_effectivedatedetails();
			approvalpt.validates_expirationdetails();
			approvalpt.validates_foreigndetails();
			approvalpt.validates_punitivedetails();
			approvalpt.validates_quotadetails();
			approvalpt.validate_layernum();
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@When("User selects ExpandApprovals, Pending approvals and PT Correction approvals")
	public void user_selects_expand_approvals_pending_approvals_and_pt_correction_approvals() {
		try{
			approvalpt = new ApprovalPT();
			
			approvalpt.click_on_CorrectionApp();;
			
	}
	catch(Exception e)
	{
		e.printStackTrace();
	  }
  }
	
	@When("Correction Approvals should be open")
	public void correction_approvals_should_be_open() {
		try{
			approvalpt = new ApprovalPT();
			approvalpt.validate_Correctionptpage();
			
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
	
	
	@Then("User  the expected fields are getting displayed in Correction Approvals")
	public void user_the_expected_fields_are_getting_displayed_in_correction_approvals() {
		try{
			approvalpt = new ApprovalPT();
			approvalpt.validates_client();
			approvalpt.validates_policydetails();
			approvalpt.validates_progdetails();
			approvalpt.validates_carrierdetails();
			approvalpt.validates_statusdetails();
			approvalpt.validates_effectivedatedetails();
			approvalpt.validates_expirationdetails();
			approvalpt.validates_foreigndetails();
			approvalpt.validates_punitivedetails();
			approvalpt.validates_quotadetails();
			approvalpt.validate_layernum();
//			
			Thread.sleep(3000);
//			
//      		closeAllBrowsers();
			
		}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
	
	 @After
		public void takescreenshot(Scenario scenario)
		{
			try
			{Utility.generateScreenshot(scenario);
			
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	
}
