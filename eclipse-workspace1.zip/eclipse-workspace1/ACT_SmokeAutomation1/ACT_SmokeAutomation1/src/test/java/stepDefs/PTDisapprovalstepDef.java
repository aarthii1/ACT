package stepDefs;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;

import base.TestBase;
import commonUtils.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Dashboard;
import pages.DisapprovedPT;
import pages.HomePage;
import pages.PTDisApprovals;

public class PTDisapprovalstepDef extends TestBase {
	
	Dashboard dashboard;
	PTDisApprovals ptapprovals;
	DisapprovedPT disapprovePT;
	static String clientname;
	@When("User selects the PT Approvals")
	public void user_selects_the_pt_approvals() {
	    
		try
				
		{    initialize();
		dashboard =new Dashboard();

		dashboard.navigateToPTapproval();		
		boolean flag= dashboard.verifyPTApproval();
		Assert.assertTrue(flag);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	
	@When("User search for the Client")
	public void user_search_for_the_client(io.cucumber.datatable.DataTable dataTable) {
		
		try {
			
			List<List<String>> items= dataTable.asLists();
			String clientname1 = items.get(0).get(0);
		ptapprovals= new PTDisApprovals();
		
		ptapprovals.applyFilterPTapprovals(clientname1);
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	@Then("The expected client should display")
	public void the_expected_client_should_display(io.cucumber.datatable.DataTable dataTable) {
		
		try {
			
			List<List<String>> items= dataTable.asLists();
			clientname = items.get(0).get(0);
			
			ptapprovals= new PTDisApprovals();
			
			Assert.assertTrue(ptapprovals.clientresultsValidation(clientname));
			
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
	  
	}
	

@Given("User selects the clients")
public void user_selects_the_clients() {
	
	try
	{
		ptapprovals= new PTDisApprovals();
		
		ptapprovals.clickonViewTransaction();
		
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
    
}
@When("User validates the Client details")
public void user_validates_the_client_details() {
	
	try {
		
	//transdetails = new HashMap<String, String>();
	
	ptapprovals= new PTDisApprovals();
	ptapprovals.retrieveTransactiondetails();
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
    
}
@Then("User clicks on the Disapprove button")
public void user_clicks_on_the_disapprove_button() {
	
	try {
		
		
		
		ptapprovals= new PTDisApprovals();
		
		ptapprovals.clickonDisapprovebutton();
		
		System.out.println("func 1"+transdetails);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
   
}


@Given("User selects the Premium Transaction disapprove")
public void user_selects_the_premium_transaction_disapprove() {
   
	try {
	
		ptapprovals= new PTDisApprovals();
		//System.out.println(" func 2"+ transdetails);
		disapprovePT =new DisapprovedPT();



		disapprovePT.navigateToDisapprovedPT();
	
	
	}
	catch(Exception e) {
		
		e.printStackTrace();
	}
	
	
	
}
@When("User filter the transaction details")
public void user_filter_the_transaction_details() {
	
	disapprovePT.applyfiltertransaction(clientname, transdetails.get("Program name"), transdetails.get("Policy number"));
	
	//disapprovePT.applyfiltertransaction("dishatest1", "06-22-2022_EPL", "pol1");
	
	
}
@Then("User expand the filtered transactions and clicks View Transaction")
public void user_expand_the_filtered_transactions() {
    
	try 
	{
	disapprovePT.clickonViewTransaction();
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

@Then("User validates the View transaction details")
public void user_validates_the_view_transaction_details() {
    // Write code here that turns the phrase above into concrete actions
    
	disapprovePT.validateTransdetails(transdetails.get("Policy number"));
	

}

@Then("User close the browser")
public void User_close_the_browser() {
    // Write code here that turns the phrase above into concrete actions
    
	closeAllBrowsers();
	

}

@After
public void takescreenshot(Scenario scenario)
{
	try
	{Utility.generateScreenshot(scenario);
	
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
}




}
